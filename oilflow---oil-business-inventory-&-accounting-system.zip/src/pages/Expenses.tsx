import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { ExpenseHead, Transaction } from '../types';

export const Expenses: React.FC = () => {
  const {
    expenseHeads,
    addExpenseHead,
    updateExpenseHead,
    deleteExpenseHead,
    getExpenseHeadSpending,
    totalExpensesAllTime,
    todayExpenses,
    openJournalModal,
    transactions,
    openViewTransactionModal,
    openPdfPreview,
    accounts,
    formatCurrency,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'spending' | 'name' | 'recent'>('spending');

  // Add / Edit Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingHead, setEditingHead] = useState<ExpenseHead | null>(null);
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState('General');
  const [formDescription, setFormDescription] = useState('');

  // Extract all categories
  const categories = useMemo(() => {
    const set = new Set<string>();
    expenseHeads.forEach((h) => {
      if (h.category) set.add(h.category);
    });
    return ['All', ...Array.from(set)];
  }, [expenseHeads]);

  // Filter and sort expense heads
  const filteredHeads = useMemo(() => {
    let result = expenseHeads.filter((h) => {
      if (selectedCategory !== 'All' && h.category !== selectedCategory) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = h.name.toLowerCase().includes(q);
        const matchCat = h.category?.toLowerCase().includes(q);
        const matchDesc = h.description?.toLowerCase().includes(q);
        if (!matchName && !matchCat && !matchDesc) return false;
      }
      return true;
    });

    if (sortBy === 'spending') {
      result.sort((a, b) => getExpenseHeadSpending(b.id) - getExpenseHeadSpending(a.id));
    } else if (sortBy === 'name') {
      result.sort((a, b) => a.name.localeCompare(b.name));
    } else if (sortBy === 'recent') {
      result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    return result;
  }, [expenseHeads, selectedCategory, searchQuery, sortBy, getExpenseHeadSpending]);

  // Recent Expense Transactions
  const expenseTransactions = useMemo(() => {
    return transactions
      .filter((t) => t.type === 'Pay' && (t.expenseHeadId || t.expenseHeadName))
      .slice(0, 20);
  }, [transactions]);

  // Top spending head
  const topHead = useMemo(() => {
    if (expenseHeads.length === 0) return null;
    let max = -1;
    let best = expenseHeads[0];
    expenseHeads.forEach((h) => {
      const sp = getExpenseHeadSpending(h.id);
      if (sp > max) {
        max = sp;
        best = h;
      }
    });
    return max > 0 ? { head: best, amount: max } : null;
  }, [expenseHeads, getExpenseHeadSpending]);

  const handleOpenAdd = () => {
    setEditingHead(null);
    setFormName('');
    setFormCategory('General');
    setFormDescription('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (head: ExpenseHead) => {
    setEditingHead(head);
    setFormName(head.name);
    setFormCategory(head.category || 'General');
    setFormDescription(head.description || '');
    setIsModalOpen(true);
  };

  const handleSaveHead = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      alert('Please enter an Expense Head name.');
      return;
    }

    if (editingHead) {
      updateExpenseHead(editingHead.id, {
        name: formName.trim(),
        category: formCategory.trim() || 'General',
        description: formDescription.trim(),
      });
    } else {
      addExpenseHead({
        name: formName.trim(),
        category: formCategory.trim() || 'General',
        description: formDescription.trim(),
      });
    }

    setIsModalOpen(false);
  };

  const handleDeleteHead = (head: ExpenseHead) => {
    const spending = getExpenseHeadSpending(head.id);
    if (spending > 0) {
      if (
        !window.confirm(
          `Head "${head.name}" has Rs. ${spending.toLocaleString()} in recorded expense payments. Are you sure you want to delete this head?`
        )
      ) {
        return;
      }
    } else {
      if (!window.confirm(`Delete expense head "${head.name}"?`)) {
        return;
      }
    }
    deleteExpenseHead(head.id);
  };

  const getCategoryIcon = (category: string) => {
    const c = category.toLowerCase();
    if (c.includes('rent')) return 'apartment';
    if (c.includes('elect') || c.includes('util')) return 'bolt';
    if (c.includes('fuel') || c.includes('diesel')) return 'local_gas_station';
    if (c.includes('labor') || c.includes('wage') || c.includes('salary')) return 'engineering';
    if (c.includes('trans') || c.includes('freight')) return 'local_shipping';
    if (c.includes('tea') || c.includes('mess') || c.includes('food')) return 'restaurant';
    if (c.includes('maint') || c.includes('repair')) return 'build';
    if (c.includes('pack') || c.includes('drum')) return 'inventory_2';
    return 'receipt_long';
  };

  return (
    <div className="flex flex-col w-full pb-16">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-space-md mb-space-lg">
        <div>
          <div className="flex items-center gap-space-xs text-on-surface-variant font-label-sm uppercase tracking-wider mb-1">
            <span>Financials &amp; Accounts</span>
            <span className="material-symbols-outlined text-[14px]">chevron_right</span>
            <span className="text-primary font-semibold">Expense Heads</span>
          </div>
          <div className="flex items-center gap-2">
            <h1 className="font-headline-lg text-headline-lg text-on-surface font-semibold tracking-tight">
              Expense Heads &amp; Overheads
            </h1>
          </div>
          <p className="font-body-md text-body-md text-on-surface-variant mt-0.5">
            Manage depot expense categories (Rent, Electricity, Fuel, Labor) and record direct JV Out payment vouchers.
          </p>
        </div>

        {/* Top Actions */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => openJournalModal('Out')}
            className="h-10 px-4 rounded-lg bg-error hover:bg-error/90 text-white font-label-md text-label-md font-semibold flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
          >
            <span className="material-symbols-outlined text-[18px]">call_made</span>
            <span>Record JV Out</span>
          </button>

          <button
            type="button"
            onClick={handleOpenAdd}
            className="h-10 px-4 rounded-lg bg-primary-container text-on-primary hover:bg-primary font-label-md text-label-md font-semibold flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
          >
            <span className="material-symbols-outlined text-[18px]">add</span>
            <span>+ New Expense Head</span>
          </button>
        </div>
      </div>

      {/* 4 Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-gutter mb-space-lg">
        {/* Card 1: Total All-time Expenses */}
        <div className="bg-surface-container-lowest rounded-xl p-space-md shadow-sm border border-surface-container-high/40 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-space-xs">
            <span className="font-label-md text-label-md text-on-surface-variant font-medium">Total Expenses (All Time)</span>
            <span className="w-8 h-8 rounded-lg bg-error-container text-on-error-container flex items-center justify-center">
              <span className="material-symbols-outlined text-[18px]">output</span>
            </span>
          </div>
          <div>
            <div className="font-metric-xl text-metric-xl text-on-surface font-bold tracking-tight">
              Rs. {totalExpensesAllTime.toLocaleString()}
            </div>
            <p className="font-body-sm text-[12px] text-on-surface-variant mt-0.5">
              Cumulative payouts across all heads
            </p>
          </div>
        </div>

        {/* Card 2: Today's Expenses */}
        <div className="bg-surface-container-lowest rounded-xl p-space-md shadow-sm border border-surface-container-high/40 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-space-xs">
            <span className="font-label-md text-label-md text-on-surface-variant font-medium">Today&apos;s Expense Outflow</span>
            <span className="w-8 h-8 rounded-lg bg-tertiary-fixed/30 text-tertiary flex items-center justify-center">
              <span className="material-symbols-outlined text-[18px]">today</span>
            </span>
          </div>
          <div>
            <div className="font-metric-xl text-metric-xl text-error font-bold tracking-tight">
              Rs. {todayExpenses.toLocaleString()}
            </div>
            <p className="font-body-sm text-[12px] text-on-surface-variant mt-0.5">
              Paid today from Cash Safe or Bank
            </p>
          </div>
        </div>

        {/* Card 3: Configured Heads Count */}
        <div className="bg-surface-container-lowest rounded-xl p-space-md shadow-sm border border-surface-container-high/40 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-space-xs">
            <span className="font-label-md text-label-md text-on-surface-variant font-medium">Active Expense Heads</span>
            <span className="w-8 h-8 rounded-lg bg-primary-container/20 text-primary flex items-center justify-center">
              <span className="material-symbols-outlined text-[18px]">category</span>
            </span>
          </div>
          <div>
            <div className="font-metric-xl text-metric-xl text-on-surface font-bold tracking-tight">
              {expenseHeads.length}
            </div>
            <p className="font-body-sm text-[12px] text-on-surface-variant mt-0.5">
              Available in JV Out dropdown
            </p>
          </div>
        </div>

        {/* Card 4: Top Spending Head */}
        <div className="bg-surface-container-lowest rounded-xl p-space-md shadow-sm border border-surface-container-high/40 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-space-xs">
            <span className="font-label-md text-label-md text-on-surface-variant font-medium">Top Spending Category</span>
            <span className="w-8 h-8 rounded-lg bg-secondary-container text-on-secondary-fixed flex items-center justify-center">
              <span className="material-symbols-outlined text-[18px]">trending_up</span>
            </span>
          </div>
          <div>
            <div className="font-headline-sm text-headline-sm text-on-surface font-bold truncate">
              {topHead ? topHead.head.name.split('(')[0].trim() : 'None Recorded'}
            </div>
            <p className="font-body-sm text-[12px] text-primary font-semibold mt-0.5">
              {topHead ? `Rs. ${topHead.amount.toLocaleString()} spent` : 'Ready for JV payments'}
            </p>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-surface-container-lowest rounded-xl p-space-md shadow-sm border border-surface-container-high/40 mb-space-md space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Search Box */}
          <div className="relative flex-1 max-w-md">
            <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-[18px]">
              search
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search heads by title, category..."
              className="w-full h-10 pl-9 pr-8 bg-surface-container-low rounded-lg text-body-sm text-on-surface placeholder:text-on-surface-variant focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-on-surface-variant hover:text-on-surface text-[14px]"
              >
                ✕
              </button>
            )}
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-2">
            <span className="font-label-sm text-label-sm text-on-surface-variant whitespace-nowrap">Sort By:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
              className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface border border-surface-container-high/40 focus:outline-none focus:ring-2 focus:ring-primary/20"
            >
              <option value="spending">Highest Spending</option>
              <option value="name">Name A-Z</option>
              <option value="recent">Recently Added</option>
            </select>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-full text-[12px] font-semibold whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-primary text-on-primary shadow-xs'
                  : 'bg-surface-container-low text-on-surface-variant hover:bg-surface-container hover:text-on-surface'
              }`}
            >
              {cat === 'All' ? 'All Heads' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Expense Heads List View */}
      <div className="bg-surface-container-lowest rounded-xl shadow-sm border border-surface-container-high/40 overflow-hidden mb-space-lg">
        <div className="px-space-md py-3.5 bg-surface-container-low border-b border-surface-container-high/40 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-[20px]">format_list_bulleted</span>
            <h2 className="font-headline-sm text-headline-sm font-semibold text-on-surface">
              Expense Heads Directory
            </h2>
            <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-primary-container/20 text-primary">
              {filteredHeads.length} {filteredHeads.length === 1 ? 'Head' : 'Heads'}
            </span>
          </div>
          <span className="text-[12px] text-on-surface-variant hidden sm:inline">
            Direct payment heads for operational expenses
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-surface-container-low/60 h-10 text-on-surface-variant font-label-sm text-label-sm uppercase tracking-wider text-[11px] border-b border-surface-container-high/40">
                <th className="py-2.5 px-space-md font-semibold">Expense Head &amp; Description</th>
                <th className="py-2.5 px-space-md font-semibold">Category</th>
                <th className="py-2.5 px-space-md text-right font-semibold">Total Spent</th>
                <th className="py-2.5 px-space-md text-center font-semibold">Quick Action</th>
                <th className="py-2.5 px-space-md text-right font-semibold">Manage</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-container-low/60 text-[13px] text-on-surface">
              {filteredHeads.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-on-surface-variant">
                    <span className="material-symbols-outlined text-[36px] text-on-surface-variant/40 mb-2 block">
                      receipt_long
                    </span>
                    <p className="font-semibold text-on-surface text-[15px]">No matching expense heads found</p>
                    <p className="text-[12px] text-on-surface-variant max-w-sm mx-auto mt-1 mb-4">
                      Try adjusting your search query or create a new head to categorize your depot expenses.
                    </p>
                    <button
                      type="button"
                      onClick={handleOpenAdd}
                      className="px-4 py-2 bg-primary text-white text-[13px] font-semibold rounded-lg shadow-sm hover:bg-primary/90 transition-colors"
                    >
                      + Add Expense Head
                    </button>
                  </td>
                </tr>
              ) : (
                filteredHeads.map((head) => {
                  const spending = getExpenseHeadSpending(head.id);
                  const icon = getCategoryIcon(head.category);

                  return (
                    <tr
                      key={head.id}
                      className="hover:bg-surface-container-low/50 transition-colors group"
                    >
                      {/* Name & Description */}
                      <td className="py-3 px-space-md">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-lg bg-surface-container-low text-primary flex items-center justify-center shrink-0 border border-surface-container-high/40">
                            <span className="material-symbols-outlined text-[19px]">{icon}</span>
                          </div>
                          <div className="min-w-0">
                            <div className="font-headline-sm text-[14px] font-bold text-on-surface leading-snug">
                              {head.name}
                            </div>
                            <div className="text-[12px] text-on-surface-variant line-clamp-1">
                              {head.description || 'Operational overhead category'}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Category */}
                      <td className="py-3 px-space-md whitespace-nowrap">
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-secondary-container text-on-secondary-fixed">
                          {head.category || 'General'}
                        </span>
                      </td>

                      {/* Total Spent */}
                      <td className="py-3 px-space-md text-right whitespace-nowrap">
                        <span
                          className={`font-metric-md text-[14px] font-bold ${
                            spending > 0 ? 'text-error font-extrabold' : 'text-on-surface-variant'
                          }`}
                        >
                          Rs. {spending.toLocaleString()}
                        </span>
                      </td>

                      {/* Quick JV Action */}
                      <td className="py-3 px-space-md text-center whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => openJournalModal('Out', head.id)}
                          className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg bg-primary-container text-on-primary hover:bg-primary text-[12px] font-bold shadow-xs active:scale-95 transition-all"
                          title="Record direct JV Out payment for this head"
                        >
                          <span className="material-symbols-outlined text-[15px]">call_made</span>
                          <span>Pay via JV</span>
                        </button>
                      </td>

                      {/* Edit / Delete */}
                      <td className="py-3 px-space-md text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            type="button"
                            onClick={() => handleOpenEdit(head)}
                            className="p-1.5 rounded-lg text-on-surface-variant hover:text-primary hover:bg-surface-container transition-colors"
                            title="Edit Head"
                          >
                            <span className="material-symbols-outlined text-[18px]">edit</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteHead(head)}
                            className="p-1.5 rounded-lg text-on-surface-variant hover:text-error hover:bg-error-container/30 transition-colors"
                            title="Delete Head"
                          >
                            <span className="material-symbols-outlined text-[18px]">delete</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Expense Payouts Audit Table */}
      <div className="bg-surface-container-lowest rounded-xl shadow-sm border border-surface-container-high/40 overflow-hidden">
        <div className="px-space-md py-3.5 bg-surface-container-low border-b border-surface-container-high/40 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-[20px]">history_edu</span>
            <h3 className="font-headline-sm text-headline-sm font-semibold text-on-surface">
              Recent Expense JV Payouts
            </h3>
          </div>
          <span className="text-[12px] font-medium text-on-surface-variant">
            {expenseTransactions.length} recent postings
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-surface-container-low/70 h-9 text-on-surface-variant font-label-sm text-label-sm uppercase tracking-wider text-[11px]">
                <th className="py-2 px-space-md font-semibold">Date &amp; Time</th>
                <th className="py-2 px-space-md font-semibold">Doc #</th>
                <th className="py-2 px-space-md font-semibold">Expense Head</th>
                <th className="py-2 px-space-sm font-semibold">Paid Via</th>
                <th className="py-2 px-space-md font-semibold">Description / Remarks</th>
                <th className="py-2 px-space-md text-right font-semibold">Amount (PKR)</th>
                <th className="py-2 px-space-md text-center font-semibold">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-container-low/60 text-[13px] text-on-surface">
              {expenseTransactions.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-on-surface-variant">
                    <p className="font-semibold text-on-surface">No expense payouts recorded yet</p>
                    <p className="text-[12px] text-on-surface-variant mt-0.5">
                      Click &quot;Record JV Out&quot; above or select &quot;Pay via JV&quot; on any head to record an expense.
                    </p>
                  </td>
                </tr>
              ) : (
                expenseTransactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-surface-container-low/40 transition-colors">
                    <td className="py-2.5 px-space-md whitespace-nowrap">
                      <span className="font-semibold">{tx.date}</span>
                      <span className="text-on-surface-variant text-[11px] block">{tx.time}</span>
                    </td>
                    <td className="py-2.5 px-space-md whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => openPdfPreview(tx)}
                        className="inline-flex items-center gap-1.5 font-bold text-primary text-[13px] hover:underline cursor-pointer focus:outline-none transition-all"
                        title="Click to view & download PDF"
                      >
                        <span className="material-symbols-outlined text-[15px] opacity-75">picture_as_pdf</span>
                        <span>{tx.docNumber}</span>
                      </button>
                    </td>
                    <td className="py-2.5 px-space-md whitespace-nowrap">
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-error-container text-on-error-container">
                        <span className="material-symbols-outlined text-[13px]">receipt_long</span>
                        {tx.expenseHeadName || 'Expense'}
                      </span>
                    </td>
                    <td className="py-2.5 px-space-sm whitespace-nowrap text-on-surface-variant">
                      {tx.accountName || 'Cash Vault'}
                    </td>
                    <td className="py-2.5 px-space-md max-w-xs truncate text-on-surface-variant">
                      {tx.notes || 'Expense Outflow'}
                    </td>
                    <td className="py-2.5 px-space-md text-right whitespace-nowrap font-bold text-error">
                      Rs. {tx.paidAmount.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-space-md text-center whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => openViewTransactionModal(tx)}
                        className="text-primary hover:underline text-[12px] font-semibold"
                      >
                        View Slip
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Expense Head Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-inverse-surface/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-surface-container-lowest w-full max-w-md rounded-2xl shadow-2xl border border-surface-container-high overflow-hidden flex flex-col">
            <div className="px-5 py-4 bg-surface-container-low flex items-center justify-between border-b border-surface-container-high/40">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-primary text-[22px]">
                  {editingHead ? 'edit_note' : 'add_circle'}
                </span>
                <h3 className="font-headline-sm text-headline-sm font-semibold text-on-surface">
                  {editingHead ? 'Edit Expense Head' : 'Add New Expense Head'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="w-8 h-8 rounded-full hover:bg-surface-container-high text-on-surface-variant flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveHead} className="p-5 space-y-4">
              <div>
                <label className="block font-label-sm text-label-sm font-semibold text-on-surface mb-1">
                  Head Name <span className="text-error">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. Generator Diesel"
                  className="w-full h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface border border-surface-container-high/60 focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>

              <div>
                <label className="block font-label-sm text-label-sm font-semibold text-on-surface mb-1">
                  Category <span className="text-error">*</span>
                </label>
                <select
                  value={formCategory}
                  onChange={(e) => setFormCategory(e.target.value)}
                  className="w-full h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface border border-surface-container-high/60 focus:outline-none focus:ring-2 focus:ring-primary/20 font-medium"
                >
                  <option value="Rent & Premises">Rent &amp; Premises</option>
                  <option value="Utilities">Utilities</option>
                  <option value="Utilities & Fuel">Utilities &amp; Fuel</option>
                  <option value="Labor & Wages">Labor &amp; Wages</option>
                  <option value="Logistics">Logistics &amp; Transport</option>
                  <option value="Office & Mess">Office &amp; Mess</option>
                  <option value="Maintenance">Maintenance &amp; Repair</option>
                  <option value="Operations">Operations &amp; Packaging</option>
                  <option value="Miscellaneous">Miscellaneous</option>
                </select>
              </div>

              <div>
                <label className="block font-label-sm text-label-sm font-semibold text-on-surface mb-1">
                  Description / Note
                </label>
                <textarea
                  rows={2}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="e.g. Daily diesel filling for power outage generator..."
                  className="w-full p-2.5 bg-surface-container-low rounded-lg text-body-sm text-on-surface border border-surface-container-high/60 focus:outline-none focus:ring-2 focus:ring-primary/20 resize-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-surface-container-high/40">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="h-10 px-4 rounded-lg bg-surface-container-low hover:bg-surface-container text-on-surface font-semibold text-[13px]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="h-10 px-5 rounded-lg bg-primary text-white font-semibold text-[13px] shadow-sm flex items-center gap-1.5 active:scale-95 transition-all"
                >
                  <span className="material-symbols-outlined text-[18px]">check</span>
                  <span>{editingHead ? 'Update Head' : 'Save Head'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
