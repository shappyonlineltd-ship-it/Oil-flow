import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { TransactionType, Transaction } from '../types';

export const Transactions: React.FC = () => {
  const {
    transactions,
    accounts,
    openTransactionModal,
    openJournalModal,
    openViewTransactionModal,
    openEditTransactionModal,
    deleteTransaction,
    searchQuery,
    setSearchQuery,
    openPdfPreview,
  } = useApp();

  const [selectedType, setSelectedType] = useState<string>('All');
  const [selectedAccount, setSelectedAccount] = useState<string>('All');
  const [selectedDateRange, setSelectedDateRange] = useState<'All' | 'Today' | 'This Week' | 'This Month'>('All');
  const [dropdownOpen, setDropdownOpen] = useState(false);

  // Counts by type
  const counts = useMemo(() => {
    return {
      All: transactions.length,
      Purchase: transactions.filter((t) => t.type === 'Purchase').length,
      Sale: transactions.filter((t) => t.type === 'Sale').length,
      Receive: transactions.filter((t) => t.type === 'Receive').length,
      Pay: transactions.filter((t) => t.type === 'Pay').length,
      Transfer: transactions.filter((t) => t.type === 'Transfer').length,
    };
  }, [transactions]);

  // Filtering
  const filtered = useMemo(() => {
    return transactions.filter((t) => {
      // Type
      if (selectedType !== 'All' && t.type !== selectedType) return false;
      // Account
      if (selectedAccount !== 'All') {
        const matchesAccount =
          t.type === 'Transfer'
            ? t.accountId === selectedAccount || t.toAccountId === selectedAccount
            : t.accountId === selectedAccount && (t.paidAmount || 0) > 0;
        if (!matchesAccount) return false;
      }
      // Date range
      if (selectedDateRange !== 'All') {
        const txDate = new Date(t.date);
        const now = new Date();
        if (selectedDateRange === 'Today') {
          const todayStr = now.toISOString().slice(0, 10);
          if (t.date !== todayStr) return false;
        } else if (selectedDateRange === 'This Week') {
          const diffDays = (now.getTime() - txDate.getTime()) / (1000 * 3600 * 24);
          if (diffDays > 7) return false;
        } else if (selectedDateRange === 'This Month') {
          const monthStr = now.toISOString().slice(0, 7);
          if (!t.date.startsWith(monthStr)) return false;
        }
      }
      // Search
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchDoc = t.docNumber.toLowerCase().includes(q);
        const matchParty = t.partyName?.toLowerCase().includes(q);
        const matchExpense = t.expenseHeadName?.toLowerCase().includes(q);
        const matchAccount = t.accountName?.toLowerCase().includes(q);
        const matchNotes = t.notes?.toLowerCase().includes(q);
        const matchItems = t.items?.some((i) => i.productName.toLowerCase().includes(q));
        if (!matchDoc && !matchParty && !matchExpense && !matchAccount && !matchNotes && !matchItems) return false;
      }
      return true;
    });
  }, [transactions, selectedType, selectedAccount, selectedDateRange, searchQuery]);

  const handleExportCSV = () => {
    const headers = ['DocNumber', 'Type', 'Date', 'Time', 'Party', 'Account', 'Amount', 'PaidAmount', 'BalanceDue', 'Status', 'Notes'];
    const rows = filtered.map((t) => [
      t.docNumber,
      t.type,
      t.date,
      t.time,
      t.partyName || '',
      t.accountName || '',
      t.totalAmount,
      t.paidAmount,
      t.balanceDue,
      t.paymentStatus,
      t.notes || '',
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `OilFlow_Transactions_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDelete = (tx: Transaction) => {
    if (
      window.confirm(
        `Delete transaction ${tx.docNumber}? This will automatically reverse all stock changes, account balances, and party ledger entries.`
      )
    ) {
      deleteTransaction(tx.id);
    }
  };

  return (
    <div className="flex flex-col w-full pb-12">
      {/* Top Operational Header Bar */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-space-md mb-space-lg">
        <div>
          <div className="flex items-center gap-space-xs text-on-surface-variant font-label-sm uppercase tracking-wider mb-1">
            <span>Ledger &amp; Financials</span>
            <span className="material-symbols-outlined text-[14px]">chevron_right</span>
            <span className="text-primary font-semibold">Audit Records</span>
          </div>
          <h1 className="font-headline-lg text-headline-lg text-on-surface font-semibold tracking-tight">
            Transactions &amp; Audit Log
          </h1>
          <p className="font-body-md text-body-md text-on-surface-variant mt-0.5">
            Complete audit log of all oil purchases, sales, receipts, payments, and vault/bank transfers.
          </p>
        </div>

        {/* Right Action Set: Export & New Transaction Dropdown */}
        <div className="flex items-center gap-space-sm self-start md:self-auto relative">
          <button
            onClick={handleExportCSV}
            className="h-10 px-space-md bg-surface-container-low text-on-surface rounded-lg font-label-md text-label-md font-semibold flex items-center gap-space-xs hover:bg-surface-container transition-colors shadow-xs"
            type="button"
          >
            <span className="material-symbols-outlined text-[18px]">file_download</span>
            <span>Export Log</span>
          </button>

          {/* New Transaction Button with Dropdown */}
          <div className="relative inline-block text-left">
            <button
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="h-10 px-space-md bg-primary-container text-on-primary rounded-lg font-label-md text-label-md font-semibold flex items-center gap-space-xs hover:bg-primary transition-colors shadow-sm focus:outline-none"
              type="button"
            >
              <span className="material-symbols-outlined text-[20px]">add</span>
              <span>New Transaction</span>
              <span className="material-symbols-outlined text-[18px] ml-1">arrow_drop_down</span>
            </button>

            {dropdownOpen && (
              <div className="absolute right-0 mt-2 w-56 rounded-xl bg-surface-container-lowest shadow-xl border border-surface-container-high py-1.5 z-30 focus:outline-none animate-in fade-in duration-100">
                <button
                  type="button"
                  onClick={() => {
                    setDropdownOpen(false);
                    openTransactionModal('Sale');
                  }}
                  className="w-full flex items-center gap-space-sm px-space-md py-2 text-left text-on-surface hover:bg-surface-container-low transition-colors font-body-sm text-body-sm"
                >
                  <span className="material-symbols-outlined text-primary text-[20px]">point_of_sale</span>
                  <div>
                    <p className="font-headline-sm text-[13px] font-semibold">New Sale</p>
                    <p className="text-on-surface-variant text-[11px]">Direct invoice or dispatch</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setDropdownOpen(false);
                    openTransactionModal('Purchase');
                  }}
                  className="w-full flex items-center gap-space-sm px-space-md py-2 text-left text-on-surface hover:bg-surface-container-low transition-colors font-body-sm text-body-sm"
                >
                  <span className="material-symbols-outlined text-secondary text-[20px]">local_shipping</span>
                  <div>
                    <p className="font-headline-sm text-[13px] font-semibold">New Purchase</p>
                    <p className="text-on-surface-variant text-[11px]">Tanker intake &amp; bulk drums</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setDropdownOpen(false);
                    openTransactionModal('Receive');
                  }}
                  className="w-full flex items-center gap-space-sm px-space-md py-2 text-left text-on-surface hover:bg-surface-container-low transition-colors font-body-sm text-body-sm"
                >
                  <span className="material-symbols-outlined text-tertiary text-[20px]">call_received</span>
                  <div>
                    <p className="font-headline-sm text-[13px] font-semibold">Receive Money</p>
                    <p className="text-on-surface-variant text-[11px]">Payment collection &amp; receipt</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setDropdownOpen(false);
                    openTransactionModal('Pay');
                  }}
                  className="w-full flex items-center gap-space-sm px-space-md py-2 text-left text-on-surface hover:bg-surface-container-low transition-colors font-body-sm text-body-sm"
                >
                  <span className="material-symbols-outlined text-error text-[20px]">payments</span>
                  <div>
                    <p className="font-headline-sm text-[13px] font-semibold">Pay Money</p>
                    <p className="text-on-surface-variant text-[11px]">Supplier payout &amp; expenses</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setDropdownOpen(false);
                    openJournalModal();
                  }}
                  className="w-full flex items-center gap-space-sm px-space-md py-2 text-left text-on-surface hover:bg-surface-container-low transition-colors font-body-sm text-body-sm border-t border-surface-container-high/60 mt-1 pt-1.5"
                >
                  <span className="material-symbols-outlined text-tertiary text-[20px]">edit_note</span>
                  <div>
                    <p className="font-headline-sm text-[13px] font-semibold">Journal Entry</p>
                    <p className="text-on-surface-variant text-[11px]">Simple In / Out entry</p>
                  </div>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Filter & Segmentation Control Center */}
      <div className="bg-surface-container-lowest rounded-xl p-space-md shadow-sm mb-space-md flex flex-col gap-space-md border border-surface-container-high/40">
        {/* Top Filter Row: Tabs & Search */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-space-md">
          {/* Transaction Type Segment Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-surface-container-low rounded-lg">
            {[
              { label: 'All Transactions', key: 'All', count: counts.All },
              { label: 'Purchases', key: 'Purchase', count: counts.Purchase },
              { label: 'Sales', key: 'Sale', count: counts.Sale },
              { label: 'Receipts', key: 'Receive', count: counts.Receive },
              { label: 'Payments', key: 'Pay', count: counts.Pay },
              { label: 'Transfers', key: 'Transfer', count: counts.Transfer },
            ].map((tab) => (
              <button
                key={tab.key}
                type="button"
                onClick={() => setSelectedType(tab.key)}
                className={`px-space-sm py-1.5 rounded-lg font-label-md text-label-md flex items-center gap-1.5 transition-all ${
                  selectedType === tab.key
                    ? 'bg-surface-container-lowest font-semibold text-primary shadow-xs'
                    : 'text-on-surface-variant hover:bg-surface-container hover:text-on-surface'
                }`}
              >
                <span>{tab.label}</span>
                <span
                  className={`px-1.5 py-0.2 rounded-full text-[11px] ${
                    selectedType === tab.key
                      ? 'bg-primary/10 text-primary font-bold'
                      : 'bg-surface-container-high text-on-surface-variant'
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            ))}
          </div>

          {/* Quick Search Bar */}
          <div className="relative w-full lg:w-80">
            <span className="material-symbols-outlined absolute left-space-sm top-1/2 -translate-y-1/2 text-on-surface-variant text-[18px]">
              search
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by ID, party, invoice #, note..."
              className="w-full h-10 pl-9 pr-space-md bg-surface-container-low rounded-lg font-body-sm text-body-sm text-on-surface placeholder:text-on-surface-variant focus:outline-none focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary/20 transition-all"
            />
          </div>
        </div>

        {/* Bottom Filter Row: Date Range Buttons & Bank Account Dropdown */}
        <div className="flex flex-wrap items-center justify-between gap-space-sm pt-space-xs">
          {/* Date Range Filter Group */}
          <div className="flex items-center flex-wrap gap-1">
            <span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider mr-2">
              Range:
            </span>
            {(['All', 'Today', 'This Week', 'This Month'] as const).map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => setSelectedDateRange(r)}
                className={`px-space-sm py-1 rounded-md font-label-sm text-label-sm transition-colors ${
                  selectedDateRange === r
                    ? 'bg-primary text-on-primary font-semibold shadow-xs'
                    : 'text-on-surface-variant hover:bg-surface-container'
                }`}
              >
                {r === 'All' ? 'All Dates' : r}
              </button>
            ))}
          </div>

          {/* Bank/Cash Account Filter */}
          <div className="flex items-center gap-space-xs">
            <span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">
              Account:
            </span>
            <div className="relative">
              <select
                value={selectedAccount}
                onChange={(e) => setSelectedAccount(e.target.value)}
                className="h-9 pl-space-sm pr-8 bg-surface-container-low text-on-surface rounded-lg font-body-sm text-body-sm appearance-none focus:outline-none focus:ring-2 focus:ring-primary/20 cursor-pointer"
              >
                <option value="All">All Accounts (Consolidated)</option>
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}
                  </option>
                ))}
              </select>
              <span className="material-symbols-outlined pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-on-surface-variant text-[16px]">
                expand_more
              </span>
            </div>
            <button
              onClick={() => {
                setSelectedType('All');
                setSelectedAccount('All');
                setSelectedDateRange('All');
                setSearchQuery('');
              }}
              className="h-9 w-9 flex items-center justify-center rounded-lg bg-surface-container-low text-on-surface-variant hover:text-on-surface hover:bg-surface-container transition-colors"
              title="Reset Filters"
              type="button"
            >
              <span className="material-symbols-outlined text-[18px]">restart_alt</span>
            </button>
          </div>
        </div>
      </div>

      {/* Accounting Grade Transactions Table Card */}
      <div className="bg-surface-container-lowest rounded-xl shadow-sm overflow-hidden mb-space-lg border border-surface-container-high/40">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-surface-container-low/70 h-10 text-on-surface-variant font-label-sm text-label-sm uppercase tracking-wider">
                <th className="py-2.5 px-space-md font-semibold">Date &amp; Time</th>
                <th className="py-2.5 px-space-md font-semibold">Tx ID / Doc #</th>
                <th className="py-2.5 px-space-sm font-semibold">Type</th>
                <th className="py-2.5 px-space-md font-semibold">Party / Counterparty</th>
                <th className="py-2.5 px-space-md font-semibold">Description / Items</th>
                <th className="py-2.5 px-space-sm font-semibold">Account</th>
                <th className="py-2.5 px-space-md text-right font-semibold">Amount (PKR)</th>
                <th className="py-2.5 px-space-md text-right font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-container-low/60 text-body-md font-body-md text-on-surface">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-on-surface-variant">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <span className="material-symbols-outlined text-[36px] text-on-surface-variant/40">
                        receipt_long
                      </span>
                      <p className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                        No transactions recorded yet
                      </p>
                      <p className="font-body-sm text-body-sm text-on-surface-variant max-w-sm">
                        All transaction totals and balances are at clean zero. Use &quot;Record Transaction&quot; above to log your first sale, purchase, or receipt.
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                filtered.map((tx) => (
                  <tr key={tx.id} className="hover:bg-surface-container-low/40 transition-colors">
                    {/* Date & Time */}
                    <td className="py-3 px-space-md whitespace-nowrap">
                      <div className="flex flex-col">
                        <span className="font-headline-sm text-headline-sm font-semibold text-on-surface">
                          {tx.date}
                        </span>
                        <span className="font-body-sm text-body-sm text-on-surface-variant">{tx.time}</span>
                      </div>
                    </td>

                    {/* Doc # */}
                    <td className="py-3 px-space-md whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => openPdfPreview(tx)}
                        className="inline-flex items-center gap-1.5 font-headline-sm text-[13px] font-semibold text-primary hover:underline hover:opacity-85 tracking-wide cursor-pointer focus:outline-none transition-all"
                        title="Click to view & download PDF"
                      >
                        <span className="material-symbols-outlined text-[15px] opacity-75">picture_as_pdf</span>
                        <span>{tx.docNumber}</span>
                      </button>
                    </td>

                    {/* Type */}
                    <td className="py-3 px-space-sm whitespace-nowrap">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                          tx.type === 'Sale'
                            ? 'bg-primary-container text-on-primary'
                            : tx.type === 'Purchase'
                            ? 'bg-secondary-container text-primary'
                            : tx.type === 'Receive'
                            ? 'bg-tertiary-fixed text-on-tertiary-fixed'
                            : tx.type === 'Pay'
                            ? 'bg-error-container text-on-error-container'
                            : 'bg-surface-container text-primary'
                        }`}
                      >
                        <span className="material-symbols-outlined text-[13px]">
                          {tx.type === 'Sale' || tx.type === 'Receive' ? 'north_east' : 'south_west'}
                        </span>
                        {tx.type}
                      </span>
                    </td>

                    {/* Party or Expense Head */}
                    <td className="py-3 px-space-md">
                      <div className="flex items-center gap-2">
                        {tx.expenseHeadName ? (
                          <>
                            <div className="w-7 h-7 rounded-full bg-error-container text-on-error-container flex items-center justify-center font-bold text-[11px] shrink-0">
                              <span className="material-symbols-outlined text-[15px]">receipt_long</span>
                            </div>
                            <div className="flex flex-col min-w-0">
                              <span className="font-headline-sm text-[13px] font-bold text-on-surface truncate max-w-[180px]">
                                {tx.expenseHeadName}
                              </span>
                              <span className="text-[10px] text-error font-semibold">Expense Head</span>
                            </div>
                          </>
                        ) : (
                          <>
                            <div className="w-7 h-7 rounded-full bg-surface-container-high flex items-center justify-center text-primary font-semibold text-[11px] shrink-0">
                              {(tx.partyName || 'Counter').slice(0, 2).toUpperCase()}
                            </div>
                            <div className="flex flex-col min-w-0">
                              <span className="font-headline-sm text-[13px] font-semibold text-on-surface truncate max-w-[180px]">
                                {tx.partyName || 'Counter Cash Sale'}
                              </span>
                            </div>
                          </>
                        )}
                      </div>
                    </td>

                    {/* Description / Items */}
                    <td className="py-3 px-space-md max-w-xs">
                      <p className="font-body-sm text-body-sm text-on-surface line-clamp-1 font-medium">
                        {tx.items && tx.items.length > 0
                          ? tx.items.map((it) => `${it.productName} × ${it.quantity}`).join(', ')
                          : tx.notes || `${tx.type} entry`}
                      </p>
                      {tx.items && tx.items.length > 0 && tx.notes ? (
                        <p className="font-label-sm text-label-sm text-on-surface-variant truncate">{tx.notes}</p>
                      ) : null}
                    </td>

                    {/* Account */}
                    <td className="py-3 px-space-sm whitespace-nowrap">
                      {tx.type === 'Transfer' ? (
                        <span className="inline-flex items-center gap-1 text-on-surface-variant font-body-sm text-body-sm">
                          <span className="material-symbols-outlined text-[16px] text-tertiary">swap_horiz</span>
                          {tx.accountName?.split(' ')[0] || 'Account'} → {tx.toAccountName?.split(' ')[0] || 'Account'}
                        </span>
                      ) : (tx.paidAmount || 0) > 0 && tx.accountName ? (
                        <span className="inline-flex items-center gap-1 text-on-surface-variant font-body-sm text-body-sm">
                          <span className="material-symbols-outlined text-[16px] text-tertiary">payments</span>
                          {tx.accountName.split(' ')[0]}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-on-surface-variant text-[11px] font-semibold px-2 py-0.5 rounded-md bg-surface-container-low border border-surface-container-high/40">
                          <span className="material-symbols-outlined text-[13px] text-tertiary">credit_card</span>
                          Credit (Udhaar)
                        </span>
                      )}
                    </td>

                    {/* Amount */}
                    <td className="py-3 px-space-md text-right whitespace-nowrap">
                      <span
                        className={`font-metric-md text-metric-md font-bold ${
                          tx.type === 'Sale' || tx.type === 'Receive' ? 'text-tertiary' : 'text-error'
                        }`}
                      >
                        {tx.type === 'Sale' || tx.type === 'Receive' ? '+' : '-'}Rs.{' '}
                        {tx.totalAmount.toLocaleString()}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-space-md text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1 text-on-surface-variant">
                        <button
                          className="p-1 rounded-md hover:bg-surface-container hover:text-primary transition-colors"
                          title="View Document"
                          type="button"
                          onClick={() => openViewTransactionModal(tx)}
                        >
                          <span className="material-symbols-outlined text-[18px]">visibility</span>
                        </button>
                        <button
                          className="p-1 rounded-md hover:bg-surface-container hover:text-primary transition-colors"
                          title="Edit Transaction"
                          type="button"
                          onClick={() => openEditTransactionModal(tx)}
                        >
                          <span className="material-symbols-outlined text-[18px]">edit</span>
                        </button>
                        <button
                          className="p-1 rounded-md hover:bg-error-container hover:text-error transition-colors"
                          title="Delete Transaction (Reverses all ledger effects)"
                          type="button"
                          onClick={() => handleDelete(tx)}
                        >
                          <span className="material-symbols-outlined text-[18px]">delete</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer */}
        <div className="px-space-md py-space-sm bg-surface-container-low flex flex-col sm:flex-row items-center justify-between gap-space-sm border-t border-surface-container-high/40">
          <span className="font-body-sm text-body-sm text-on-surface-variant">
            Showing <span className="font-semibold text-on-surface">{filtered.length}</span> of{' '}
            <span className="font-semibold text-on-surface">{transactions.length}</span> verified audit entries
          </span>
          <span className="font-body-sm text-body-sm text-on-surface-variant">
            Filtered Total Volume:{' '}
            <span className="font-bold text-on-surface">
              Rs. {filtered.reduce((sum, t) => sum + t.totalAmount, 0).toLocaleString()}
            </span>
          </span>
        </div>
      </div>
    </div>
  );
};
