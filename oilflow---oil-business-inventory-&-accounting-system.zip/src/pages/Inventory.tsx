import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { ProductCategory, UnitType, Product } from '../types';
import { ProductLedgerModal } from '../components/modals/ProductLedgerModal';

export const Inventory: React.FC = () => {
  const {
    viewingProductLedgerId,
    products,
    openProductDrawer,
    openProductLedgerModal,
    deleteProduct,
    adjustStock,
    openTransactionModal,
    totalStockValue,
    totalStockUnits,
    searchQuery,
    setSearchQuery,
  } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedUnit, setSelectedUnit] = useState<string>('All');
  const [selectedStockFilter, setSelectedStockFilter] = useState<'All' | 'In Stock' | 'Low Stock' | 'Out of Stock'>('All');
  const [adjustingProduct, setAdjustingProduct] = useState<Product | null>(null);
  const [newStockValue, setNewStockValue] = useState<number>(0);

  // Breakdown statistics
  const drumCount = useMemo(() => {
    return products.filter((p) => p.unit === 'Drum').reduce((s, p) => s + p.currentStock, 0);
  }, [products]);

  const drumLiters = useMemo(() => {
    return products
      .filter((p) => p.unit === 'Drum')
      .reduce((s, p) => s + p.currentStock * p.packingSize, 0);
  }, [products]);

  const retailPackCount = useMemo(() => {
    return products
      .filter((p) => p.unit !== 'Drum')
      .reduce((s, p) => s + p.currentStock, 0);
  }, [products]);

  const lowStockCount = useMemo(() => {
    return products.filter((p) => p.currentStock > 0 && p.currentStock <= p.minAlertThreshold).length;
  }, [products]);

  const outOfStockCount = useMemo(() => {
    return products.filter((p) => p.currentStock === 0).length;
  }, [products]);

  // Bulk Tank Farm Reserve
  const bulkReserveLiters = useMemo(() => {
    return products
      .filter((p) => p.category === 'Base Oils' || p.category === 'Industrial Oils')
      .reduce((s, p) => s + p.currentStock * p.packingSize, 0);
  }, [products]);
  const bulkTankMax = 15000;
  const bulkPercent = Math.min(100, Math.round((bulkReserveLiters / bulkTankMax) * 100));

  // Filtered Products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // Category filter
      if (selectedCategory !== 'All' && p.category !== selectedCategory) return false;
      // Unit filter
      if (selectedUnit !== 'All' && p.unit !== selectedUnit) return false;
      // Stock status filter
      if (selectedStockFilter === 'In Stock' && p.currentStock <= p.minAlertThreshold) return false;
      if (selectedStockFilter === 'Low Stock' && (p.currentStock === 0 || p.currentStock > p.minAlertThreshold)) return false;
      if (selectedStockFilter === 'Out of Stock' && p.currentStock > 0) return false;
      // Search
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchName = p.name.toLowerCase().includes(q);
        const matchGrade = p.grade.toLowerCase().includes(q);
        const matchCat = p.category.toLowerCase().includes(q);
        const matchDesc = p.description?.toLowerCase().includes(q);
        if (!matchName && !matchGrade && !matchCat && !matchDesc) return false;
      }
      return true;
    });
  }, [products, selectedCategory, selectedUnit, selectedStockFilter, searchQuery]);

  const handleOpenAdjust = (p: Product) => {
    setAdjustingProduct(p);
    setNewStockValue(p.currentStock);
  };

  const handleSaveAdjust = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustingProduct) return;
    adjustStock(adjustingProduct.id, newStockValue);
    setAdjustingProduct(null);
  };

  const handleDelete = (p: Product) => {
    if (window.confirm(`Are you sure you want to remove ${p.name} from the catalog?`)) {
      deleteProduct(p.id);
    }
  };

  const handleExportCSV = () => {
    const headers = [
      'Name',
      'Grade',
      'Category',
      'Unit',
      'PackingSize',
      'StockUnits',
      'StockLiters',
      'CostPerUnitPKR',
      'SalePricePerUnitPKR',
      'TotalStockCostValuationPKR',
      'TotalStockSaleValuationPKR',
    ];
    const rows = products.map((p) => [
      p.name,
      p.grade,
      p.category,
      p.unit,
      p.packingSize,
      p.currentStock,
      p.currentStock * p.packingSize,
      p.purchaseCost,
      p.salePrice,
      p.currentStock * p.purchaseCost,
      p.currentStock * p.salePrice,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `OilFlow_Stock_Inventory_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (viewingProductLedgerId) {
    return <ProductLedgerModal />;
  }

  return (
    <div className="flex flex-col w-full pb-space-xl">
      {/* Operational Sub-Header & Strategic Context */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-space-md mb-space-lg">
        <div>
          <div className="flex items-center gap-space-xs mb-1">
            <span className="font-label-sm text-label-sm uppercase tracking-wider text-primary font-semibold">
              Warehouse Operations
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-outline-variant" />
            <span className="font-label-sm text-label-sm text-on-surface-variant font-medium">
              Live stock reconciliation
            </span>
          </div>
          <h1 className="font-headline-lg text-headline-lg text-on-surface font-bold tracking-tight">
            Inventory &amp; Oil Stocks
          </h1>
          <p className="font-body-md text-body-md text-on-surface-variant mt-0.5">
            Manage your bulk oil products, drums, ready packaging sizes, and real-time stock levels.
          </p>
        </div>

        {/* Global Section CTAs */}
        <div className="flex items-center gap-space-sm self-start lg:self-auto">
          <button
            onClick={handleExportCSV}
            className="h-10 px-space-md rounded-lg bg-surface-container-low text-on-surface hover:bg-surface-container-high transition-colors flex items-center gap-space-xs font-label-md text-label-md font-semibold shadow-xs"
            type="button"
          >
            <span className="material-symbols-outlined text-[18px] text-on-surface-variant">file_download</span>
            <span>Export Stock Report</span>
          </button>
          <button
            onClick={() => openProductDrawer()}
            className="h-10 px-space-md rounded-lg bg-primary text-on-primary hover:bg-primary-container transition-colors flex items-center gap-space-xs font-label-md text-label-md font-semibold shadow-sm active:scale-98"
            type="button"
          >
            <span className="material-symbols-outlined text-[20px]">add</span>
            <span>Add Product</span>
          </button>
        </div>
      </div>

      {/* Metric Summary Mini Cards (Bento/4-Grid Desktop) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-space-md mb-space-lg">
        {/* Card 1: Total SKUs */}
        <div className="p-space-md rounded-xl bg-surface-container-lowest shadow-sm flex flex-col justify-between relative overflow-hidden group border border-surface-container-high/40">
          <div className="flex items-center justify-between mb-space-sm">
            <span className="font-label-md text-label-md text-on-surface-variant">Total Product Lines</span>
            <div className="w-9 h-9 rounded-lg bg-secondary-container text-on-secondary-fixed flex items-center justify-center">
              <span className="material-symbols-outlined text-[20px]">category</span>
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-space-xs">
              <span className="font-metric-xl text-metric-xl text-on-surface">{products.length}</span>
              <span className="font-label-md text-label-md text-on-surface-variant">Active SKUs</span>
            </div>
            <div className="mt-space-xs flex items-center gap-1">
              <span className="font-label-sm text-label-sm text-tertiary font-semibold flex items-center">
                <span className="material-symbols-outlined text-[14px]">check_circle</span> Verified
              </span>
              <span className="font-body-sm text-body-sm text-on-surface-variant">in current depot</span>
            </div>
          </div>
        </div>

        {/* Card 2: Drums in Warehouse */}
        <div className="p-space-md rounded-xl bg-surface-container-lowest shadow-sm flex flex-col justify-between relative overflow-hidden border border-surface-container-high/40">
          <div className="flex items-center justify-between mb-space-sm">
            <span className="font-label-md text-label-md text-on-surface-variant">In-Warehouse Drums</span>
            <div className="w-9 h-9 rounded-lg bg-surface-container-low text-primary flex items-center justify-center">
              <span className="material-symbols-outlined text-[20px]">propane_tank</span>
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-space-xs">
              <span className="font-metric-xl text-metric-xl text-on-surface">{drumCount}</span>
              <span className="font-label-md text-label-md text-primary font-semibold">
                ({drumLiters.toLocaleString()} Ltr)
              </span>
            </div>
            <div className="mt-space-xs flex items-center gap-2">
              <div className="w-24 h-1.5 rounded-full bg-surface-container-high overflow-hidden">
                <div className="w-[68%] h-full bg-primary-container rounded-full" />
              </div>
              <span className="font-label-sm text-label-sm text-on-surface-variant">68% Capacity</span>
            </div>
          </div>
        </div>

        {/* Card 3: Packed Retail Units */}
        <div className="p-space-md rounded-xl bg-surface-container-lowest shadow-sm flex flex-col justify-between relative overflow-hidden border border-surface-container-high/40">
          <div className="flex items-center justify-between mb-space-sm">
            <span className="font-label-md text-label-md text-on-surface-variant">Packed Retail Units</span>
            <div className="w-9 h-9 rounded-lg bg-surface-container-low text-secondary flex items-center justify-center">
              <span className="material-symbols-outlined text-[20px]">shelves</span>
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-space-xs">
              <span className="font-metric-xl text-metric-xl text-on-surface">{retailPackCount.toLocaleString()}</span>
              <span className="font-label-md text-label-md text-on-surface-variant">Units</span>
            </div>
            <div className="mt-space-xs flex items-center gap-1 text-on-surface-variant font-body-sm text-body-sm">
              <span>Bottles, Cans &amp; Pails ready</span>
            </div>
          </div>
        </div>

        {/* Card 4: Valuation */}
        <div className="p-space-md rounded-xl bg-surface-container-lowest shadow-sm flex flex-col justify-between relative overflow-hidden border border-surface-container-high/40">
          <div className="flex items-center justify-between mb-space-sm">
            <span className="font-label-md text-label-md text-on-surface-variant">Total Stock Valuation</span>
            <div className="w-9 h-9 rounded-lg bg-surface-container text-tertiary flex items-center justify-center">
              <span className="material-symbols-outlined text-[20px]">payments</span>
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-space-xs">
              <span className="font-metric-xl text-metric-xl text-on-surface">
                Rs. {totalStockValue.toLocaleString()}
              </span>
            </div>
            <div className="mt-space-xs flex items-center gap-space-xs">
              <span className="w-2 h-2 rounded-full bg-tertiary" />
              <span className="font-label-sm text-label-sm text-tertiary font-semibold">Manual Purchase Cost</span>
            </div>
          </div>
        </div>
      </div>

      {/* Terminal Visual Capacity Bar Banner */}
      <div className="mb-space-lg p-space-md rounded-xl bg-surface-container-lowest shadow-sm flex flex-col lg:flex-row items-start lg:items-center justify-between gap-space-md border border-surface-container-high/40">
        <div className="flex items-center gap-space-md min-w-0">
          <div className="w-12 h-12 rounded-lg bg-surface-container-low flex items-center justify-center shrink-0">
            <span className="material-symbols-outlined text-primary text-[28px]">oil_barrel</span>
          </div>
          <div>
            <div className="flex items-center gap-space-xs">
              <h2 className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                Base Bulk Tank Farm (T-01 to T-04)
              </h2>
              <span className={`px-2 py-0.5 rounded-full font-label-sm text-label-sm font-semibold ${
                bulkReserveLiters > 0 ? 'bg-tertiary-fixed text-on-tertiary-fixed' : 'bg-surface-container text-on-surface-variant'
              }`}>
                {bulkReserveLiters > 0 ? 'Normal State' : 'Depot Clean / Zero Stock'}
              </span>
            </div>
            <p className="font-body-sm text-body-sm text-on-surface-variant mt-0.5">
              Real-time volumetric telemetry synced from terminal flow meters and depot drum counts.
            </p>
          </div>
        </div>
        <div className="w-full lg:w-96 flex flex-col gap-1.5 shrink-0">
          <div className="flex justify-between font-label-sm text-label-sm font-semibold">
            <span className="text-on-surface-variant">Total Bulk Oil Reserve</span>
            <span className="text-primary font-bold">
              {bulkReserveLiters.toLocaleString()} / {bulkTankMax.toLocaleString()} Ltr ({bulkPercent}%)
            </span>
          </div>
          <div className="h-3 w-full bg-surface-container-high rounded-full overflow-hidden flex">
            <div
              className="bg-primary h-full rounded-l-full transition-all duration-500"
              style={{ width: `${Math.min(100, bulkPercent)}%` }}
            />
          </div>
          <div className="flex justify-between font-label-sm text-label-sm text-on-surface-variant">
            <span>T-01 &amp; T-02: {bulkReserveLiters.toLocaleString()} L</span>
            <span>Reserve capacity: {(bulkTankMax - bulkReserveLiters).toLocaleString()} L</span>
          </div>
        </div>
      </div>

      {/* Filtration & Search Control Center */}
      <div className="p-space-md rounded-xl bg-surface-container-lowest shadow-sm mb-space-md flex flex-col gap-space-md border border-surface-container-high/40">
        {/* Top Search & Instant Stats */}
        <div className="flex flex-col md:flex-row gap-space-md items-center justify-between">
          <div className="relative w-full md:w-96">
            <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-[20px]">
              search
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by product name, grade, or packaging..."
              className="w-full h-10 pl-10 pr-space-md bg-surface-container-low rounded-lg font-body-md text-body-md text-on-surface placeholder:text-on-surface-variant focus:outline-none focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary/20 transition-all"
            />
          </div>
          <div className="flex items-center gap-space-sm self-end md:self-auto">
            <span className="font-body-sm text-body-sm text-on-surface-variant">
              Viewing {filteredProducts.length} of {products.length} inventory lines
            </span>
          </div>
        </div>

        {/* Segmented Filter Pills */}
        <div className="flex flex-col gap-space-sm pt-space-xs">
          {/* Category Segment */}
          <div className="flex flex-wrap items-center gap-space-xs">
            <span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider font-semibold w-20">
              Category:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {['All', 'Base Oils', 'Engine Oils', 'Gear Oils', 'Greases', 'Industrial Oils'].map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1 rounded-full font-label-md text-label-md transition-colors ${
                    selectedCategory === cat
                      ? 'bg-primary text-on-primary font-semibold shadow-xs'
                      : 'bg-surface-container-low text-on-surface-variant hover:text-on-surface hover:bg-surface-container-high font-medium'
                  }`}
                >
                  {cat === 'All' ? 'All Categories' : cat}
                </button>
              ))}
            </div>
          </div>

          {/* Unit Segment */}
          <div className="flex flex-wrap items-center gap-space-xs">
            <span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider font-semibold w-20">
              Unit:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {[
                { label: 'All Units', value: 'All' },
                { label: 'Drums (200L)', value: 'Drum' },
                { label: 'Bottles (1L)', value: 'Bottle' },
                { label: 'Cans (4L)', value: 'Can' },
                { label: 'Packs (1Kg)', value: 'Kg' },
              ].map((u) => (
                <button
                  key={u.value}
                  type="button"
                  onClick={() => setSelectedUnit(u.value)}
                  className={`px-3 py-1 rounded-full font-label-md text-label-md transition-colors ${
                    selectedUnit === u.value
                      ? 'bg-primary text-on-primary font-semibold shadow-xs'
                      : 'bg-surface-container-low text-on-surface-variant hover:text-on-surface hover:bg-surface-container-high font-medium'
                  }`}
                >
                  {u.label}
                </button>
              ))}
            </div>
          </div>

          {/* Stock Status Segment */}
          <div className="flex flex-wrap items-center gap-space-xs">
            <span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider font-semibold w-20">
              Stock:
            </span>
            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={() => setSelectedStockFilter('All')}
                className={`px-3 py-1 rounded-full font-label-md text-label-md transition-colors ${
                  selectedStockFilter === 'All'
                    ? 'bg-primary text-on-primary font-semibold shadow-xs'
                    : 'bg-surface-container-low text-on-surface-variant hover:text-on-surface hover:bg-surface-container-high font-medium'
                }`}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => setSelectedStockFilter('In Stock')}
                className={`px-3 py-1 rounded-full font-label-md text-label-md transition-colors ${
                  selectedStockFilter === 'In Stock'
                    ? 'bg-primary text-on-primary font-semibold shadow-xs'
                    : 'bg-surface-container-low text-on-surface-variant hover:text-on-surface hover:bg-surface-container-high font-medium'
                }`}
              >
                In Stock
              </button>
              <button
                type="button"
                onClick={() => setSelectedStockFilter('Low Stock')}
                className={`px-3 py-1 rounded-full font-label-md text-label-md transition-colors flex items-center gap-1.5 ${
                  selectedStockFilter === 'Low Stock'
                    ? 'bg-primary text-on-primary font-semibold shadow-xs'
                    : 'bg-surface-container-low text-on-surface-variant hover:text-on-surface hover:bg-surface-container-high font-medium'
                }`}
              >
                <span>Low Stock</span>
                {lowStockCount > 0 && (
                  <span className="w-5 h-5 rounded-full bg-error-container text-on-error-container text-[11px] font-bold flex items-center justify-center">
                    {lowStockCount}
                  </span>
                )}
              </button>
              <button
                type="button"
                onClick={() => setSelectedStockFilter('Out of Stock')}
                className={`px-3 py-1 rounded-full font-label-md text-label-md transition-colors flex items-center gap-1.5 ${
                  selectedStockFilter === 'Out of Stock'
                    ? 'bg-primary text-on-primary font-semibold shadow-xs'
                    : 'bg-surface-container-low text-on-surface-variant hover:text-on-surface hover:bg-surface-container-high font-medium'
                }`}
              >
                <span>Out of Stock</span>
                <span className="w-5 h-5 rounded-full bg-surface-container-high text-on-surface-variant text-[11px] font-bold flex items-center justify-center">
                  {outOfStockCount}
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Primary Inventory Table */}
      <div className="rounded-xl bg-surface-container-lowest shadow-sm overflow-hidden border border-surface-container-high/40">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-surface-container-low h-10 text-on-surface-variant font-label-sm text-label-sm uppercase tracking-wider">
                <th className="px-space-md font-semibold">Product Name &amp; Grade</th>
                <th className="px-space-md font-semibold">Category</th>
                <th className="px-space-md font-semibold">Packaging Size</th>
                <th className="px-space-md font-semibold">Current Stock</th>
                <th className="px-space-md font-semibold text-right">Total Stock Value</th>
                <th className="px-space-md font-semibold text-right">Cost / Unit</th>
                <th className="px-space-md font-semibold text-right">Sale Price</th>
                <th className="px-space-md font-semibold text-right">Margin</th>
                <th className="px-space-md font-semibold">Status</th>
                <th className="px-space-md font-semibold text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-container-low text-body-sm">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-on-surface-variant">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <span className="material-symbols-outlined text-[36px] text-on-surface-variant/40">
                        inventory_2
                      </span>
                      <p className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                        No inventory products yet
                      </p>
                      <p className="font-body-sm text-body-sm text-on-surface-variant max-w-sm">
                        All warehouse stock is at zero. Click &quot;Add New Product&quot; to begin cataloging your oil grades, packaging units, and drum inventory.
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredProducts.map((p) => {
                  const totalVol = p.currentStock * p.packingSize;
                  const itemCostValue = p.currentStock * p.purchaseCost;
                  const itemSaleValue = p.currentStock * p.salePrice;
                  const marginPct =
                    p.purchaseCost > 0
                      ? Math.round(((p.salePrice - p.purchaseCost) / p.purchaseCost) * 1000) / 10
                      : 0;
                  const isLow = p.currentStock > 0 && p.currentStock <= p.minAlertThreshold;
                  const isOut = p.currentStock === 0;

                  return (
                  <tr key={p.id} className="h-16 hover:bg-surface-container-low/60 transition-colors">
                    {/* Name & Grade */}
                    <td className="px-space-md py-space-sm">
                      <div className="flex items-center gap-space-sm">
                        <button
                          type="button"
                          onClick={() => openProductLedgerModal(p.id)}
                          className="w-8 h-8 rounded-lg bg-surface-container hover:bg-primary/10 flex items-center justify-center text-primary shrink-0 transition-colors cursor-pointer"
                          title="Click to view Stock Ledger Report"
                        >
                          <span className="material-symbols-outlined text-[18px]">
                            {p.unit === 'Drum' ? 'water_drop' : p.unit === 'Kg' ? 'layers' : 'speed'}
                          </span>
                        </button>
                        <div className="flex flex-col min-w-0">
                          <button
                            type="button"
                            onClick={() => openProductLedgerModal(p.id)}
                            className="text-left group/name inline-flex items-center gap-1.5 focus:outline-none cursor-pointer"
                            title="Click to view Stock Ledger Report"
                          >
                            <span className="font-headline-sm text-headline-sm text-on-surface font-semibold group-hover/name:text-primary group-hover/name:underline underline-offset-2 transition-colors truncate">
                              {p.name}
                            </span>
                            <span className="material-symbols-outlined text-[16px] text-primary opacity-0 group-hover/name:opacity-100 transition-opacity">
                              receipt_long
                            </span>
                          </button>
                          <span className="font-body-sm text-body-sm text-on-surface-variant truncate">
                            {p.grade} {p.description ? `· ${p.description}` : ''}
                          </span>
                        </div>
                      </div>
                    </td>

                    {/* Category */}
                    <td className="px-space-md py-space-sm whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded bg-surface-container text-on-surface font-label-sm text-label-sm font-medium">
                        {p.category}
                      </span>
                    </td>

                    {/* Packaging Size */}
                    <td className="px-space-md py-space-sm whitespace-nowrap">
                      <span className="font-body-md text-body-md text-on-surface font-medium">
                        {p.packingSize} {p.packingUnit} {p.unit}
                      </span>
                    </td>

                    {/* Current Stock */}
                    <td className="px-space-md py-space-sm whitespace-nowrap">
                      <div className="flex flex-col">
                        <span
                          className={`font-body-md text-body-md font-semibold flex items-center gap-1 ${
                            isOut ? 'text-error' : isLow ? 'text-error' : 'text-on-surface'
                          }`}
                        >
                          {p.currentStock} {p.unit}s
                          {isLow && <span className="material-symbols-outlined text-[14px]">warning</span>}
                        </span>
                        <span className="font-body-sm text-body-sm text-on-surface-variant">
                          {totalVol.toLocaleString()} {p.packingUnit}s total
                        </span>
                        <span className="inline-flex items-center gap-1 mt-0.5 text-[11px] font-bold text-tertiary">
                          <span className="material-symbols-outlined text-[13px]">payments</span>
                          <span>Worth: Rs. {itemCostValue.toLocaleString()}</span>
                        </span>
                      </div>
                    </td>

                    {/* Total Stock Value */}
                    <td className="px-space-md py-space-sm text-right whitespace-nowrap">
                      <div className="flex flex-col items-end">
                        <span className="font-bold text-on-surface text-[14px]">
                          Rs. {itemCostValue.toLocaleString()}
                        </span>
                        <span className="text-[11px] text-on-surface-variant font-medium">
                          Sale: Rs. {itemSaleValue.toLocaleString()}
                        </span>
                      </div>
                    </td>

                    {/* Cost */}
                    <td className="px-space-md py-space-sm text-right whitespace-nowrap font-body-md text-body-md text-on-surface">
                      Rs. {p.purchaseCost.toLocaleString()}
                    </td>

                    {/* Sale Price */}
                    <td className="px-space-md py-space-sm text-right whitespace-nowrap font-body-md text-body-md text-on-surface font-semibold">
                      Rs. {p.salePrice.toLocaleString()}
                    </td>

                    {/* Margin */}
                    <td className="px-space-md py-space-sm text-right whitespace-nowrap">
                      <span className="font-label-md text-label-md text-tertiary font-bold">
                        +{marginPct}%
                      </span>
                    </td>

                    {/* Status badge */}
                    <td className="px-space-md py-space-sm whitespace-nowrap">
                      {isOut ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full font-label-sm text-label-sm font-semibold bg-surface-container-high text-on-surface-variant">
                          <span className="w-1.5 h-1.5 rounded-full bg-outline" />
                          Out of Stock
                        </span>
                      ) : isLow ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full font-label-sm text-label-sm font-semibold bg-error-container text-on-error-container">
                          <span className="w-1.5 h-1.5 rounded-full bg-error" />
                          Low Stock
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full font-label-sm text-label-sm font-semibold bg-tertiary-fixed text-on-tertiary-fixed">
                          <span className="w-1.5 h-1.5 rounded-full bg-tertiary" />
                          In Stock
                        </span>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="px-space-md py-space-sm whitespace-nowrap text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          type="button"
                          onClick={() => openProductLedgerModal(p.id)}
                          className="p-1.5 rounded-lg text-on-surface-variant hover:text-primary hover:bg-surface-container transition-colors"
                          title="View Stock Ledger Report"
                        >
                          <span className="material-symbols-outlined text-[18px]">receipt_long</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => openTransactionModal('Purchase', p.name)}
                          className="p-1.5 rounded-lg text-on-surface-variant hover:text-primary hover:bg-surface-container transition-colors"
                          title="New Purchase of this Product"
                        >
                          <span className="material-symbols-outlined text-[18px]">shopping_cart</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenAdjust(p)}
                          className="p-1.5 rounded-lg text-on-surface-variant hover:text-primary hover:bg-surface-container transition-colors"
                          title="Adjust Stock Balance"
                        >
                          <span className="material-symbols-outlined text-[18px]">tune</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => openProductDrawer(p)}
                          className="p-1.5 rounded-lg text-on-surface-variant hover:text-primary hover:bg-surface-container transition-colors"
                          title="Edit Product"
                        >
                          <span className="material-symbols-outlined text-[18px]">edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(p)}
                          className="p-1.5 rounded-lg text-error hover:bg-error-container transition-colors"
                          title="Delete Product"
                        >
                          <span className="material-symbols-outlined text-[18px]">delete</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              }))}
            </tbody>
          </table>
        </div>

        {/* Table Pagination / Summary Footer */}
        <div className="px-space-md py-space-sm bg-surface-container-low flex flex-col sm:flex-row items-center justify-between gap-space-sm border-t border-surface-container-high/40">
          <div className="font-body-sm text-body-sm text-on-surface-variant">
            {filteredProducts.length === 0 ? (
              <span>Showing 0 of 0 products</span>
            ) : (
              <>
                Showing <span className="font-semibold text-on-surface">1</span> to{' '}
                <span className="font-semibold text-on-surface">{filteredProducts.length}</span> of{' '}
                <span className="font-semibold text-on-surface">{products.length}</span> products
              </>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <span className="font-body-sm text-body-sm text-on-surface-variant">
              Total Volume:{' '}
              <span className="font-bold text-on-surface">
                {filteredProducts.reduce((s, p) => s + p.currentStock * p.packingSize, 0).toLocaleString()} Liters/Kg
              </span>
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-outline-variant hidden sm:inline-block" />
            <span className="font-body-sm text-body-sm text-on-surface-variant">
              Total Stock Worth:{' '}
              <span className="font-bold text-tertiary">
                Rs. {filteredProducts.reduce((s, p) => s + p.currentStock * p.purchaseCost, 0).toLocaleString()}
              </span>
              <span className="text-on-surface-variant text-[11px] ml-1">
                (Sale: Rs. {filteredProducts.reduce((s, p) => s + p.currentStock * p.salePrice, 0).toLocaleString()})
              </span>
            </span>
          </div>
        </div>
      </div>

      {/* Adjust Stock Quick Modal */}
      {adjustingProduct && (
        <div className="fixed inset-0 bg-inverse-surface/40 backdrop-blur-sm z-50 flex items-center justify-center p-space-md animate-in fade-in duration-150">
          <div className="bg-surface-container-lowest w-full max-w-sm rounded-2xl shadow-xl overflow-hidden border border-surface-container-high/60">
            <div className="p-space-md bg-surface-container-low flex items-center justify-between border-b border-surface-container-high/60">
              <h3 className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                Adjust Stock Level
              </h3>
              <button
                type="button"
                onClick={() => setAdjustingProduct(null)}
                className="w-8 h-8 rounded-full hover:bg-surface-container-high flex items-center justify-center text-on-surface-variant"
              >
                <span className="material-symbols-outlined text-[18px]">close</span>
              </button>
            </div>
            <form onSubmit={handleSaveAdjust} className="p-space-md space-y-space-md">
              <div>
                <p className="font-body-md text-body-md font-semibold text-on-surface">
                  {adjustingProduct.name} ({adjustingProduct.grade})
                </p>
                <p className="font-body-sm text-body-sm text-on-surface-variant">
                  Current: {adjustingProduct.currentStock} {adjustingProduct.unit}s
                </p>
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-label-sm text-label-sm text-on-surface font-semibold">
                  New Physical Count ({adjustingProduct.unit}s)
                </label>
                <input
                  type="number"
                  min="0"
                  value={newStockValue === 0 ? '' : newStockValue}
                  placeholder="0"
                  onChange={(e) => setNewStockValue(e.target.value === '' ? 0 : Number(e.target.value))}
                  required
                  className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm font-bold text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>

              <div className="flex items-center justify-end gap-space-sm pt-space-xs">
                <button
                  type="button"
                  onClick={() => setAdjustingProduct(null)}
                  className="px-3 h-9 text-body-sm rounded-lg bg-surface-container text-on-surface"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 h-9 text-body-sm font-semibold rounded-lg bg-primary text-on-primary hover:bg-primary-container"
                >
                  Confirm Adjustment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
