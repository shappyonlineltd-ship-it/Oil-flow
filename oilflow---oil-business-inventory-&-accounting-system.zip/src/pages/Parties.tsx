import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Party } from '../types';
import { PartyLedgerModal } from '../components/modals/PartyLedgerModal';

export const Parties: React.FC = () => {
  const {
    viewingPartyLedgerId,
    parties,
    openPartyModal,
    openPartyLedgerModal,
    openTransactionModal,
    deleteParty,
    totalCustomerReceivables,
    totalSupplierPayables,
    searchQuery,
    setSearchQuery,
  } = useApp();

  const [tabFilter, setTabFilter] = useState<'All' | 'Customer' | 'Supplier'>('All');

  const customerCount = useMemo(() => {
    return parties.filter((p) => p.type === 'Customer' || p.type === 'Both').length;
  }, [parties]);

  const supplierCount = useMemo(() => {
    return parties.filter((p) => p.type === 'Supplier' || p.type === 'Both').length;
  }, [parties]);

  const filteredParties = useMemo(() => {
    return parties.filter((p) => {
      if (tabFilter === 'Customer' && p.type !== 'Customer' && p.type !== 'Both') return false;
      if (tabFilter === 'Supplier' && p.type !== 'Supplier' && p.type !== 'Both') return false;

      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchName = p.name.toLowerCase().includes(q);
        const matchPhone = p.phone.toLowerCase().includes(q);
        const matchCity = p.city.toLowerCase().includes(q);
        const matchAddr = p.address?.toLowerCase().includes(q);
        if (!matchName && !matchPhone && !matchCity && !matchAddr) return false;
      }

      return true;
    });
  }, [parties, tabFilter, searchQuery]);

  const [deleteConfirmParty, setDeleteConfirmParty] = useState<Party | null>(null);

  const handleDelete = (p: Party) => {
    setDeleteConfirmParty(p);
  };

  if (viewingPartyLedgerId) {
    return <PartyLedgerModal />;
  }

  return (
    <div className="flex flex-col w-full pb-space-xl">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-space-md mb-space-lg">
        <div>
          <div className="flex items-center gap-space-xs text-on-surface-variant font-label-sm uppercase tracking-wider mb-1">
            <span>Counterparties</span>
            <span className="material-symbols-outlined text-[14px]">chevron_right</span>
            <span className="text-primary font-semibold">Party Ledgers</span>
          </div>
          <h1 className="font-headline-lg text-headline-lg text-on-surface font-semibold tracking-tight">
            Parties &amp; Client Accounts
          </h1>
          <p className="font-body-md text-body-md text-on-surface-variant mt-0.5">
            Maintain customer receivables, supplier payables, credit terms, and individual transaction statements.
          </p>
        </div>

        <button
          onClick={() => openPartyModal()}
          className="h-10 px-space-md bg-primary text-on-primary hover:bg-primary-container transition-colors rounded-lg flex items-center gap-space-xs font-label-md text-label-md font-semibold shadow-sm self-start md:self-auto active:scale-98"
          type="button"
        >
          <span className="material-symbols-outlined text-[20px]">person_add</span>
          <span>Add New Party</span>
        </button>
      </div>

      {/* Summary Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-space-md mb-space-lg">
        {/* Card 1 */}
        <div className="bg-surface-container-lowest p-space-md rounded-xl shadow-sm flex items-center justify-between border border-surface-container-high/40">
          <div>
            <span className="font-label-sm text-label-sm text-on-surface-variant uppercase font-semibold block">
              Total Customers
            </span>
            <span className="font-metric-xl text-metric-xl text-on-surface font-bold block mt-1">
              {customerCount}
            </span>
            <span className="text-[12px] text-tertiary font-medium">Active buyers &amp; workshops</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-tertiary-fixed/40 text-tertiary flex items-center justify-center">
            <span className="material-symbols-outlined text-[22px]">store</span>
          </div>
        </div>

        {/* Card 2 */}
        <div className="bg-surface-container-lowest p-space-md rounded-xl shadow-sm flex items-center justify-between border border-surface-container-high/40">
          <div>
            <span className="font-label-sm text-label-sm text-on-surface-variant uppercase font-semibold block">
              Total Suppliers
            </span>
            <span className="font-metric-xl text-metric-xl text-on-surface font-bold block mt-1">
              {supplierCount}
            </span>
            <span className="text-[12px] text-secondary font-medium">Refineries &amp; bulk depots</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-secondary-container text-on-secondary-fixed flex items-center justify-center">
            <span className="material-symbols-outlined text-[22px]">factory</span>
          </div>
        </div>

        {/* Card 3 */}
        <div className="bg-surface-container-lowest p-space-md rounded-xl shadow-sm flex items-center justify-between border border-surface-container-high/40">
          <div>
            <span className="font-label-sm text-label-sm text-on-surface-variant uppercase font-semibold block">
              Customer Receivables
            </span>
            <span className="font-metric-xl text-metric-xl text-tertiary font-bold block mt-1">
              Rs. {totalCustomerReceivables.toLocaleString()}
            </span>
            <span className="text-[12px] text-on-surface-variant">Uncollected money</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-tertiary-fixed text-on-tertiary-fixed flex items-center justify-center">
            <span className="material-symbols-outlined text-[22px]">arrow_downward_alt</span>
          </div>
        </div>

        {/* Card 4 */}
        <div className="bg-surface-container-lowest p-space-md rounded-xl shadow-sm flex items-center justify-between border border-surface-container-high/40">
          <div>
            <span className="font-label-sm text-label-sm text-on-surface-variant uppercase font-semibold block">
              Supplier Payables
            </span>
            <span className="font-metric-xl text-metric-xl text-error font-bold block mt-1">
              Rs. {totalSupplierPayables.toLocaleString()}
            </span>
            <span className="text-[12px] text-on-surface-variant">Outstanding bills to pay</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-error-container text-on-error-container flex items-center justify-center">
            <span className="material-symbols-outlined text-[22px]">arrow_upward_alt</span>
          </div>
        </div>
      </div>

      {/* Control Strip */}
      <div className="bg-surface-container-lowest p-space-md rounded-xl shadow-sm mb-space-md flex flex-col sm:flex-row items-center justify-between gap-space-md border border-surface-container-high/40">
        <div className="flex items-center gap-1.5 p-1 bg-surface-container-low rounded-lg w-full sm:w-auto">
          {(['All', 'Customer', 'Supplier'] as const).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTabFilter(t)}
              className={`flex-1 sm:flex-initial px-4 py-1.5 rounded-lg font-label-md text-label-md font-semibold transition-all ${
                tabFilter === t
                  ? 'bg-surface-container-lowest text-primary shadow-xs'
                  : 'text-on-surface-variant hover:text-on-surface hover:bg-surface-container'
              }`}
            >
              {t === 'All' ? 'All Counterparties' : t === 'Customer' ? 'Customers' : 'Suppliers'}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-80">
          <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-[18px]">
            search
          </span>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search party by name, phone, city..."
            className="w-full h-10 pl-9 pr-space-md bg-surface-container-low rounded-lg font-body-sm text-body-sm text-on-surface placeholder:text-on-surface-variant focus:outline-none focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary/20 transition-all"
          />
        </div>
      </div>

      {/* Parties Table */}
      <div className="bg-surface-container-lowest rounded-xl shadow-sm overflow-hidden border border-surface-container-high/40">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-surface-container-low h-10 text-on-surface-variant font-label-sm text-label-sm uppercase tracking-wider">
                <th className="py-2.5 px-space-md font-semibold">Party / Business Name</th>
                <th className="py-2.5 px-space-md font-semibold">Type</th>
                <th className="py-2.5 px-space-md font-semibold">Phone / WhatsApp</th>
                <th className="py-2.5 px-space-md font-semibold">Station / City</th>
                <th className="py-2.5 px-space-md text-right font-semibold">Current Balance (PKR)</th>
                <th className="py-2.5 px-space-md text-right font-semibold">Credit Limit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-surface-container-low text-body-sm">
              {filteredParties.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-on-surface-variant">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <span className="material-symbols-outlined text-[36px] text-on-surface-variant/40">
                        group
                      </span>
                      <p className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                        No counterparties registered yet
                      </p>
                      <p className="font-body-sm text-body-sm text-on-surface-variant max-w-sm">
                        All party ledger balances are at zero. Click &quot;Add New Party&quot; above to register customers, oil dealers, and supply refineries.
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredParties.map((p) => {
                  const isReceivable = p.currentBalance > 0;
                  const isPayable = p.currentBalance < 0;

                  return (
                  <tr key={p.id} className="hover:bg-surface-container-low/40 transition-colors h-16">
                    <td className="py-3 px-space-md">
                      <div className="flex items-center gap-space-sm">
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              openPartyModal(p);
                            }}
                            className="p-1.5 rounded-lg text-on-surface-variant hover:text-primary hover:bg-surface-container transition-colors"
                            title="Edit Party Profile"
                            aria-label="Edit Party"
                          >
                            <span className="material-symbols-outlined text-[18px]">edit</span>
                          </button>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDelete(p);
                            }}
                            className="p-1.5 rounded-lg text-on-surface-variant hover:text-error hover:bg-error-container/40 transition-colors"
                            title="Delete Party Record"
                            aria-label="Delete Party"
                          >
                            <span className="material-symbols-outlined text-[18px]">delete</span>
                          </button>
                        </div>
                        <div className="flex flex-col min-w-0">
                          <span
                            onClick={() => openPartyLedgerModal(p.id)}
                            className="font-headline-sm text-headline-sm font-semibold text-on-surface hover:text-primary cursor-pointer truncate"
                          >
                            {p.name}
                          </span>
                          <span className="font-body-sm text-body-sm text-on-surface-variant truncate">
                            {p.address}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-space-md whitespace-nowrap">
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                          p.type === 'Customer'
                            ? 'bg-secondary-container text-on-secondary-fixed'
                            : p.type === 'Supplier'
                            ? 'bg-surface-container-high text-primary'
                            : 'bg-primary-container text-on-primary'
                        }`}
                      >
                        {p.type}
                      </span>
                    </td>

                    <td className="py-3 px-space-md whitespace-nowrap font-mono text-on-surface">
                      {p.phone || '-'}
                    </td>

                    <td className="py-3 px-space-md whitespace-nowrap text-on-surface">
                      {p.city}
                    </td>

                    <td className="py-3 px-space-md text-right whitespace-nowrap">
                      <div className="flex flex-col items-end">
                        <span
                          className={`font-metric-md text-metric-md font-bold ${
                            isReceivable ? 'text-tertiary' : isPayable ? 'text-error' : 'text-on-surface-variant'
                          }`}
                        >
                          {isReceivable ? '+' : isPayable ? '-' : ''}Rs.{' '}
                          {Math.abs(p.currentBalance).toLocaleString()}
                        </span>
                        <span className="text-[10px] text-on-surface-variant font-medium">
                          {isReceivable ? 'Receivable' : isPayable ? 'Payable' : 'Zero Balance'}
                        </span>
                      </div>
                    </td>

                    <td className="py-3 px-space-md text-right whitespace-nowrap font-medium text-on-surface">
                      {p.creditLimit ? `Rs. ${p.creditLimit.toLocaleString()}` : '-'}
                    </td>
                  </tr>
                );
              }))}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="px-space-md py-space-sm bg-surface-container-low flex items-center justify-between border-t border-surface-container-high/40">
          <span className="font-body-sm text-body-sm text-on-surface-variant">
            Displaying {filteredParties.length} registered parties
          </span>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmParty && (
        <div className="fixed inset-0 bg-inverse-surface/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-surface-container-lowest max-w-sm w-full rounded-2xl p-space-lg shadow-2xl border border-surface-container-high/60">
            <div className="w-12 h-12 rounded-full bg-error-container text-on-error-container flex items-center justify-center mx-auto mb-3">
              <span className="material-symbols-outlined text-[26px]">delete</span>
            </div>
            <h3 className="font-headline-sm text-headline-sm font-semibold text-on-surface text-center mb-1">
              Delete Party Record?
            </h3>
            <p className="font-body-sm text-body-sm text-on-surface-variant text-center mb-6">
              Are you sure you want to remove <span className="font-semibold text-on-surface">{deleteConfirmParty.name}</span> from the registered parties? This action cannot be undone.
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmParty(null)}
                className="flex-1 h-10 rounded-lg bg-surface-container hover:bg-surface-container-high text-on-surface font-label-md text-label-md font-semibold transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteParty(deleteConfirmParty.id);
                  setDeleteConfirmParty(null);
                }}
                className="flex-1 h-10 rounded-lg bg-error hover:bg-error/90 text-on-error font-label-md text-label-md font-semibold transition-colors shadow-sm"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
