import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { TransactionType } from '../types';

export const Dashboard: React.FC = () => {
  const {
    totalCash,
    totalBank,
    totalStockUnits,
    totalStockVolumeLiters,
    totalStockValue,
    totalCustomerReceivables,
    totalSupplierPayables,
    todayCashIn,
    todayCashOut,
    todayNetCash,
    transactions,
    products,
    parties,
    accounts,
    openTransactionModal,
    openViewTransactionModal,
    setActiveTab,
    searchQuery,
    settings,
  } = useApp();

  const [filterType, setFilterType] = useState<string>('All');

  // Filter transactions based on global search and local filter
  const filteredTransactions = transactions.filter((tx) => {
    if (filterType !== 'All' && tx.type !== filterType) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matchDoc = tx.docNumber.toLowerCase().includes(q);
      const matchParty = tx.partyName?.toLowerCase().includes(q);
      const matchNotes = tx.notes?.toLowerCase().includes(q);
      const matchItem = tx.items.some((i) => i.productName.toLowerCase().includes(q));
      if (!matchDoc && !matchParty && !matchNotes && !matchItem) return false;
    }
    return true;
  });

  // Recent 5
  const recentTransactions = filteredTransactions.slice(0, 5);

  // Low stock products for alerts
  const lowStockItems = products.filter((p) => p.currentStock <= p.minAlertThreshold);

  const customerCount = parties.filter((p) => p.type === 'Customer' || p.type === 'Both').length;
  const supplierCount = parties.filter((p) => p.type === 'Supplier' || p.type === 'Both').length;

  return (
    <div className="flex flex-col w-full pb-margin-lg">
      {/* Top Greeting & Operational Status Strip */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-space-md mb-space-lg pt-space-xs">
        <div className="flex flex-col">
          <div className="flex items-center gap-space-xs mb-1">
            <span className="w-2 h-2 rounded-full bg-tertiary animate-pulse" />
            <span className="font-label-sm text-label-sm uppercase tracking-wider text-tertiary font-semibold">
              Live Operational Status: Active Depot ({settings.depotName || 'Lahore Main Depot'})
            </span>
          </div>
          <h1 className="font-display-lg text-display-lg text-on-surface tracking-tight">
            Welcome back, {settings.ownerName || 'Muhammad Tariq'}
          </h1>
          <p className="font-body-md text-body-md text-on-surface-variant">
            Here is your live oil inventory, cash balances, and counterparty ledger summary for today.
          </p>
        </div>
      </div>

      {/* 1. Six Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-gutter mb-space-lg">
        {/* Card 1: Cash in Hand */}
        <div className="bg-surface-container-lowest rounded-xl p-space-md shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between border border-surface-container-high/40">
          <div className="flex items-center justify-between mb-space-sm">
            <span className="font-label-md text-label-md text-on-surface-variant">Cash in Hand</span>
            <span className="w-7 h-7 rounded-lg bg-tertiary-fixed/40 text-tertiary flex items-center justify-center">
              <span className="material-symbols-outlined text-[18px]">payments</span>
            </span>
          </div>
          <div className="flex flex-col">
            <div className="font-metric-xl text-metric-xl text-on-surface tracking-tight">
              Rs. {totalCash.toLocaleString()}
            </div>
            <div className="flex items-center gap-1 mt-1">
              <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-semibold bg-tertiary-fixed text-on-tertiary-fixed">
                Liquid Safe
              </span>
              <span className="font-body-sm text-body-sm text-on-surface-variant">In Vault</span>
            </div>
          </div>
        </div>

        {/* Card 2: Bank Balance */}
        <div className="bg-surface-container-lowest rounded-xl p-space-md shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between border border-surface-container-high/40">
          <div className="flex items-center justify-between mb-space-sm">
            <span className="font-label-md text-label-md text-on-surface-variant">Bank Balance</span>
            <span className="w-7 h-7 rounded-lg bg-primary-fixed text-primary flex items-center justify-center">
              <span className="material-symbols-outlined text-[18px]">account_balance</span>
            </span>
          </div>
          <div className="flex flex-col">
            <div className="font-metric-xl text-metric-xl text-on-surface tracking-tight">
              Rs. {totalBank.toLocaleString()}
            </div>
            <div className="font-body-sm text-body-sm text-on-surface-variant truncate mt-1">
              {accounts.filter((a) => a.type === 'Bank').length > 0
                ? accounts
                    .filter((a) => a.type === 'Bank')
                    .map((a) => `${a.bankName || a.name}: Rs. ${a.balance.toLocaleString()}`)
                    .join(' | ')
                : 'No bank accounts'}
            </div>
          </div>
        </div>

        {/* Card 3: Total Stock */}
        <div className="bg-surface-container-lowest rounded-xl p-space-md shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between border border-surface-container-high/40">
          <div className="flex items-center justify-between mb-space-sm">
            <span className="font-label-md text-label-md text-on-surface-variant">Total Stock</span>
            <span className="w-7 h-7 rounded-lg bg-secondary-container text-on-secondary-container flex items-center justify-center">
              <span className="material-symbols-outlined text-[18px]">inventory_2</span>
            </span>
          </div>
          <div className="flex flex-col">
            <div className="font-metric-xl text-metric-xl text-on-surface tracking-tight">
              {totalStockUnits.toLocaleString()}{' '}
              <span className="font-headline-sm text-headline-sm text-on-surface-variant font-normal">Units</span>
            </div>
            <div className="font-body-sm text-body-sm text-on-surface-variant mt-1">
              {totalStockVolumeLiters.toLocaleString()} Ltr/Kg equiv.
            </div>
          </div>
        </div>

        {/* Card 4: Stock Value */}
        <div className="bg-surface-container-lowest rounded-xl p-space-md shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between border border-surface-container-high/40">
          <div className="flex items-center justify-between mb-space-sm">
            <span className="font-label-md text-label-md text-on-surface-variant">Stock Value</span>
            <span className="w-7 h-7 rounded-lg bg-surface-container-high text-primary flex items-center justify-center">
              <span className="material-symbols-outlined text-[18px]">price_change</span>
            </span>
          </div>
          <div className="flex flex-col">
            <div className="font-metric-xl text-metric-xl text-on-surface tracking-tight">
              Rs. {totalStockValue.toLocaleString()}
            </div>
            <div className="font-body-sm text-body-sm text-on-surface-variant mt-1">
              Manual purchase cost
            </div>
          </div>
        </div>

        {/* Card 5: Customer Receivables */}
        <div className="bg-surface-container-lowest rounded-xl p-space-md shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between border border-surface-container-high/40">
          <div className="flex items-center justify-between mb-space-sm">
            <span className="font-label-md text-label-md text-on-surface-variant">Customer Receivables</span>
            <span className="w-7 h-7 rounded-lg bg-surface-container text-primary flex items-center justify-center">
              <span className="material-symbols-outlined text-[18px]">arrow_downward_alt</span>
            </span>
          </div>
          <div className="flex flex-col">
            <div className="font-metric-xl text-metric-xl text-tertiary tracking-tight">
              Rs. {totalCustomerReceivables.toLocaleString()}
            </div>
            <div className="flex items-center gap-1 mt-1">
              <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-semibold bg-surface-container-high text-on-surface-variant">
                Pending
              </span>
              <span className="font-body-sm text-body-sm text-on-surface-variant">
                {customerCount} customers
              </span>
            </div>
          </div>
        </div>

        {/* Card 6: Supplier Payables */}
        <div className="bg-surface-container-lowest rounded-xl p-space-md shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between border border-surface-container-high/40">
          <div className="flex items-center justify-between mb-space-sm">
            <span className="font-label-md text-label-md text-on-surface-variant">Supplier Payables</span>
            <span className="w-7 h-7 rounded-lg bg-error-container text-on-error-container flex items-center justify-center">
              <span className="material-symbols-outlined text-[18px]">arrow_upward_alt</span>
            </span>
          </div>
          <div className="flex flex-col">
            <div className="font-metric-xl text-metric-xl text-error tracking-tight">
              Rs. {totalSupplierPayables.toLocaleString()}
            </div>
            <div className="flex items-center gap-1 mt-1">
              <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-semibold bg-error-container text-on-error-container">
                Due Soon
              </span>
              <span className="font-body-sm text-body-sm text-on-surface-variant">
                {supplierCount} suppliers
              </span>
            </div>
          </div>
        </div>
      </div>



      {/* 3. Two-Column Main Operations Desk */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter items-start">
        {/* Left 8/12: Recent Transactions Registry */}
        <div className="lg:col-span-8 flex flex-col gap-space-md">
          <div className="bg-surface-container-lowest rounded-xl shadow-sm overflow-hidden border border-surface-container-high/40">
            <div className="p-space-md flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm bg-surface-container-lowest border-b border-surface-container-low">
              <div className="flex items-center gap-space-sm">
                <div className="w-3 h-3 rounded-full bg-primary-container" />
                <h2 className="font-headline-md text-headline-md text-on-surface">Recent Transactions</h2>
                <span className="px-2 py-0.5 rounded-full text-[11px] bg-surface-container text-on-surface-variant font-medium">
                  Live Audit Log
                </span>
              </div>
              <div className="flex items-center gap-space-xs">
                {/* Filter pill dropdown */}
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                  className="px-2.5 py-1.5 text-body-sm font-label-md rounded-lg bg-surface-container-low text-on-surface hover:bg-surface-container transition-colors border-none focus:outline-none"
                >
                  <option value="All">All Types</option>
                  <option value="Sale">Sales</option>
                  <option value="Purchase">Purchases</option>
                  <option value="Receive">Receipts</option>
                  <option value="Pay">Payments</option>
                  <option value="Transfer">Transfers</option>
                </select>
                <button
                  onClick={() => setActiveTab('transactions')}
                  className="px-3 py-1.5 text-body-sm font-label-md rounded-lg bg-surface-container-low text-on-surface hover:bg-surface-container transition-colors flex items-center gap-1"
                  type="button"
                >
                  <span className="material-symbols-outlined text-[16px]">visibility</span> View All
                </button>
              </div>
            </div>

            {/* Table Viewport */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-surface-container-low text-on-surface-variant font-label-sm text-label-sm uppercase tracking-wider">
                    <th className="py-2.5 px-space-md">Date / Trx #</th>
                    <th className="py-2.5 px-space-md">Party &amp; Item Details</th>
                    <th className="py-2.5 px-space-md">Category</th>
                    <th className="py-2.5 px-space-md text-right">Amount (PKR)</th>
                    <th className="py-2.5 px-space-md text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-surface-container-low text-body-sm">
                  {recentTransactions.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-12 text-center text-on-surface-variant">
                        <div className="flex flex-col items-center justify-center gap-2">
                          <span className="material-symbols-outlined text-[36px] text-on-surface-variant/40">
                            receipt_long
                          </span>
                          <p className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                            No transactions recorded yet
                          </p>
                          <p className="font-body-sm text-body-sm text-on-surface-variant max-w-sm">
                            The system is at a clean zero-testing state. Use Quick Actions above to record your first sale, purchase, or deposit.
                          </p>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    recentTransactions.map((tx) => (
                      <tr key={tx.id} className="hover:bg-surface-container-low/60 transition-colors">
                      <td className="py-3 px-space-md align-top whitespace-nowrap">
                        <div className="font-medium text-on-surface">{tx.date}</div>
                        <div className="font-mono text-label-sm text-primary font-semibold">{tx.docNumber}</div>
                      </td>
                      <td className="py-3 px-space-md align-top">
                        <div className="font-semibold text-on-surface flex items-center gap-1.5">
                          {tx.expenseHeadName ? (
                            <>
                              <span className="material-symbols-outlined text-[15px] text-error">receipt_long</span>
                              <span className="text-error font-bold">{tx.expenseHeadName}</span>
                            </>
                          ) : (
                            tx.partyName || 'Counter Sale'
                          )}
                        </div>
                        <div className="text-on-surface-variant text-[12px] truncate max-w-xs">
                          {tx.items && tx.items.length > 0
                            ? tx.items.map((it) => `${it.productName} × ${it.quantity}`).join(', ')
                            : tx.notes || `${tx.type} settlement`}
                        </div>
                      </td>
                      <td className="py-3 px-space-md align-top whitespace-nowrap">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold ${
                            tx.type === 'Sale'
                              ? 'bg-tertiary-fixed text-on-tertiary-fixed'
                              : tx.type === 'Purchase'
                              ? 'bg-primary-fixed text-on-primary-fixed'
                              : tx.type === 'Receive'
                              ? 'bg-surface-container-high text-primary'
                              : tx.type === 'Pay'
                              ? 'bg-error-container text-on-error-container'
                              : 'bg-surface-container text-primary'
                          }`}
                        >
                          {tx.type}
                        </span>
                      </td>
                      <td
                        className={`py-3 px-space-md align-top text-right font-metric-md text-metric-md whitespace-nowrap ${
                          tx.type === 'Sale' || tx.type === 'Receive' ? 'text-tertiary' : 'text-error'
                        }`}
                      >
                        {tx.type === 'Sale' || tx.type === 'Receive' ? '+' : '-'}Rs.{' '}
                        {tx.totalAmount.toLocaleString()}
                      </td>
                      <td className="py-3 px-space-md align-top text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            className="p-1.5 rounded-lg text-on-surface-variant hover:text-primary hover:bg-surface-container transition-colors"
                            title="View Document"
                            type="button"
                            onClick={() => openViewTransactionModal(tx)}
                          >
                            <span className="material-symbols-outlined text-[18px]">receipt_long</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
              </table>
            </div>

            <div className="p-space-md bg-surface-container-low/30 flex items-center justify-between border-t border-surface-container-low">
              <span className="font-body-sm text-body-sm text-on-surface-variant">
                Showing latest {recentTransactions.length} of {transactions.length} entries across all active accounts
              </span>
              <button
                onClick={() => setActiveTab('transactions')}
                className="font-label-md text-label-md text-primary font-semibold hover:underline inline-flex items-center gap-1"
                type="button"
              >
                Open Full Ledger <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right 4/12: Alerts, Oil Tank Gauges & Cash Register */}
        <div className="lg:col-span-4 flex flex-col gap-space-md">
          {/* Fast Daily Cash Register Summary */}
          <div className="bg-surface-container-lowest rounded-xl p-space-md shadow-sm border border-surface-container-high/40">
            <div className="flex items-center justify-between mb-space-sm">
              <div className="flex items-center gap-space-xs">
                <span className="material-symbols-outlined text-tertiary text-[20px]">account_balance_wallet</span>
                <h3 className="font-headline-sm text-headline-sm text-on-surface">Today's Cash Desk</h3>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-tertiary-fixed/30 text-tertiary">
                Real-time
              </span>
            </div>
            <div className="flex flex-col gap-space-xs bg-surface-container-low p-space-sm rounded-lg mb-space-sm">
              <div className="flex justify-between items-center text-body-sm">
                <span className="text-on-surface-variant flex items-center gap-1">
                  <span className="material-symbols-outlined text-[14px] text-tertiary">add_circle</span> Today's
                  Cash In:
                </span>
                <span className="font-semibold text-tertiary">Rs. {todayCashIn.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-body-sm">
                <span className="text-on-surface-variant flex items-center gap-1">
                  <span className="material-symbols-outlined text-[14px] text-error">remove_circle</span> Today's
                  Cash Out:
                </span>
                <span className="font-semibold text-error">Rs. {todayCashOut.toLocaleString()}</span>
              </div>
              <div className="pt-space-xs mt-space-xs flex justify-between items-center bg-surface-container-lowest p-space-xs rounded border border-surface-container-high/40">
                <span className="font-label-md text-label-md text-on-surface font-semibold">Net Movement:</span>
                <span
                  className={`font-metric-md text-metric-md ${
                    todayNetCash >= 0 ? 'text-tertiary' : 'text-error'
                  }`}
                >
                  {todayNetCash >= 0 ? '+' : '-'}Rs. {Math.abs(todayNetCash).toLocaleString()}
                </span>
              </div>
            </div>
            <p className="font-body-sm text-body-sm text-on-surface-variant text-center">
              Desk Cash verified · Safe Vault Balance: Rs. {totalCash.toLocaleString()}
            </p>
          </div>



          {/* Low Stock Alerts Box with 1-Click Reorder Trigger */}
          <div className="bg-surface-container-lowest rounded-xl p-space-md shadow-sm border border-surface-container-high/40">
            <div className="flex items-center justify-between mb-space-sm">
              <div className="flex items-center gap-space-xs">
                <span className="material-symbols-outlined text-error text-[20px]">warning</span>
                <h3 className="font-headline-sm text-headline-sm text-on-surface">Low Stock Warning</h3>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-error-container text-on-error-container">
                {lowStockItems.length} Alerts
              </span>
            </div>
            <div className="flex flex-col gap-space-sm">
              {lowStockItems.length === 0 ? (
                <div className="p-3 bg-surface-container-low rounded-lg text-center text-[12px] text-on-surface-variant">
                  All warehouse items meet minimum safety reserves.
                </div>
              ) : (
                lowStockItems.slice(0, 3).map((item) => (
                  <div
                    key={item.id}
                    className="p-space-sm bg-surface-container-low rounded-lg flex items-center justify-between gap-space-sm"
                  >
                    <div className="flex flex-col min-w-0">
                      <span className="font-semibold text-on-surface truncate text-body-sm">
                        {item.name} ({item.packingSize}L {item.unit})
                      </span>
                      <div className="flex items-center gap-1 text-[12px] text-error font-medium">
                        <span className="material-symbols-outlined text-[14px]">error</span>
                        <span>
                          Only {item.currentStock} {item.unit}s left
                        </span>
                        <span className="text-on-surface-variant font-normal">
                          (Min: {item.minAlertThreshold})
                        </span>
                      </div>
                    </div>
                    <button
                      className="px-2.5 py-1.5 rounded bg-primary-container text-on-primary font-label-sm text-[12px] font-semibold hover:bg-primary transition-colors whitespace-nowrap active:scale-95 shadow-xs"
                      onClick={() => openTransactionModal('Purchase', item.name)}
                      type="button"
                    >
                      Reorder
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
