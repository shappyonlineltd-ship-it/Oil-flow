import React, { useState } from 'react';
import { useApp } from '../context/AppContext';

export const Settings: React.FC = () => {
  const {
    settings,
    updateSettings,
    resetAllData,
  } = useApp();

  // Business profile state
  const [businessName, setBusinessName] = useState(settings.businessName || 'Tariq Oil Traders');
  const [depotName, setDepotName] = useState(settings.depotName || 'Lahore Main Depot');
  const [ownerName, setOwnerName] = useState(settings.ownerName || 'Muhammad Tariq');
  const [currencySymbol, setCurrencySymbol] = useState(settings.currencySymbol || 'Rs.');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveBusinessProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      businessName,
      depotName,
      ownerName,
      currencySymbol,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="flex flex-col w-full pb-space-xl space-y-space-lg">
      {/* Header */}
      <div>
        <div className="flex items-center gap-space-xs text-on-surface-variant font-label-sm uppercase tracking-wider mb-1">
          <span>System Settings</span>
          <span className="material-symbols-outlined text-[14px]">chevron_right</span>
          <span className="text-primary font-semibold">Business Profile &amp; Preferences</span>
        </div>
        <h1 className="font-headline-lg text-headline-lg text-on-surface font-semibold tracking-tight">
          Settings &amp; Preferences
        </h1>
        <p className="font-body-md text-body-md text-on-surface-variant mt-0.5">
          Configure your business profile, depot location, invoice headers, and terminal preferences.
        </p>
      </div>

      {savedSuccess && (
        <div className="p-space-sm rounded-xl bg-tertiary-fixed/30 text-tertiary border border-tertiary-fixed text-body-sm flex items-center gap-2">
          <span className="material-symbols-outlined text-[18px]">check_circle</span>
          <span className="font-semibold">Business profile preferences saved successfully!</span>
        </div>
      )}

      {/* 1. Business Terminal & Depot Profile Settings */}
      <div className="bg-surface-container-lowest rounded-2xl p-space-md sm:p-space-lg shadow-sm border border-surface-container-high/60">
        <div className="flex items-center gap-space-sm border-b border-surface-container-low pb-space-md mb-space-md">
          <div className="w-10 h-10 rounded-xl bg-primary-fixed text-primary flex items-center justify-center font-bold shadow-xs">
            <span className="material-symbols-outlined text-[24px]">storefront</span>
          </div>
          <div>
            <h2 className="font-headline-sm text-headline-sm font-semibold text-on-surface">
              Business Terminal &amp; Depot Profile
            </h2>
            <p className="font-body-sm text-body-sm text-on-surface-variant">
              Invoicing headers and warehouse station preferences
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveBusinessProfile} className="space-y-space-md">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-space-md">
            <div className="flex flex-col gap-1">
              <label className="font-label-sm text-label-sm text-on-surface font-semibold">
                Business Title
              </label>
              <input
                type="text"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder="e.g. Tariq Oil Traders"
                className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm font-medium text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20 border border-outline/10"
              />
            </div>

            <div className="flex flex-col gap-1">
              <label className="font-label-sm text-label-sm text-on-surface font-semibold">
                Warehouse / Terminal Depot Location
              </label>
              <input
                type="text"
                value={depotName}
                onChange={(e) => setDepotName(e.target.value)}
                placeholder="e.g. Lahore Main Depot"
                className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm font-medium text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20 border border-outline/10"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-space-md">
            <div className="flex flex-col gap-1">
              <label className="font-label-sm text-label-sm text-on-surface font-semibold">
                Owner / Managing Operator
              </label>
              <input
                type="text"
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                placeholder="e.g. Muhammad Tariq"
                className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm font-medium text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20 border border-outline/10"
              />
            </div>

            <div className="flex flex-col gap-1">
              <label className="font-label-sm text-label-sm text-on-surface font-semibold">
                Accounting Currency Symbol
              </label>
              <input
                type="text"
                value={currencySymbol}
                onChange={(e) => setCurrencySymbol(e.target.value)}
                placeholder="Rs."
                className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm font-medium text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20 border border-outline/10"
              />
            </div>
          </div>

          <div className="pt-space-xs flex justify-end">
            <button
              type="submit"
              className="h-10 px-space-lg bg-primary text-on-primary hover:bg-primary-container rounded-lg font-label-md text-label-md font-semibold transition-colors shadow-sm active:scale-98 cursor-pointer"
            >
              Save Profile Preferences
            </button>
          </div>
        </form>
      </div>

      {/* 2. Testing & Data Reset State */}
      <div className="bg-surface-container-lowest rounded-2xl p-space-md sm:p-space-lg shadow-sm border border-surface-container-high/60 space-y-space-md">
        <div className="flex items-center gap-space-sm border-b border-surface-container-low pb-space-sm">
          <div className="w-10 h-10 rounded-xl bg-error-container text-on-error-container flex items-center justify-center font-bold shadow-xs">
            <span className="material-symbols-outlined text-[24px]">restart_alt</span>
          </div>
          <div>
            <h2 className="font-headline-sm text-headline-sm font-semibold text-on-surface">
              Clean Testing State
            </h2>
            <p className="font-body-sm text-body-sm text-on-surface-variant">
              Zero out all cash/bank balances, party ledgers, and transactions to start clean testing from scratch.
            </p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-space-md pt-space-xs">
          <div className="text-body-sm text-on-surface-variant">
            Sets all Cash Balances, Bank Balances, Stock Volumes, Receivables, and Payables to exactly 0, removing all test transactions.
          </div>
          <button
            type="button"
            onClick={() => {
              if (
                window.confirm(
                  'Reset the entire app to clean zero testing state? All balances will be set to 0 and all products, parties, and transactions will be cleared.'
                )
              ) {
                resetAllData();
                alert('App successfully reset to clean testing state with zero balances.');
              }
            }}
            className="px-space-md h-10 bg-error-container text-on-error-container hover:bg-error hover:text-on-error rounded-lg font-label-md text-label-md font-semibold transition-colors shrink-0 flex items-center gap-1.5 active:scale-98 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">delete_sweep</span>
            <span>Reset App to Zero Balances</span>
          </button>
        </div>
      </div>
    </div>
  );
};
