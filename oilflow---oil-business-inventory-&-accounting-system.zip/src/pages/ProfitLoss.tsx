import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { generateProfitLossPDF } from '../utils/pdfGenerator';

type PeriodFilter = 'today' | 'week' | 'month' | 'last-month' | 'quarter' | 'year' | 'all' | 'custom';

function formatStatementDate(dateStr: string): string {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1;
    const day = parseInt(parts[2], 10);
    const d = new Date(year, month, day);
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  }
  const d = new Date(dateStr);
  return isNaN(d.getTime()) ? dateStr : d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

function fmtNum(val: number): string {
  return Math.abs(val || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export const ProfitLoss: React.FC = () => {
  const {
    transactions,
    products,
    expenseHeads,
    settings,
    totalStockValue,
    openViewTransactionModal,
    openJournalModal,
    openTransactionModal,
    formatCurrency,
  } = useApp();

  const [period, setPeriod] = useState<PeriodFilter>('month');
  const [activeTab, setActiveTab] = useState<'statement' | 'products' | 'expenses' | 'transactions'>('statement');
  const [taxRatePercent, setTaxRatePercent] = useState<number>(15);

  // Custom date range state
  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);
  const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10);
  const [customStart, setCustomStart] = useState<string>(firstDayOfMonth);
  const [customEnd, setCustomEnd] = useState<string>(todayStr);

  // Calculate actual Date Range based on period filter
  const { startDate, endDate, periodLabel, periodRangeStr } = useMemo(() => {
    const currentDate = new Date();
    let start = '';
    let end = todayStr;
    let label = '';

    if (period === 'today') {
      start = todayStr;
      end = todayStr;
      label = `Today (${formatStatementDate(todayStr)})`;
    } else if (period === 'week') {
      const day = currentDate.getDay();
      const diffToMonday = currentDate.getDate() - day + (day === 0 ? -6 : 1);
      const monday = new Date(currentDate.setDate(diffToMonday));
      start = monday.toISOString().slice(0, 10);
      end = todayStr;
      label = 'This Week';
    } else if (period === 'month') {
      const year = currentDate.getFullYear();
      const month = currentDate.getMonth();
      start = new Date(year, month, 1).toISOString().slice(0, 10);
      end = new Date(year, month + 1, 0).toISOString().slice(0, 10);
      label = currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    } else if (period === 'last-month') {
      const year = currentDate.getFullYear();
      const month = currentDate.getMonth() - 1;
      start = new Date(year, month, 1).toISOString().slice(0, 10);
      end = new Date(year, month + 1, 0).toISOString().slice(0, 10);
      const lmDate = new Date(year, month, 1);
      label = lmDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    } else if (period === 'quarter') {
      const qMonth = Math.floor(currentDate.getMonth() / 3) * 3;
      start = new Date(currentDate.getFullYear(), qMonth, 1).toISOString().slice(0, 10);
      end = new Date(currentDate.getFullYear(), qMonth + 3, 0).toISOString().slice(0, 10);
      label = `Q${Math.floor(currentDate.getMonth() / 3) + 1} ${currentDate.getFullYear()}`;
    } else if (period === 'year') {
      start = `${currentDate.getFullYear()}-01-01`;
      end = `${currentDate.getFullYear()}-12-31`;
      label = `Financial Year ${currentDate.getFullYear()}`;
    } else if (period === 'all') {
      start = '2000-01-01';
      end = '2099-12-31';
      label = 'All Time Operational History';
    } else {
      start = customStart || '2000-01-01';
      end = customEnd || '2099-12-31';
      label = `Custom Range: ${start} to ${end}`;
    }

    const rangeStr = `${formatStatementDate(start)} - ${formatStatementDate(end)}`;
    return { startDate: start, endDate: end, periodLabel: label, periodRangeStr: rangeStr };
  }, [period, customStart, customEnd, todayStr]);

  // Report generation timestamp
  const reportDateStr = useMemo(() => {
    const d = new Date();
    const dateFormatted = d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    const timeFormatted = d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
    return `${dateFormatted} ${timeFormatted}`;
  }, []);

  // Filter Transactions in this reporting period
  const periodTransactions = useMemo(() => {
    return transactions.filter((tx) => {
      if (!tx.date) return false;
      return tx.date >= startDate && tx.date <= endDate;
    });
  }, [transactions, startDate, endDate]);

  // Product unit purchase cost map for accurate lookup
  const productCostMap = useMemo(() => {
    const map = new Map<string, { name: string; cost: number; salePrice: number; unit: string }>();
    products.forEach((p) => {
      map.set(p.id, {
        name: p.name,
        cost: p.purchaseCost || 0,
        salePrice: p.salePrice || 0,
        unit: p.unit || 'Drum',
      });
    });
    return map;
  }, [products]);

  // Detailed product-wise sales and cost breakdown
  const productPerformance = useMemo(() => {
    const breakdown: Record<
      string,
      {
        productId: string;
        productName: string;
        packagingUnit: string;
        qtySold: number;
        volumeSold: number;
        revenue: number;
        cost: number;
        grossProfit: number;
        marginPct: number;
      }
    > = {};

    periodTransactions
      .filter((tx) => tx.type === 'Sale')
      .forEach((tx) => {
        tx.items.forEach((item) => {
          const prodInfo = productCostMap.get(item.productId);
          const unitCost = prodInfo?.cost || (item.unitPrice > 0 ? item.unitPrice * 0.85 : 0);
          const itemCost = item.quantity * unitCost;

          if (!breakdown[item.productId]) {
            breakdown[item.productId] = {
              productId: item.productId,
              productName: item.productName || prodInfo?.name || 'Bulk Oil Product',
              packagingUnit: item.packagingUnit || prodInfo?.unit || 'Units',
              qtySold: 0,
              volumeSold: 0,
              revenue: 0,
              cost: 0,
              grossProfit: 0,
              marginPct: 0,
            };
          }

          breakdown[item.productId].qtySold += item.quantity || 0;
          breakdown[item.productId].volumeSold += item.totalVolume || 0;
          breakdown[item.productId].revenue += item.subtotal || 0;
          breakdown[item.productId].cost += itemCost;
        });
      });

    return Object.values(breakdown)
      .map((item) => {
        const gp = item.revenue - item.cost;
        const margin = item.revenue > 0 ? (gp / item.revenue) * 100 : 0;
        return {
          ...item,
          grossProfit: gp,
          marginPct: margin,
        };
      })
      .sort((a, b) => b.revenue - a.revenue);
  }, [periodTransactions, productCostMap]);

  // Total direct COGS from items sold
  const totalCOGSFromItems = useMemo(() => {
    return productPerformance.reduce((sum, p) => sum + p.cost, 0);
  }, [productPerformance]);

  // 1. REVENUE (INCOME) BREAKDOWN
  const saleTransactions = useMemo(() => {
    return periodTransactions.filter((tx) => tx.type === 'Sale');
  }, [periodTransactions]);

  const { salesLocal, salesExport, salesReturnsDiscounts, netSales } = useMemo(() => {
    let local = 0;
    let exportVal = 0;
    let returnsDiscounts = 0;

    saleTransactions.forEach((tx) => {
      const text = `${tx.partyName || ''} ${tx.notes || ''} ${tx.docNumber || ''}`.toLowerCase();
      const isExport = text.includes('export') || text.includes('international') || text.includes('foreign');
      const isReturnOrDiscount = text.includes('return') || text.includes('discount') || tx.docNumber?.startsWith('SR-') || tx.totalAmount < 0;

      if (isReturnOrDiscount) {
        returnsDiscounts += Math.abs(tx.totalAmount || 0);
      } else if (isExport) {
        exportVal += (tx.totalAmount || 0);
      } else {
        local += (tx.totalAmount || 0);
      }
    });

    const net = local + exportVal - returnsDiscounts;
    return {
      salesLocal: local,
      salesExport: exportVal,
      salesReturnsDiscounts: returnsDiscounts,
      netSales: net,
    };
  }, [saleTransactions]);

  // 2. PURCHASES & INVENTORY (COGS) ACCOUNTING LOGIC
  const purchaseTransactions = useMemo(() => {
    return periodTransactions.filter((tx) => tx.type === 'Purchase');
  }, [periodTransactions]);

  const { purchasesNet, purchaseReturns, freightInward } = useMemo(() => {
    let net = 0;
    let ret = 0;
    let freight = 0;

    purchaseTransactions.forEach((tx) => {
      const text = `${tx.partyName || ''} ${tx.notes || ''} ${tx.docNumber || ''}`.toLowerCase();
      if (text.includes('return') || tx.totalAmount < 0) {
        ret += Math.abs(tx.totalAmount || 0);
      } else {
        net += (tx.totalAmount || 0);
      }
    });

    // Check freight inward from expenses
    periodTransactions
      .filter((tx) => tx.type === 'Pay')
      .forEach((tx) => {
        const text = `${tx.expenseHeadName || ''} ${tx.notes || ''}`.toLowerCase();
        if (text.includes('freight inward') || text.includes('carriage inward') || text.includes('intake freight')) {
          freight += (tx.paidAmount || 0);
        }
      });

    return {
      purchasesNet: net,
      purchaseReturns: ret,
      freightInward: freight,
    };
  }, [purchaseTransactions, periodTransactions]);

  // Inventory valuation: Opening Stock & Closing Stock
  const {
    openingStockAmount,
    goodsAvailableForSale,
    closingStockAmount,
    costOfGoodsSold,
  } = useMemo(() => {
    // Current stock value in terminal
    const currentStockVal = totalStockValue || 0;

    // Direct COGS derived from actual sales
    const directCOGS = totalCOGSFromItems;

    // In GAAP/Trading account:
    // Goods Available = Opening Stock + Purchases (Net) + Freight Inward - Purchase Returns
    // Closing Stock = Goods Available - COGS
    // Therefore: Opening Stock = Closing Stock + COGS - Purchases (Net) - Freight Inward + Purchase Returns
    let closingVal = currentStockVal;
    let openingVal = 0;

    if (purchasesNet > 0 || directCOGS > 0) {
      openingVal = Math.max(0, closingVal + directCOGS - purchasesNet - freightInward + purchaseReturns);
    } else {
      openingVal = currentStockVal;
    }

    const available = openingVal + purchasesNet + freightInward - purchaseReturns;
    const finalCOGS = directCOGS > 0 ? directCOGS : Math.max(0, available - closingVal);

    // If closing stock was derived from balance:
    if (available >= finalCOGS) {
      closingVal = available - finalCOGS;
    }

    return {
      openingStockAmount: openingVal,
      goodsAvailableForSale: available,
      closingStockAmount: closingVal,
      costOfGoodsSold: finalCOGS,
    };
  }, [totalStockValue, totalCOGSFromItems, purchasesNet, freightInward, purchaseReturns]);

  // 3. GROSS PROFIT
  const grossProfit = netSales - costOfGoodsSold;
  const grossMarginPct = netSales > 0 ? (grossProfit / netSales) * 100 : 0;

  // 4. OPERATING EXPENSES
  // Categorize payouts into standard statement overheads matching the reference image
  const { operatingExpenseItems, totalOperatingExpenses } = useMemo(() => {
    const expenseTxs = periodTransactions.filter(
      (tx) => tx.type === 'Pay' && (tx.expenseHeadId || tx.expenseHeadName || (!tx.partyId && tx.paidAmount > 0))
    );

    const categories: Record<string, number> = {
      'Salaries & Wages': 0,
      'Rent Expense': 0,
      'Utilities (Electricity, Gas, Water)': 0,
      'Fuel & Transport': 0,
      'Telephone & Internet': 0,
      'Office & Stationery': 0,
      'Repairs & Maintenance': 0,
      'Marketing & Advertising': 0,
      'Bank Charges': 0,
      'Depreciation Expense': 0,
      'Other Expenses': 0,
    };

    expenseTxs.forEach((tx) => {
      const name = (tx.expenseHeadName || tx.notes || 'Other Expenses').toLowerCase();
      const amount = tx.paidAmount || 0;

      // Skip freight inward already accounted in COGS
      if (name.includes('freight inward') || name.includes('carriage inward') || name.includes('intake freight')) {
        return;
      }

      if (/salary|wages|staff|labor|labour|payroll|worker/.test(name)) {
        categories['Salaries & Wages'] += amount;
      } else if (/rent|godown|warehouse rent|depot rent|office rent/.test(name)) {
        categories['Rent Expense'] += amount;
      } else if (/electric|gas|water|utility|utilities|wapda|lesco|power|bill/.test(name)) {
        categories['Utilities (Electricity, Gas, Water)'] += amount;
      } else if (/fuel|diesel|petrol|transport|delivery|carriage|cartage|freight outward|vehicle/.test(name)) {
        categories['Fuel & Transport'] += amount;
      } else if (/phone|telephone|mobile|internet|wifi|ptcl|network|communication/.test(name)) {
        categories['Telephone & Internet'] += amount;
      } else if (/office|stationery|paper|printing|supplies|tea|kitchen|cleaning/.test(name)) {
        categories['Office & Stationery'] += amount;
      } else if (/repair|maintenance|servicing|workshop|overhaul|spare/.test(name)) {
        categories['Repairs & Maintenance'] += amount;
      } else if (/market|advertising|advert|promo|marketing|branding|billboard/.test(name)) {
        categories['Marketing & Advertising'] += amount;
      } else if (/bank|charges|fee|clearing|commission|duty|excise/.test(name)) {
        categories['Bank Charges'] += amount;
      } else if (/deprec|amort/.test(name)) {
        categories['Depreciation Expense'] += amount;
      } else {
        categories['Other Expenses'] += amount;
      }
    });

    const items = Object.entries(categories).map(([catName, amount]) => ({
      name: catName,
      amount,
    }));

    const total = items.reduce((sum, item) => sum + item.amount, 0);

    return { operatingExpenseItems: items, totalOperatingExpenses: total };
  }, [periodTransactions]);

  // 5. OTHER INCOME
  const { otherIncomeItems, totalOtherIncome } = useMemo(() => {
    const receipts = periodTransactions.filter((tx) => tx.type === 'Receive' && !tx.partyId);

    const categories: Record<string, number> = {
      'Interest Income': 0,
      'Discount Received': 0,
      'Other Income': 0,
    };

    receipts.forEach((tx) => {
      const name = (tx.notes || tx.accountName || '').toLowerCase();
      const amount = tx.paidAmount || 0;

      if (/interest|bank profit|dividend|savings/.test(name)) {
        categories['Interest Income'] += amount;
      } else if (/discount|rebate|cash discount/.test(name)) {
        categories['Discount Received'] += amount;
      } else {
        categories['Other Income'] += amount;
      }
    });

    const items = Object.entries(categories).map(([catName, amount]) => ({
      name: catName,
      amount,
    }));

    const total = items.reduce((sum, item) => sum + item.amount, 0);

    return { otherIncomeItems: items, totalOtherIncome: total };
  }, [periodTransactions]);

  // 6. NET PROFIT BEFORE & AFTER TAX
  const netProfitBeforeTax = grossProfit - totalOperatingExpenses + totalOtherIncome;
  const taxExpense = netProfitBeforeTax > 0 ? (netProfitBeforeTax * taxRatePercent) / 100 : 0;
  const netProfitAfterTax = netProfitBeforeTax - taxExpense;
  const netMarginPct = netSales > 0 ? (netProfitAfterTax / netSales) * 100 : 0;

  // Formatted date string tokens for statement
  const openingStockDateStr = useMemo(() => formatStatementDate(startDate), [startDate]);
  const closingStockDateStr = useMemo(() => formatStatementDate(endDate), [endDate]);

  // Expense Head breakdown table (for drill-down tab)
  const expenseHeadBreakdown = useMemo(() => {
    const map: Record<string, { headId?: string; name: string; category: string; amount: number; count: number }> = {};
    periodTransactions
      .filter((tx) => tx.type === 'Pay' && (tx.expenseHeadId || tx.expenseHeadName || (!tx.partyId && tx.paidAmount > 0)))
      .forEach((tx) => {
        const key = tx.expenseHeadId || tx.expenseHeadName || 'General Overhead';
        const headObj = expenseHeads.find((h) => h.id === tx.expenseHeadId || h.name === tx.expenseHeadName);
        const name = headObj?.name || tx.expenseHeadName || 'Direct Overhead Payout';
        const category = headObj?.category || 'General';

        if (!map[key]) {
          map[key] = { headId: tx.expenseHeadId, name, category, amount: 0, count: 0 };
        }
        map[key].amount += tx.paidAmount || 0;
        map[key].count += 1;
      });

    return Object.values(map).sort((a, b) => b.amount - a.amount);
  }, [periodTransactions, expenseHeads]);

  // Handle PDF Export
  const handleDownloadPDF = () => {
    generateProfitLossPDF(
      {
        periodLabel,
        startDate,
        endDate,
        periodRangeStr,
        reportDateStr,
        currency: 'PKR',
        salesLocal,
        salesExport,
        salesReturnsDiscounts,
        netSales,
        openingStockDateStr,
        openingStockAmount,
        purchasesNet,
        purchaseReturns,
        freightInward,
        goodsAvailableForSale,
        closingStockDateStr,
        closingStockAmount,
        costOfGoodsSold,
        grossProfit,
        grossMarginPct,
        operatingExpenseItems,
        totalOperatingExpenses,
        otherIncomeItems,
        totalOtherIncome,
        netProfitBeforeTax,
        taxRatePercent,
        taxExpense,
        netProfitAfterTax,
        netMarginPct,
      },
      settings
    );
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="flex flex-col w-full pb-20">
      {/* Top Header & Audit Controls */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 mb-5">
        <div>
          <div className="flex items-center gap-1.5 text-slate-500 text-xs font-semibold uppercase tracking-wider mb-1">
            <span>Financials &amp; Accounts</span>
            <span className="material-symbols-outlined text-[14px]">chevron_right</span>
            <span className="text-slate-800 font-bold">Profit &amp; Loss Statement</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Profit &amp; Loss Statement
          </h1>
          <p className="text-sm text-slate-600 mt-0.5">
            Real-time financial statement calculated from actual invoices, procurement, and operating expense vouchers.
          </p>
        </div>

        {/* Action Controls: Print, PDF, Quick Transact */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={handlePrint}
            className="h-10 px-3.5 rounded-lg bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 font-semibold text-[13px] flex items-center gap-1.5 shadow-xs transition-colors"
            title="Print Statement"
          >
            <span className="material-symbols-outlined text-[18px]">print</span>
            <span>Print</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadPDF}
            className="h-10 px-4 rounded-lg bg-[#0e1b38] hover:bg-[#1a2d54] text-white font-semibold text-[13px] flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
            title="Download Official PDF Statement"
          >
            <span className="material-symbols-outlined text-[18px]">picture_as_pdf</span>
            <span>Download Statement PDF</span>
          </button>
        </div>
      </div>

      {/* Date Range & Period Filter Bar */}
      <div className="bg-white rounded-xl p-4 shadow-xs border border-slate-200 mb-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Quick Period Buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {(
              [
                { id: 'today', label: 'Today' },
                { id: 'week', label: 'This Week' },
                { id: 'month', label: 'This Month' },
                { id: 'last-month', label: 'Last Month' },
                { id: 'quarter', label: 'This Quarter' },
                { id: 'year', label: 'This Year' },
                { id: 'all', label: 'All Time' },
                { id: 'custom', label: 'Custom Range' },
              ] as const
            ).map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setPeriod(p.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  period === p.id
                    ? 'bg-[#0e1b38] text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Active Period & Tax Rate Configurator */}
          <div className="flex items-center gap-4 self-start md:self-auto flex-wrap">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
              <span className="material-symbols-outlined text-[#0e1b38] text-[16px]">calendar_month</span>
              <span>{periodLabel}</span>
            </div>

            <div className="flex items-center gap-1.5 text-xs text-slate-600 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
              <span className="font-semibold">Tax Rate:</span>
              <input
                type="number"
                min="0"
                max="100"
                step="0.5"
                value={taxRatePercent === 0 ? '' : taxRatePercent}
                placeholder="0"
                onChange={(e) => setTaxRatePercent(e.target.value === '' ? 0 : Math.max(0, parseFloat(e.target.value) || 0))}
                className="w-12 h-6 px-1 text-center font-bold text-slate-900 bg-white border border-slate-300 rounded text-xs focus:outline-none focus:ring-1 focus:ring-slate-900"
              />
              <span className="font-bold text-slate-800">%</span>
            </div>
          </div>
        </div>

        {/* Custom Date Pickers */}
        {period === 'custom' && (
          <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              <label className="text-xs font-semibold text-slate-600">From Date:</label>
              <input
                type="date"
                value={customStart}
                onChange={(e) => setCustomStart(e.target.value)}
                className="h-8 px-2 rounded-lg bg-slate-50 border border-slate-300 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
              />
            </div>
            <div className="flex items-center gap-2">
              <label className="text-xs font-semibold text-slate-600">To Date:</label>
              <input
                type="date"
                value={customEnd}
                onChange={(e) => setCustomEnd(e.target.value)}
                className="h-8 px-2 rounded-lg bg-slate-50 border border-slate-300 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900"
              />
            </div>
          </div>
        )}
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 mb-5 overflow-x-auto scrollbar-none">
        <button
          type="button"
          onClick={() => setActiveTab('statement')}
          className={`pb-2.5 px-3.5 text-[13px] font-bold border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'statement'
              ? 'border-[#0e1b38] text-[#0e1b38]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <span className="material-symbols-outlined text-[18px]">receipt_long</span>
          <span>Official P&amp;L Statement</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('products')}
          className={`pb-2.5 px-3.5 text-[13px] font-bold border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'products'
              ? 'border-[#0e1b38] text-[#0e1b38]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <span className="material-symbols-outlined text-[18px]">pie_chart</span>
          <span>Product Margins &amp; COGS ({productPerformance.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('expenses')}
          className={`pb-2.5 px-3.5 text-[13px] font-bold border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'expenses'
              ? 'border-[#0e1b38] text-[#0e1b38]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <span className="material-symbols-outlined text-[18px]">payments</span>
          <span>Expense Head Breakdown ({expenseHeadBreakdown.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('transactions')}
          className={`pb-2.5 px-3.5 text-[13px] font-bold border-b-2 flex items-center gap-2 transition-all whitespace-nowrap ${
            activeTab === 'transactions'
              ? 'border-[#0e1b38] text-[#0e1b38]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <span className="material-symbols-outlined text-[18px]">list_alt</span>
          <span>Included Postings ({periodTransactions.length})</span>
        </button>
      </div>

      {/* TAB 1: OFFICIAL PROFIT & LOSS STATEMENT (EXACT REFERENCE DESIGN) */}
      {activeTab === 'statement' && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden p-4 sm:p-7">
          {/* Statement Header Row */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-200">
            {/* Left: Icon & Title */}
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-lg bg-[#0e1b38] text-white flex items-center justify-center shadow-xs shrink-0">
                <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M3 3v18h18" />
                  <path d="m19 9-5 5-4-4-3 3" />
                </svg>
              </div>
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-[#0e1b38] tracking-tight uppercase">
                  PROFIT &amp; LOSS STATEMENT
                </h2>
                <p className="text-sm font-semibold text-slate-600">
                  {settings.businessName || 'Al Madina Traders'}
                </p>
              </div>
            </div>

            {/* Right: Period, Report Date, Currency */}
            <div className="flex items-center gap-5 sm:gap-7 self-start md:self-auto flex-wrap">
              {/* For the Period */}
              <div className="flex items-start gap-2">
                <span className="material-symbols-outlined text-slate-700 text-[20px] mt-0.5">calendar_month</span>
                <div>
                  <span className="text-[11px] font-semibold text-slate-500 block leading-tight">For the Period</span>
                  <span className="text-[13px] font-bold text-slate-900 block mt-0.5 whitespace-nowrap">
                    {periodRangeStr}
                  </span>
                </div>
              </div>

              {/* Report Date */}
              <div>
                <span className="text-[11px] font-semibold text-slate-500 block leading-tight">Report Date</span>
                <span className="text-[13px] font-bold text-slate-900 block mt-0.5 whitespace-nowrap">
                  {reportDateStr}
                </span>
              </div>

              {/* Currency */}
              <div>
                <span className="text-[11px] font-semibold text-slate-500 block leading-tight">Currency</span>
                <span className="inline-block px-3 py-0.5 rounded bg-[#0e1b38] text-white text-xs font-bold mt-0.5">
                  PKR
                </span>
              </div>
            </div>
          </div>

          {/* TWO COLUMN FINANCIAL GRID */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 my-6 items-start">
            {/* ========================================================= */}
            {/* LEFT COLUMN: INCOME, COST OF GOODS SOLD, GROSS PROFIT */}
            {/* ========================================================= */}
            <div className="flex flex-col gap-6">
              {/* 1. INCOME TABLE */}
              <div className="rounded-sm border border-slate-200 overflow-hidden shadow-2xs">
                {/* Header */}
                <div className="bg-[#0e1b38] text-white px-4 py-2.5 flex justify-between items-center text-xs font-bold uppercase tracking-wider">
                  <span>INCOME</span>
                  <span>AMOUNT (PKR)</span>
                </div>

                {/* Rows */}
                <div className="divide-y divide-slate-100 text-[13px]">
                  <div className="px-4 py-2.5 flex justify-between items-center hover:bg-slate-50/50">
                    <span className="text-slate-800 font-medium">Sales (Local)</span>
                    <span className="text-slate-900 font-semibold">{fmtNum(salesLocal)}</span>
                  </div>
                  <div className="px-4 py-2.5 flex justify-between items-center hover:bg-slate-50/50">
                    <span className="text-slate-800 font-medium">Sales (Export)</span>
                    <span className="text-slate-900 font-semibold">{fmtNum(salesExport)}</span>
                  </div>
                  <div className="px-4 py-2.5 flex justify-between items-center hover:bg-slate-50/50">
                    <span className="text-slate-800 font-medium">Sales Returns / Discounts</span>
                    <span className="text-red-600 font-semibold">
                      {salesReturnsDiscounts !== 0 ? `-${fmtNum(salesReturnsDiscounts)}` : '0.00'}
                    </span>
                  </div>

                  {/* Summary: NET SALES */}
                  <div className="bg-[#eef8f2] text-[#0a5c36] font-bold px-4 py-2.5 flex justify-between items-center border-t border-emerald-100 text-[13.5px]">
                    <span className="tracking-wide">NET SALES</span>
                    <span className="text-[14px] font-extrabold">{fmtNum(netSales)}</span>
                  </div>
                </div>
              </div>

              {/* 2. COST OF GOODS SOLD TABLE */}
              <div className="rounded-sm border border-slate-200 overflow-hidden shadow-2xs">
                {/* Header */}
                <div className="bg-[#0e1b38] text-white px-4 py-2.5 flex justify-between items-center text-xs font-bold uppercase tracking-wider">
                  <span>COST OF GOODS SOLD</span>
                  <span>AMOUNT (PKR)</span>
                </div>

                {/* Rows */}
                <div className="divide-y divide-slate-100 text-[13px]">
                  <div className="px-4 py-2.5 flex justify-between items-center hover:bg-slate-50/50">
                    <span className="text-slate-800 font-medium">
                      Opening Stock ({openingStockDateStr || startDate})
                    </span>
                    <span className="text-slate-900 font-semibold">{fmtNum(openingStockAmount)}</span>
                  </div>
                  <div className="px-4 py-2.5 flex justify-between items-center hover:bg-slate-50/50">
                    <span className="text-slate-800 font-medium">Purchases (Net)</span>
                    <span className="text-slate-900 font-semibold">{fmtNum(purchasesNet)}</span>
                  </div>
                  <div className="px-4 py-2.5 flex justify-between items-center hover:bg-slate-50/50">
                    <span className="text-slate-800 font-medium">Purchase Returns</span>
                    <span className="text-red-600 font-semibold">
                      {purchaseReturns !== 0 ? `-${fmtNum(purchaseReturns)}` : '0.00'}
                    </span>
                  </div>
                  <div className="px-4 py-2.5 flex justify-between items-center hover:bg-slate-50/50">
                    <span className="text-slate-800 font-medium">Freight Inward</span>
                    <span className="text-slate-900 font-semibold">{fmtNum(freightInward)}</span>
                  </div>

                  {/* GOODS AVAILABLE FOR SALE ROW */}
                  <div className="bg-slate-50 font-bold px-4 py-2.5 flex justify-between items-center border-y border-slate-200 text-slate-900">
                    <span className="uppercase text-[12.5px] tracking-wide">GOODS AVAILABLE FOR SALE</span>
                    <span className="text-[13.5px] font-extrabold">{fmtNum(goodsAvailableForSale)}</span>
                  </div>

                  <div className="px-4 py-2.5 flex justify-between items-center hover:bg-slate-50/50">
                    <span className="text-slate-800 font-medium">
                      Closing Stock ({closingStockDateStr || endDate})
                    </span>
                    <span className="text-red-600 font-semibold">
                      {closingStockAmount !== 0 ? `-${fmtNum(closingStockAmount)}` : '0.00'}
                    </span>
                  </div>

                  {/* Summary: COST OF GOODS SOLD */}
                  <div className="bg-white font-bold px-4 py-2.5 flex justify-between items-center border-t border-slate-200">
                    <span className="text-slate-900 text-[13px] uppercase tracking-wide">COST OF GOODS SOLD</span>
                    <span className="text-red-600 text-[14px] font-extrabold">{fmtNum(costOfGoodsSold)}</span>
                  </div>
                </div>
              </div>

              {/* 3. GROSS PROFIT HIGHLIGHT CARD */}
              <div className="bg-[#fffbeb] border border-[#fef08a] rounded-lg p-3.5 px-4 flex justify-between items-center shadow-2xs">
                <span className="text-sm sm:text-base font-extrabold text-[#0a5c36] uppercase tracking-wide">
                  GROSS PROFIT
                </span>
                <span className="text-base sm:text-lg font-black text-[#0a5c36]">
                  {fmtNum(grossProfit)}
                </span>
              </div>
            </div>

            {/* ========================================================= */}
            {/* RIGHT COLUMN: OPERATING EXPENSES, OTHER INCOME */}
            {/* ========================================================= */}
            <div className="flex flex-col gap-6">
              {/* 1. OPERATING EXPENSES TABLE */}
              <div className="rounded-sm border border-slate-200 overflow-hidden shadow-2xs">
                {/* Header */}
                <div className="bg-[#0e1b38] text-white px-4 py-2.5 flex justify-between items-center text-xs font-bold uppercase tracking-wider">
                  <span>OPERATING EXPENSES</span>
                  <span>AMOUNT (PKR)</span>
                </div>

                {/* Rows */}
                <div className="divide-y divide-slate-100 text-[13px]">
                  {operatingExpenseItems.map((item, idx) => (
                    <div key={idx} className="px-4 py-2 flex justify-between items-center hover:bg-slate-50/50">
                      <span className="text-slate-800 font-medium">{item.name}</span>
                      <span className="text-slate-900 font-semibold">{fmtNum(item.amount)}</span>
                    </div>
                  ))}

                  {/* Summary: TOTAL OPERATING EXPENSES */}
                  <div className="bg-[#fff5f5] text-red-600 font-bold px-4 py-2.5 flex justify-between items-center border-t-2 border-red-100 text-[13px]">
                    <span className="uppercase tracking-wide">TOTAL OPERATING EXPENSES</span>
                    <span className="text-[14px] font-extrabold">{fmtNum(totalOperatingExpenses)}</span>
                  </div>
                </div>
              </div>

              {/* 2. OTHER INCOME TABLE */}
              <div className="rounded-sm border border-slate-200 overflow-hidden shadow-2xs">
                {/* Header */}
                <div className="bg-[#0e1b38] text-white px-4 py-2.5 flex justify-between items-center text-xs font-bold uppercase tracking-wider">
                  <span>OTHER INCOME</span>
                  <span>AMOUNT (PKR)</span>
                </div>

                {/* Rows */}
                <div className="divide-y divide-slate-100 text-[13px]">
                  {otherIncomeItems.map((item, idx) => (
                    <div key={idx} className="px-4 py-2 flex justify-between items-center hover:bg-slate-50/50">
                      <span className="text-slate-800 font-medium">{item.name}</span>
                      <span className="text-slate-900 font-semibold">{fmtNum(item.amount)}</span>
                    </div>
                  ))}

                  {/* Summary: TOTAL OTHER INCOME */}
                  <div className="bg-[#f0fdf4] text-[#0a5c36] font-bold px-4 py-2.5 flex justify-between items-center border-t border-emerald-100 text-[13px]">
                    <span className="uppercase tracking-wide">TOTAL OTHER INCOME</span>
                    <span className="text-[14px] font-extrabold">{fmtNum(totalOtherIncome)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* ========================================================= */}
          {/* FULL WIDTH BOTTOM SECTION: NET PROFIT BEFORE & AFTER TAX */}
          {/* ========================================================= */}
          <div className="mt-6 flex flex-col shadow-2xs">
            {/* Row 1: NET PROFIT BEFORE TAX */}
            <div className="bg-[#eef8f2] border border-emerald-200 rounded-t-lg p-3.5 px-6 flex justify-between items-center">
              <span className="text-sm sm:text-base font-bold text-[#0a5c36] uppercase tracking-wide">
                NET PROFIT BEFORE TAX
              </span>
              <span className="text-base sm:text-lg font-black text-[#0a5c36]">
                {fmtNum(netProfitBeforeTax)}
              </span>
            </div>

            {/* Row 2: Tax Expense */}
            <div className="bg-white border-x border-emerald-200 p-3 px-6 flex justify-between items-center text-sm font-medium text-slate-800">
              <div className="flex items-center gap-1.5">
                <span>Tax</span>
                <span className="text-red-600 font-semibold">Expense</span>
                <span className="text-xs text-slate-500 font-normal">({taxRatePercent}%)</span>
              </div>
              <span className="text-red-600 font-bold">
                {taxExpense !== 0 ? `-${fmtNum(taxExpense)}` : '0.00'}
              </span>
            </div>

            {/* Row 3: NET PROFIT AFTER TAX */}
            <div className="bg-[#075e3a] text-white p-4 px-6 flex justify-between items-center rounded-b-lg shadow-sm">
              <span className="text-base sm:text-lg font-black uppercase tracking-wider">
                NET PROFIT AFTER TAX
              </span>
              <span className="text-xl sm:text-2xl font-black tracking-tight">
                {netProfitAfterTax < 0 ? '-' : ''}{fmtNum(netProfitAfterTax)}
              </span>
            </div>
          </div>

          {/* Statement Audit Attestation Footer */}
          <div className="mt-8 pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
            <div className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[#075e3a] text-[18px]">verified</span>
              <span>Prepared systematically from validated journal records &amp; inventory valuation.</span>
            </div>
            <div className="font-semibold text-slate-700">
              Authorized Signatory: _________________________
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: PRODUCT-WISE MARGINS & COGS BREAKDOWN */}
      {activeTab === 'products' && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Product Profitability &amp; Cost of Goods Sold (COGS)
              </h3>
              <p className="text-xs text-slate-600 mt-0.5">
                Breakdown of sales revenue, direct product costs, and gross margins for items sold during this period.
              </p>
            </div>
            <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-[#0e1b38] text-white">
              {productPerformance.length} Products Sold
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-600 text-xs uppercase tracking-wider border-b border-slate-200">
                  <th className="py-2.5 px-4 font-bold">Product Name</th>
                  <th className="py-2.5 px-3 text-right font-bold">Units Sold</th>
                  <th className="py-2.5 px-3 text-right font-bold">Volume</th>
                  <th className="py-2.5 px-4 text-right font-bold">Sales Revenue</th>
                  <th className="py-2.5 px-4 text-right font-bold">Direct Cost (COGS)</th>
                  <th className="py-2.5 px-4 text-right font-bold">Gross Profit</th>
                  <th className="py-2.5 px-4 text-right font-bold">Margin %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs sm:text-[13px] text-slate-800">
                {productPerformance.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-500">
                      <span className="material-symbols-outlined text-[36px] text-slate-300 mb-2 block">
                        inventory_2
                      </span>
                      <p className="font-semibold text-slate-700">No product sales recorded in this period</p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Record a Sale invoice to view product-level profitability.
                      </p>
                      <button
                        type="button"
                        onClick={() => openTransactionModal('Sale')}
                        className="mt-3 px-4 py-1.5 rounded-lg bg-[#0e1b38] text-white text-xs font-semibold shadow-xs"
                      >
                        + Record Sale Invoice
                      </button>
                    </td>
                  </tr>
                ) : (
                  productPerformance.map((p) => (
                    <tr key={p.productId} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-semibold text-slate-900">
                        <div className="flex items-center gap-2">
                          <span className="material-symbols-outlined text-amber-600 text-[18px]">oil_barrel</span>
                          <span>{p.productName}</span>
                        </div>
                      </td>
                      <td className="py-3 px-3 text-right font-semibold">
                        {p.qtySold.toLocaleString()} {p.packagingUnit}
                      </td>
                      <td className="py-3 px-3 text-right text-slate-600">
                        {p.volumeSold.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-right font-bold text-slate-900">
                        Rs. {fmtNum(p.revenue)}
                      </td>
                      <td className="py-3 px-4 text-right text-red-600 font-medium">
                        Rs. {fmtNum(p.cost)}
                      </td>
                      <td className={`py-3 px-4 text-right font-bold ${p.grossProfit >= 0 ? 'text-[#0a5c36]' : 'text-red-600'}`}>
                        Rs. {fmtNum(p.grossProfit)}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <span className={`inline-block px-2 py-0.5 rounded text-xs font-bold ${
                          p.marginPct >= 15 ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'
                        }`}>
                          {p.marginPct.toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: EXPENSE HEAD AUDIT & OVERHEADS */}
      {activeTab === 'expenses' && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Operating Expense Heads &amp; Overheads
              </h3>
              <p className="text-xs text-slate-600 mt-0.5">
                Summary of operational payout vouchers by Expense Head.
              </p>
            </div>
            <button
              type="button"
              onClick={() => openJournalModal('Out')}
              className="h-9 px-3.5 rounded-lg bg-red-600 hover:bg-red-700 text-white font-semibold text-xs flex items-center gap-1.5 shadow-xs"
            >
              <span className="material-symbols-outlined text-[16px]">call_made</span>
              <span>Record Expense (Payout)</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-600 text-xs uppercase tracking-wider border-b border-slate-200">
                  <th className="py-2.5 px-4 font-bold">Expense Head</th>
                  <th className="py-2.5 px-4 font-bold">Category</th>
                  <th className="py-2.5 px-3 text-center font-bold">Vouchers Count</th>
                  <th className="py-2.5 px-4 text-right font-bold">Total Spent</th>
                  <th className="py-2.5 px-4 text-right font-bold">% of Total Overheads</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs sm:text-[13px] text-slate-800">
                {expenseHeadBreakdown.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-12 text-center text-slate-500">
                      <span className="material-symbols-outlined text-[36px] text-slate-300 mb-2 block">
                        receipt_long
                      </span>
                      <p className="font-semibold text-slate-700">No overhead expenses recorded in this period</p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Add an Expense or record a payment disbursement.
                      </p>
                      <button
                        type="button"
                        onClick={() => openJournalModal('Out')}
                        className="mt-3 px-4 py-1.5 rounded-lg bg-red-600 text-white text-xs font-semibold shadow-xs"
                      >
                        + Record Expense
                      </button>
                    </td>
                  </tr>
                ) : (
                  expenseHeadBreakdown.map((h, idx) => (
                    <tr key={idx} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-semibold text-slate-900">{h.name}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 text-slate-700">
                          {h.category}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-center font-semibold">{h.count} payouts</td>
                      <td className="py-3 px-4 text-right font-bold text-red-600">
                        Rs. {fmtNum(h.amount)}
                      </td>
                      <td className="py-3 px-4 text-right font-semibold text-slate-600">
                        {totalOperatingExpenses > 0 ? ((h.amount / totalOperatingExpenses) * 100).toFixed(1) : '0.0'}%
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: INCLUDED TRANSACTIONS AUDIT */}
      {activeTab === 'transactions' && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Period Journal Postings &amp; Invoices Audit
              </h3>
              <p className="text-xs text-slate-600 mt-0.5">
                Every transaction posted between {startDate} and {endDate} affecting this income statement.
              </p>
            </div>
            <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-[#0e1b38] text-white">
              {periodTransactions.length} Transactions
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-600 text-xs uppercase tracking-wider border-b border-slate-200">
                  <th className="py-2.5 px-4 font-bold">Doc #</th>
                  <th className="py-2.5 px-3 font-bold">Date &amp; Time</th>
                  <th className="py-2.5 px-3 font-bold">Type</th>
                  <th className="py-2.5 px-4 font-bold">Counterparty / Description</th>
                  <th className="py-2.5 px-3 font-bold">Account Channel</th>
                  <th className="py-2.5 px-4 text-right font-bold">Total Amount</th>
                  <th className="py-2.5 px-4 text-right font-bold">Paid / Settled</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs sm:text-[13px] text-slate-800">
                {periodTransactions.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-500">
                      <p className="font-semibold text-slate-700">No transactions recorded in this period</p>
                    </td>
                  </tr>
                ) : (
                  periodTransactions.map((tx) => (
                    <tr
                      key={tx.id}
                      onClick={() => openViewTransactionModal(tx)}
                      className="hover:bg-slate-50 cursor-pointer transition-colors"
                    >
                      <td className="py-2.5 px-4 font-bold text-[#0e1b38]">{tx.docNumber}</td>
                      <td className="py-2.5 px-3 text-slate-600">{tx.date} {tx.time}</td>
                      <td className="py-2.5 px-3">
                        <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                          tx.type === 'Sale'
                            ? 'bg-emerald-100 text-emerald-800'
                            : tx.type === 'Purchase'
                            ? 'bg-blue-100 text-blue-800'
                            : tx.type === 'Receive'
                            ? 'bg-teal-100 text-teal-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {tx.type}
                        </span>
                      </td>
                      <td className="py-2.5 px-4 font-medium text-slate-900">
                        {tx.partyName || tx.expenseHeadName || tx.notes || 'Direct Depot Posting'}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">{tx.accountName || 'Credit / Account'}</td>
                      <td className="py-2.5 px-4 text-right font-bold text-slate-900">
                        Rs. {fmtNum(tx.totalAmount)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-semibold text-[#0a5c36]">
                        Rs. {fmtNum(tx.paidAmount)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
