import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Account } from '../types';
import { generateAccountLedgerPDF } from '../utils/pdfGenerator';
import { AccountLedgerModal } from '../components/modals/AccountLedgerModal';

export const AccountsLedgers: React.FC = () => {
  const {
    viewingAccountLedgerId,
    accounts,
    addAccount,
    updateAccount,
    deleteAccount,
    reconcileAccountBalances,
    openReconcileModal,
    totalCash,
    totalBank,
    openTransferModal,
    openAccountLedgerModal,
    transactions,
    openViewTransactionModal,
    openPdfPreview,
    settings,
  } = useApp();

  // Add Account Modal State
  const [addingAccount, setAddingAccount] = useState(false);
  const [newAccName, setNewAccName] = useState('');
  const [newAccType, setNewAccType] = useState<'Cash' | 'Bank'>('Bank');
  const [newBankName, setNewBankName] = useState('');
  const [newAccNumber, setNewAccNumber] = useState('');
  const [newBalance, setNewBalance] = useState<number>(0);
  const [newBranch, setNewBranch] = useState('');
  const [newIsDefault, setNewIsDefault] = useState(false);

  // Edit Account Modal State
  const [editingAccount, setEditingAccount] = useState<Account | null>(null);
  const [editName, setEditName] = useState('');
  const [editType, setEditType] = useState<'Cash' | 'Bank'>('Bank');
  const [editBankName, setEditBankName] = useState('');
  const [editAccNumber, setEditAccNumber] = useState('');
  const [editBalance, setEditBalance] = useState<number>(0);
  const [editBranch, setEditBranch] = useState('');
  const [editIsDefault, setEditIsDefault] = useState(false);

  // User feedback toast
  const [reconcileFeedback, setReconcileFeedback] = useState<string | null>(null);

  const [selectedAccountId, setSelectedAccountId] = useState<string>(accounts[0]?.id || '');

  const activeAccount = accounts.find((a) => a.id === selectedAccountId) || accounts[0];

  // Strictly compute transactions that actually involved this account
  const accountPostings = transactions
    .filter((t) => {
      if (t.type === 'Transfer') {
        return t.accountId === activeAccount?.id || t.toAccountId === activeAccount?.id;
      }
      return t.accountId === activeAccount?.id && (t.paidAmount || 0) > 0;
    })
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const handleDownloadActiveLedgerPDF = (acc: Account) => {
    const relevant = transactions
      .filter((t) => {
        if (t.type === 'Transfer') {
          return t.accountId === acc.id || t.toAccountId === acc.id;
        }
        return t.accountId === acc.id && (t.paidAmount || 0) > 0;
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    let balance = acc.openingBalance || 0;
    const rows = relevant.map((tx) => {
      let inflow = 0;
      let outflow = 0;
      let desc = '';

      if (tx.type === 'Transfer') {
        if (tx.accountId === acc.id) {
          outflow = tx.totalAmount;
          desc = `Transfer to ${tx.toAccountName}`;
          balance -= outflow;
        } else {
          inflow = tx.totalAmount;
          desc = `Transfer from ${tx.accountName}`;
          balance += inflow;
        }
      } else if (tx.type === 'Sale' || tx.type === 'Receive') {
        inflow = tx.paidAmount;
        desc = `${tx.type}: ${tx.partyName || tx.docNumber}`;
        balance += inflow;
      } else if (tx.type === 'Purchase' || tx.type === 'Pay') {
        outflow = tx.paidAmount;
        desc = tx.expenseHeadName ? `Expense: ${tx.expenseHeadName}` : `${tx.type}: ${tx.partyName || tx.docNumber}`;
        balance -= outflow;
      }

      return {
        date: tx.date,
        docNumber: tx.docNumber,
        type: tx.type,
        description: desc,
        inflow,
        outflow,
        runningBalance: balance,
      };
    });

    generateAccountLedgerPDF(acc, rows, settings);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAccName.trim()) {
      alert('Please enter account title.');
      return;
    }
    addAccount({
      name: newAccName.trim(),
      type: newAccType,
      bankName: newAccType === 'Bank' ? newBankName.trim() : undefined,
      accountNumber: newAccType === 'Bank' ? newAccNumber.trim() : undefined,
      balance: Number(newBalance) || 0,
      openingBalance: Number(newBalance) || 0,
      branch: newBranch.trim(),
      isDefault: newIsDefault,
    });
    setAddingAccount(false);
    setNewAccName('');
    setNewAccType('Bank');
    setNewBankName('');
    setNewAccNumber('');
    setNewBalance(0);
    setNewBranch('');
    setNewIsDefault(false);
  };

  const handleStartEdit = (acc: Account) => {
    setEditingAccount(acc);
    setEditName(acc.name);
    setEditType(acc.type);
    setEditBankName(acc.bankName || '');
    setEditAccNumber(acc.accountNumber || '');
    setEditBalance(acc.balance);
    setEditBranch(acc.branch || '');
    setEditIsDefault(acc.isDefault || false);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAccount) return;
    if (!editName.trim()) {
      alert('Please enter account title.');
      return;
    }

    updateAccount(editingAccount.id, {
      name: editName.trim(),
      type: editType,
      bankName: editType === 'Bank' ? editBankName.trim() : undefined,
      accountNumber: editType === 'Bank' ? editAccNumber.trim() : undefined,
      balance: Number(editBalance) || 0,
      openingBalance: Number(editBalance) || 0,
      branch: editBranch.trim(),
      isDefault: editIsDefault,
    });

    setEditingAccount(null);
  };

  const handleDeleteAccount = (acc: Account) => {
    const linked = transactions.filter((t) => t.accountId === acc.id || t.toAccountId === acc.id);
    let promptMsg = `Are you sure you want to delete account "${acc.name}"?`;
    if (linked.length > 0) {
      promptMsg = `Warning: "${acc.name}" has ${linked.length} linked transactions. Deleting it will remove the account from your list. Are you sure you want to proceed?`;
    }

    if (window.confirm(promptMsg)) {
      const res = deleteAccount(acc.id);
      if (!res.success) {
        alert(res.message);
      } else {
        if (selectedAccountId === acc.id) {
          const next = accounts.find((a) => a.id !== acc.id);
          if (next) setSelectedAccountId(next.id);
        }
      }
    }
  };

  const handleReconcile = () => {
    reconcileAccountBalances();
    openReconcileModal();
  };

  if (viewingAccountLedgerId) {
    return <AccountLedgerModal />;
  }

  return (
    <div className="flex flex-col w-full pb-space-xl">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-space-md mb-space-lg">
        <div>
          <div className="flex items-center gap-space-xs text-on-surface-variant font-label-sm uppercase tracking-wider mb-1">
            <span>Financials</span>
            <span className="material-symbols-outlined text-[14px]">chevron_right</span>
            <span className="text-primary font-semibold">Banking &amp; Cash Book</span>
          </div>
          <h1 className="font-headline-lg text-headline-lg text-on-surface font-semibold tracking-tight">
            Accounts &amp; Ledgers
          </h1>
          <p className="font-body-md text-body-md text-on-surface-variant mt-0.5">
            Real-time reconciliation of physical vault cash and corporate bank books with PDF generation and editable accounts.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-space-sm self-start md:self-auto">
          {/* Reconcile Button */}
          <button
            onClick={handleReconcile}
            className="h-10 px-space-md bg-surface-container-low text-on-surface hover:bg-surface-container rounded-lg flex items-center gap-space-xs font-label-md text-label-md font-semibold transition-colors shadow-xs"
            type="button"
            title="Recalculate balances strictly from transactions"
          >
            <span className="material-symbols-outlined text-[18px] text-tertiary">verified</span>
            <span>Reconcile Balances</span>
          </button>

          <button
            onClick={openTransferModal}
            className="h-10 px-space-md bg-surface-container-low text-on-surface hover:bg-surface-container rounded-lg flex items-center gap-space-xs font-label-md text-label-md font-semibold transition-colors shadow-xs"
            type="button"
          >
            <span className="material-symbols-outlined text-[18px]">sync_alt</span>
            <span>Transfer Funds</span>
          </button>

          <button
            onClick={() => setAddingAccount(true)}
            className="h-10 px-space-md bg-primary text-on-primary hover:bg-primary-container rounded-lg flex items-center gap-space-xs font-label-md text-label-md font-semibold transition-colors shadow-sm active:scale-98"
            type="button"
          >
            <span className="material-symbols-outlined text-[20px]">add</span>
            <span>+ Add Cash / Bank Account</span>
          </button>
        </div>
      </div>

      {/* Toast Feedback */}
      {reconcileFeedback && (
        <div className="mb-space-md p-space-sm rounded-xl bg-tertiary-fixed text-on-tertiary-fixed text-body-sm font-semibold flex items-center gap-2 animate-in fade-in shadow-xs">
          <span className="material-symbols-outlined text-[18px]">check_circle</span>
          <span>{reconcileFeedback}</span>
        </div>
      )}

      {/* Account Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-space-md mb-space-lg">
        {accounts.map((acc) => {
          const isSelected = activeAccount?.id === acc.id;
          return (
            <div
              key={acc.id}
              onClick={() => setSelectedAccountId(acc.id)}
              className={`p-space-md rounded-2xl shadow-sm transition-all cursor-pointer border flex flex-col justify-between group ${
                isSelected
                  ? 'bg-surface-container-lowest border-primary ring-2 ring-primary/20 shadow-md'
                  : 'bg-surface-container-lowest border-surface-container-high/60 hover:border-surface-container-high'
              }`}
            >
              <div>
                <div className="flex items-start justify-between mb-space-sm gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        acc.type === 'Cash'
                          ? 'bg-tertiary-fixed text-on-tertiary-fixed'
                          : 'bg-primary-fixed text-primary'
                      }`}
                    >
                      <span className="material-symbols-outlined text-[20px]">
                        {acc.type === 'Cash' ? 'payments' : 'account_balance'}
                      </span>
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <h3 className="font-headline-sm text-headline-sm font-semibold text-on-surface leading-tight truncate">
                          {acc.name}
                        </h3>
                        {acc.isDefault && (
                          <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-primary/10 text-primary">
                            Default
                          </span>
                        )}
                      </div>
                      <span className="font-label-sm text-label-sm text-on-surface-variant truncate block">
                        {acc.type === 'Cash' ? 'Depot Safe Vault' : acc.bankName || 'Bank'}
                      </span>
                    </div>
                  </div>

                  {/* Edit and Delete Actions */}
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleStartEdit(acc);
                      }}
                      className="w-7 h-7 rounded-lg text-on-surface-variant hover:text-primary hover:bg-surface-container flex items-center justify-center transition-colors"
                      title="Edit Account"
                    >
                      <span className="material-symbols-outlined text-[17px]">edit</span>
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteAccount(acc);
                      }}
                      className="w-7 h-7 rounded-lg text-on-surface-variant hover:text-error hover:bg-error-container/30 flex items-center justify-center transition-colors"
                      title="Delete Account"
                    >
                      <span className="material-symbols-outlined text-[17px]">delete</span>
                    </button>
                  </div>
                </div>

                <div className="mt-space-md">
                  <span className="font-label-sm text-label-sm text-on-surface-variant uppercase font-semibold block">
                    Available Balance
                  </span>
                  <div className="font-metric-xl text-metric-xl text-on-surface font-bold tracking-tight mt-0.5">
                    Rs. {acc.balance.toLocaleString()}
                  </div>
                  {acc.accountNumber && (
                    <p className="font-mono text-[11px] text-on-surface-variant mt-1 truncate">
                      {acc.accountNumber}
                    </p>
                  )}
                  {acc.branch && (
                    <p className="text-[11px] text-on-surface-variant/80 truncate">
                      Branch: {acc.branch}
                    </p>
                  )}
                </div>
              </div>

              <div className="pt-space-md mt-space-md border-t border-surface-container-high/40 flex items-center justify-between">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDownloadActiveLedgerPDF(acc);
                  }}
                  className="text-on-surface-variant hover:text-primary text-[12px] font-semibold flex items-center gap-1 transition-colors"
                  title="Download PDF Statement"
                >
                  <span className="material-symbols-outlined text-[15px]">download</span>
                  <span>PDF</span>
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    openAccountLedgerModal(acc.id);
                  }}
                  className="text-primary hover:underline text-[12px] font-semibold flex items-center gap-1"
                >
                  <span className="material-symbols-outlined text-[15px]">picture_as_pdf</span>
                  <span>View &amp; Share</span>
                  <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Account Activity Log */}
      {activeAccount && (
        <div className="bg-surface-container-lowest rounded-xl shadow-sm overflow-hidden border border-surface-container-high/40">
          <div className="p-space-md bg-surface-container-lowest flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm border-b border-surface-container-low">
            <div className="flex items-center gap-space-sm">
              <div className="w-3 h-3 rounded-full bg-primary-container" />
              <h2 className="font-headline-md text-headline-md text-on-surface font-semibold">
                {activeAccount.name} Activity
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[11px] bg-secondary-container text-on-secondary-fixed font-semibold">
                Rs. {activeAccount.balance.toLocaleString()}
              </span>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-auto">
              <button
                onClick={() => handleStartEdit(activeAccount)}
                className="px-2.5 h-8 bg-surface-container-low hover:bg-surface-container text-on-surface rounded-lg font-label-sm text-[12px] font-semibold flex items-center gap-1 transition-colors shadow-xs"
                type="button"
                title="Edit Account Details"
              >
                <span className="material-symbols-outlined text-[15px]">edit</span>
                <span>Edit Account</span>
              </button>
              <button
                onClick={() => handleDownloadActiveLedgerPDF(activeAccount)}
                className="px-2.5 h-8 bg-surface-container-low hover:bg-surface-container text-on-surface rounded-lg font-label-sm text-[12px] font-semibold flex items-center gap-1 transition-colors shadow-xs"
                type="button"
                title="Direct PDF file download"
              >
                <span className="material-symbols-outlined text-[15px]">download</span>
                <span>Download PDF</span>
              </button>
              <button
                onClick={() => openAccountLedgerModal(activeAccount.id)}
                className="px-3 h-8 bg-primary text-on-primary hover:bg-primary-container rounded-lg font-label-sm text-[12px] font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
                type="button"
              >
                <span className="material-symbols-outlined text-[15px]">picture_as_pdf</span>
                <span>View &amp; Share PDF</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-body-sm">
              <thead>
                <tr className="bg-surface-container-low h-10 text-on-surface-variant font-label-sm text-label-sm uppercase tracking-wider font-semibold">
                  <th className="py-2.5 px-space-md">Date</th>
                  <th className="py-2.5 px-space-md">Doc #</th>
                  <th className="py-2.5 px-space-md">Type</th>
                  <th className="py-2.5 px-space-md">Party / Details</th>
                  <th className="py-2.5 px-space-md text-right">Inflow (+Rs)</th>
                  <th className="py-2.5 px-space-md text-right">Outflow (-Rs)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-surface-container-low text-on-surface">
                {accountPostings.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-on-surface-variant">
                      No transactions recorded through this account yet.
                    </td>
                  </tr>
                ) : (
                  accountPostings.map((tx) => {
                    const isTransfer = tx.type === 'Transfer';
                    const isOutgoingTransfer = isTransfer && tx.accountId === activeAccount.id;
                    const isIncoming = tx.type === 'Sale' || tx.type === 'Receive' || (isTransfer && !isOutgoingTransfer);
                    const amount = isTransfer ? tx.totalAmount : tx.paidAmount;

                    return (
                      <tr key={tx.id} className="hover:bg-surface-container-low/40 transition-colors h-14">
                        <td className="py-2.5 px-space-md whitespace-nowrap font-medium text-on-surface">
                          {tx.date}
                        </td>
                        <td className="py-2.5 px-space-md whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => openPdfPreview(tx)}
                            className="inline-flex items-center gap-1.5 font-mono text-primary text-[12px] font-semibold hover:underline cursor-pointer focus:outline-none transition-all"
                            title="Click to view & download PDF"
                          >
                            <span className="material-symbols-outlined text-[15px] opacity-75">picture_as_pdf</span>
                            <span>{tx.docNumber}</span>
                          </button>
                        </td>
                        <td className="py-2.5 px-space-md whitespace-nowrap">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              isIncoming
                                ? 'bg-tertiary-fixed text-on-tertiary-fixed'
                                : 'bg-error-container text-on-error-container'
                            }`}
                          >
                            {tx.type}
                          </span>
                        </td>
                        <td className="py-2.5 px-space-md max-w-xs truncate text-on-surface font-medium">
                          {isTransfer
                            ? isOutgoingTransfer
                              ? `Transfer to ${tx.toAccountName}`
                              : `Transfer from ${tx.accountName}`
                            : tx.expenseHeadName
                            ? `Expense: ${tx.expenseHeadName}`
                            : tx.partyName || tx.notes || `${tx.type} entry`}
                        </td>
                        <td className="py-2.5 px-space-md text-right font-bold text-tertiary whitespace-nowrap">
                          {isIncoming ? `+Rs. ${amount.toLocaleString()}` : '-'}
                        </td>
                        <td className="py-2.5 px-space-md text-right font-bold text-error whitespace-nowrap">
                          {!isIncoming ? `-Rs. ${amount.toLocaleString()}` : '-'}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Cash / Bank Account Modal */}
      {addingAccount && (
        <div className="fixed inset-0 bg-inverse-surface/40 backdrop-blur-sm z-50 flex items-center justify-center p-space-md animate-in fade-in duration-150">
          <div className="bg-surface-container-lowest w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-surface-container-high/60">
            <div className="p-space-lg bg-surface-container-low flex items-center justify-between border-b border-surface-container-high/60">
              <h3 className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                Add New Account
              </h3>
              <button
                type="button"
                onClick={() => setAddingAccount(false)}
                className="w-8 h-8 rounded-full hover:bg-surface-container-high flex items-center justify-center text-on-surface-variant"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="p-space-lg space-y-space-md">
              {/* Account Type Selector: Cash vs Bank */}
              <div className="flex flex-col gap-1">
                <label className="font-label-sm text-label-sm text-on-surface font-semibold">Account Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setNewAccType('Cash')}
                    className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 font-semibold text-[13px] transition-all ${
                      newAccType === 'Cash'
                        ? 'bg-tertiary-fixed text-on-tertiary-fixed border-tertiary shadow-xs'
                        : 'bg-surface-container-low text-on-surface border-surface-container-high/60 hover:bg-surface-container'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[18px]">payments</span>
                    <span>Cash in Hand</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setNewAccType('Bank')}
                    className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 font-semibold text-[13px] transition-all ${
                      newAccType === 'Bank'
                        ? 'bg-primary text-on-primary border-primary shadow-xs'
                        : 'bg-surface-container-low text-on-surface border-surface-container-high/60 hover:bg-surface-container'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[18px]">account_balance</span>
                    <span>Bank Account</span>
                  </button>
                </div>
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-label-sm text-label-sm text-on-surface font-semibold">Account Title</label>
                <input
                  type="text"
                  value={newAccName}
                  onChange={(e) => setNewAccName(e.target.value)}
                  placeholder={newAccType === 'Cash' ? 'e.g. Counter Cash / Petty Cash Safe' : 'e.g. Bank Alfalah Operations A/C'}
                  required
                  className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>

              {newAccType === 'Bank' && (
                <>
                  <div className="grid grid-cols-2 gap-space-md">
                    <div className="flex flex-col gap-1">
                      <label className="font-label-sm text-label-sm text-on-surface font-semibold">Bank Name</label>
                      <input
                        type="text"
                        value={newBankName}
                        onChange={(e) => setNewBankName(e.target.value)}
                        placeholder="e.g. HBL, Meezan, Alfalah"
                        className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="font-label-sm text-label-sm text-on-surface font-semibold">Branch Name</label>
                      <input
                        type="text"
                        value={newBranch}
                        onChange={(e) => setNewBranch(e.target.value)}
                        placeholder="Gulberg / Main"
                        className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                      />
                    </div>
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="font-label-sm text-label-sm text-on-surface font-semibold">Account / IBAN Number</label>
                    <input
                      type="text"
                      value={newAccNumber}
                      onChange={(e) => setNewAccNumber(e.target.value)}
                      placeholder="PK..."
                      className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm font-mono text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                    />
                  </div>
                </>
              )}

              {newAccType === 'Cash' && (
                <div className="flex flex-col gap-1">
                  <label className="font-label-sm text-label-sm text-on-surface font-semibold">Location / Vault Desk</label>
                  <input
                    type="text"
                    value={newBranch}
                    onChange={(e) => setNewBranch(e.target.value)}
                    placeholder="e.g. Depot Safe / Cash Counter"
                    className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                </div>
              )}

              <div className="flex flex-col gap-1">
                <label className="font-label-sm text-label-sm text-on-surface font-semibold">Opening Balance (PKR)</label>
                <input
                  type="number"
                  min="0"
                  value={newBalance === 0 ? '' : newBalance}
                  placeholder="0.00"
                  onChange={(e) => setNewBalance(e.target.value === '' ? 0 : Number(e.target.value))}
                  className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm font-bold text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>

              <label className="flex items-center gap-2 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={newIsDefault}
                  onChange={(e) => setNewIsDefault(e.target.checked)}
                  className="w-4 h-4 rounded text-primary focus:ring-primary/20"
                />
                <span className="text-[12px] font-semibold text-on-surface">Set as Default Account</span>
              </label>

              <div className="pt-space-sm flex items-center justify-end gap-space-sm border-t border-surface-container-high/40">
                <button
                  type="button"
                  onClick={() => setAddingAccount(false)}
                  className="px-space-md h-10 text-body-sm rounded-lg bg-surface-container text-on-surface hover:bg-surface-container-high"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-space-lg h-10 text-body-sm font-semibold rounded-lg bg-primary text-on-primary hover:bg-primary-container"
                >
                  Save Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Cash / Bank Account Modal */}
      {editingAccount && (
        <div className="fixed inset-0 bg-inverse-surface/40 backdrop-blur-sm z-50 flex items-center justify-center p-space-md animate-in fade-in duration-150">
          <div className="bg-surface-container-lowest w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-surface-container-high/60">
            <div className="p-space-lg bg-surface-container-low flex items-center justify-between border-b border-surface-container-high/60">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[20px] text-primary">edit</span>
                <h3 className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                  Edit Account: {editingAccount.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingAccount(null)}
                className="w-8 h-8 rounded-full hover:bg-surface-container-high flex items-center justify-center text-on-surface-variant"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="p-space-lg space-y-space-md">
              {/* Type Switcher */}
              <div className="flex flex-col gap-1">
                <label className="font-label-sm text-label-sm text-on-surface font-semibold">Account Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setEditType('Cash')}
                    className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 font-semibold text-[13px] transition-all ${
                      editType === 'Cash'
                        ? 'bg-tertiary-fixed text-on-tertiary-fixed border-tertiary shadow-xs'
                        : 'bg-surface-container-low text-on-surface border-surface-container-high/60 hover:bg-surface-container'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[18px]">payments</span>
                    <span>Cash in Hand</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setEditType('Bank')}
                    className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 font-semibold text-[13px] transition-all ${
                      editType === 'Bank'
                        ? 'bg-primary text-on-primary border-primary shadow-xs'
                        : 'bg-surface-container-low text-on-surface border-surface-container-high/60 hover:bg-surface-container'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[18px]">account_balance</span>
                    <span>Bank Account</span>
                  </button>
                </div>
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-label-sm text-label-sm text-on-surface font-semibold">Account Title</label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  required
                  className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>

              {editType === 'Bank' && (
                <>
                  <div className="grid grid-cols-2 gap-space-md">
                    <div className="flex flex-col gap-1">
                      <label className="font-label-sm text-label-sm text-on-surface font-semibold">Bank Name</label>
                      <input
                        type="text"
                        value={editBankName}
                        onChange={(e) => setEditBankName(e.target.value)}
                        placeholder="e.g. HBL, Meezan, Alfalah"
                        className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="font-label-sm text-label-sm text-on-surface font-semibold">Branch Name</label>
                      <input
                        type="text"
                        value={editBranch}
                        onChange={(e) => setEditBranch(e.target.value)}
                        placeholder="Branch"
                        className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                      />
                    </div>
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="font-label-sm text-label-sm text-on-surface font-semibold">Account / IBAN Number</label>
                    <input
                      type="text"
                      value={editAccNumber}
                      onChange={(e) => setEditAccNumber(e.target.value)}
                      placeholder="PK..."
                      className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm font-mono text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                    />
                  </div>
                </>
              )}

              {editType === 'Cash' && (
                <div className="flex flex-col gap-1">
                  <label className="font-label-sm text-label-sm text-on-surface font-semibold">Location / Vault Desk</label>
                  <input
                    type="text"
                    value={editBranch}
                    onChange={(e) => setEditBranch(e.target.value)}
                    placeholder="e.g. Depot Safe Vault"
                    className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                </div>
              )}

              <div className="flex flex-col gap-1">
                <label className="font-label-sm text-label-sm text-on-surface font-semibold">Current Balance (PKR)</label>
                <input
                  type="number"
                  value={editBalance === 0 ? '' : editBalance}
                  placeholder="0.00"
                  onChange={(e) => setEditBalance(e.target.value === '' ? 0 : Number(e.target.value))}
                  className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm font-bold text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>

              <label className="flex items-center gap-2 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={editIsDefault}
                  onChange={(e) => setEditIsDefault(e.target.checked)}
                  className="w-4 h-4 rounded text-primary focus:ring-primary/20"
                />
                <span className="text-[12px] font-semibold text-on-surface">Set as Default Account</span>
              </label>

              <div className="pt-space-sm flex items-center justify-end gap-space-sm border-t border-surface-container-high/40">
                <button
                  type="button"
                  onClick={() => setEditingAccount(null)}
                  className="px-space-md h-10 text-body-sm rounded-lg bg-surface-container text-on-surface hover:bg-surface-container-high"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-space-lg h-10 text-body-sm font-semibold rounded-lg bg-primary text-on-primary hover:bg-primary-container"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
