import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { MobileNav } from './components/MobileNav';

// Pages
import { Dashboard } from './pages/Dashboard';
import { Inventory } from './pages/Inventory';
import { Transactions } from './pages/Transactions';
import { Parties } from './pages/Parties';
import { AccountsLedgers } from './pages/AccountsLedgers';
import { ProfitLoss } from './pages/ProfitLoss';
import { Expenses } from './pages/Expenses';
import { Settings } from './pages/Settings';

// Modals & Drawers
import { TransactionModal } from './components/modals/TransactionModal';
import { ProductDrawer } from './components/modals/ProductDrawer';
import { PartyModal } from './components/modals/PartyModal';
import { ViewTransactionModal } from './components/modals/ViewTransactionModal';
import { AccountTransferModal } from './components/modals/AccountTransferModal';
import { JournalEntryModal } from './components/modals/JournalEntryModal';
import { PDFPreviewModal } from './components/modals/PDFPreviewModal';
import { ReconciliationModal } from './components/modals/ReconciliationModal';

const MainLayout: React.FC = () => {
  const { activeTab } = useApp();

  return (
    <div className="min-h-screen bg-surface font-sans text-on-surface antialiased flex flex-col selection:bg-primary-container selection:text-on-primary">
      {/* Desktop & Mobile Sidebar */}
      <Sidebar />

      {/* Main Administrative Desk Canvas */}
      <div className="lg:pl-[240px] min-h-screen flex flex-col flex-1">
        {/* Top Header */}
        <Header />

        {/* Dynamic Route Viewport */}
        <main className="w-full pt-20 bg-surface px-space-sm sm:px-space-md lg:px-space-lg min-h-screen flex-1 pb-28 lg:pb-margin-lg">
          {activeTab === 'dashboard' && <Dashboard />}
          {activeTab === 'inventory' && <Inventory />}
          {activeTab === 'transactions' && <Transactions />}
          {activeTab === 'parties' && <Parties />}
          {activeTab === 'accounts-ledgers' && <AccountsLedgers />}
          {activeTab === 'profit-loss' && <ProfitLoss />}
          {activeTab === 'expenses' && <Expenses />}
          {activeTab === 'settings' && <Settings />}
        </main>
      </div>

      {/* Mobile Floating Bottom Navigation Dock */}
      <MobileNav />

      {/* Modals & Slide-over Drawers */}
      <TransactionModal />
      <ProductDrawer />
      <PartyModal />
      <ViewTransactionModal />
      <AccountTransferModal />
      <JournalEntryModal />
      <PDFPreviewModal />
      <ReconciliationModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
