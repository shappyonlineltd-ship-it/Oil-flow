export interface ExpenseHead {
  id: string;
  name: string;
  category: string;
  description?: string;
  createdAt: string;
}

export type UnitType = 'Drum' | 'Liter' | 'Kg' | 'Bottle' | 'Can' | 'Piece' | 'Bucket';

export type ProductCategory = 
  | 'Base Oils'
  | 'Engine Oils'
  | 'Gear Oils'
  | 'Greases'
  | 'Industrial Oils'
  | 'Transmission Fluids'
  | 'Additives';

export interface Product {
  id: string;
  name: string;
  grade: string;
  description: string;
  category: ProductCategory;
  unit: UnitType;
  packingSize: number; // e.g. 200 for 200L Drum, 4 for 4L Can, 1 for 1L Bottle
  packingUnit: 'Liter' | 'Kg' | 'Piece';
  currentStock: number; // in unit count (e.g., 14 drums)
  purchaseCost: number; // PKR per unit (e.g., 22500 per drum)
  salePrice: number; // PKR per unit
  minAlertThreshold: number; // e.g., 5 drums
  tankLocation?: string; // e.g. 'Tank #1', 'Storage Yard B'
  createdAt: string;
}

export type PartyType = 'Customer' | 'Supplier' | 'Both';

export interface Party {
  id: string;
  name: string;
  type: PartyType;
  phone: string;
  email?: string;
  address: string;
  city: string;
  currentBalance: number; // Positive = Receivable (they owe us), Negative = Payable (we owe them)
  openingBalance?: number;
  creditLimit?: number;
  notes?: string;
  createdAt: string;
}

export type AccountType = 'Cash' | 'Bank';

export interface Account {
  id: string;
  name: string;
  type: AccountType;
  accountNumber?: string;
  bankName?: string;
  balance: number;
  openingBalance?: number;
  branch?: string;
  isDefault?: boolean;
}

export interface AccountReconciliationItem {
  id: string;
  name: string;
  type: AccountType;
  bankName?: string;
  openingBalance: number;
  totalInflow: number;
  totalOutflow: number;
  calculatedBalance: number;
  recordedBalance: number;
  difference: number;
  transactionCount: number;
  status: 'balanced' | 'discrepancy';
}

export interface PartyReconciliationItem {
  id: string;
  name: string;
  type: PartyType;
  openingBalance: number;
  totalInvoiced: number;
  totalSettled: number;
  calculatedBalance: number;
  recordedBalance: number;
  difference: number;
  transactionCount: number;
  status: 'balanced' | 'discrepancy';
}

export interface StockReconciliationItem {
  id: string;
  name: string;
  grade: string;
  unit: UnitType;
  totalPurchased: number;
  totalSold: number;
  recordedStock: number;
  calculatedStockDelta: number;
}

export interface ReconciliationReport {
  timestamp: string;
  accounts: AccountReconciliationItem[];
  parties: PartyReconciliationItem[];
  stock: StockReconciliationItem[];
  cleanedGhostTransactionsCount: number;
  totalDiscrepanciesCount: number;
  hasDiscrepancies: boolean;
}

export type TransactionType = 'Purchase' | 'Sale' | 'Receive' | 'Pay' | 'Transfer';
export type PaymentStatus = 'Paid' | 'Partial' | 'Pending';

export interface TransactionItem {
  id: string;
  productId: string;
  productName: string;
  packagingUnit: string;
  quantity: number; // Number of packaging units (e.g. 10 drums)
  packingSize: number; // e.g. 200 liters per drum
  totalVolume: number; // quantity * packingSize (e.g. 2000 liters)
  unitPrice: number; // Price per packaging unit (e.g. Rs. 22,500/drum)
  subtotal: number;
}

export interface Transaction {
  id: string;
  docNumber: string; // e.g. 'INV-2024-089', 'TR-1041'
  type: TransactionType;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM AM/PM
  partyId?: string;
  partyName?: string;
  expenseHeadId?: string;
  expenseHeadName?: string;
  accountId?: string;
  accountName?: string;
  toAccountId?: string; // For Account Transfers
  toAccountName?: string; // For Account Transfers
  items: TransactionItem[];
  totalAmount: number;
  paidAmount: number;
  balanceDue: number;
  paymentStatus: PaymentStatus;
  notes?: string;
  createdAt: string;
}

export interface LedgerEntry {
  id: string;
  transactionId: string;
  docNumber: string;
  date: string;
  partyId?: string;
  partyName?: string;
  expenseHeadId?: string;
  expenseHeadName?: string;
  accountId?: string;
  accountName?: string;
  type: TransactionType;
  description: string;
  debit: number;
  credit: number;
  balanceAfter: number;
}

export interface AppSettings {
  businessName: string;
  depotName: string;
  ownerName: string;
  currencySymbol: string;
  minStockAlertSound: boolean;
}

export type NavTab = 'dashboard' | 'inventory' | 'transactions' | 'parties' | 'accounts-ledgers' | 'profit-loss' | 'expenses' | 'settings';

export interface ProductLedgerRow {
  id: string;
  transactionId?: string;
  docNumber: string;
  date: string;
  time?: string;
  type: string;
  partyName: string;
  partyId?: string;
  rate: number;
  qtyIn: number;
  qtyOut: number;
  volumeIn: number;
  volumeOut: number;
  runningBalance: number;
  runningVolume: number;
  totalValue: number;
  notes?: string;
  rawTx?: Transaction;
}

