import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Account, Party, Transaction, AppSettings, ReconciliationReport, Product, ProductLedgerRow } from '../types';

export interface AccountLedgerRow {
  date: string;
  docNumber: string;
  type: string;
  description: string;
  inflow: number;
  outflow: number;
  runningBalance: number;
}

export interface PartyLedgerRow {
  date: string;
  docNumber: string;
  type: string;
  description: string;
  debit: number;
  credit: number;
  runningBalance: number;
}

export function generateAccountLedgerPDF(
  account: Account,
  rows: AccountLedgerRow[],
  settings?: AppSettings
) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const businessName = settings?.businessName || 'OILFLOW PETROLEUM & LUBRICANTS';
  const depotName = settings?.depotName || 'Central Depot & Terminal Operations';

  // Header banner
  doc.setFillColor(84, 48, 156); // Primary Brand color #54309c
  doc.rect(0, 0, 210, 26, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text(businessName, 14, 11);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`${depotName} · Official Account Ledger Statement`, 14, 18);
  doc.text(`Generated: ${new Date().toLocaleString()}`, 196, 18, { align: 'right' });

  // Account Details Box
  doc.setTextColor(20, 30, 45);
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text(account.name, 14, 35);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(80, 80, 90);
  const typeStr = account.type === 'Cash' ? 'Depot Cash Vault Book' : `Bank Account (${account.bankName || 'Bank'})`;
  const acctStr = account.accountNumber ? `Account #: ${account.accountNumber}` : 'General Cash Account';
  const branchStr = account.branch ? ` · Branch: ${account.branch}` : '';
  doc.text(`${typeStr} · ${acctStr}${branchStr}`, 14, 41);

  // Financial summary pills
  const totalInflow = rows.reduce((s, r) => s + r.inflow, 0);
  const totalOutflow = rows.reduce((s, r) => s + r.outflow, 0);

  // Draw light grey container
  doc.setFillColor(242, 246, 255);
  doc.setDrawColor(220, 230, 245);
  doc.roundedRect(14, 46, 182, 18, 2, 2, 'FD');

  doc.setFontSize(8);
  doc.setTextColor(100, 100, 115);
  doc.text('TOTAL INFLOW', 20, 52);
  doc.text('TOTAL OUTFLOW', 80, 52);
  doc.text('CURRENT AVAILABLE BALANCE', 140, 52);

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0, 100, 40); // Green
  doc.text(`+Rs. ${totalInflow.toLocaleString()}`, 20, 59);

  doc.setTextColor(180, 20, 20); // Red
  doc.text(`-Rs. ${totalOutflow.toLocaleString()}`, 80, 59);

  doc.setTextColor(20, 30, 45); // Dark
  doc.text(`Rs. ${account.balance.toLocaleString()}`, 140, 59);

  // Table
  const tableData = rows.map((r) => [
    r.date,
    r.docNumber,
    r.type,
    r.description,
    r.inflow > 0 ? `+${r.inflow.toLocaleString()}` : '-',
    r.outflow > 0 ? `-${r.outflow.toLocaleString()}` : '-',
    `Rs. ${r.runningBalance.toLocaleString()}`,
  ]);

  autoTable(doc, {
    startY: 70,
    head: [['Date', 'Doc #', 'Type', 'Description / Details', 'Inflow (PKR)', 'Outflow (PKR)', 'Running Bal']],
    body: tableData.length > 0 ? tableData : [['-', '-', '-', 'No transactions recorded', '-', '-', '-']],
    theme: 'grid',
    headStyles: {
      fillColor: [84, 48, 156],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8,
      halign: 'left',
    },
    bodyStyles: {
      fontSize: 8,
      textColor: [30, 30, 35],
    },
    columnStyles: {
      0: { cellWidth: 22 },
      1: { cellWidth: 24, fontStyle: 'bold' },
      2: { cellWidth: 18 },
      3: { cellWidth: 'auto' },
      4: { cellWidth: 24, halign: 'right', textColor: [0, 100, 40] },
      5: { cellWidth: 24, halign: 'right', textColor: [180, 20, 20] },
      6: { cellWidth: 26, halign: 'right', fontStyle: 'bold' },
    },
    alternateRowStyles: {
      fillColor: [248, 250, 254],
    },
    margin: { left: 14, right: 14 },
    foot: [
      [
        'Total',
        '',
        '',
        `${rows.length} total postings`,
        `+Rs. ${totalInflow.toLocaleString()}`,
        `-Rs. ${totalOutflow.toLocaleString()}`,
        `Rs. ${account.balance.toLocaleString()}`,
      ],
    ],
    footStyles: {
      fillColor: [230, 238, 255],
      textColor: [20, 30, 50],
      fontStyle: 'bold',
      fontSize: 8,
    },
  });

  // Footer Signatures
  const finalY = (doc as any).lastAutoTable?.finalY || 240;
  const sigY = Math.min(270, Math.max(finalY + 18, 250));

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(110, 110, 120);

  doc.line(16, sigY, 65, sigY);
  doc.text('Prepared By (Accounts Officer)', 16, sigY + 5);

  doc.line(145, sigY, 194, sigY);
  doc.text('Authorized Signatory & Stamp', 145, sigY + 5);

  doc.text('This is a computer generated ledger statement from OilFlow System.', 14, sigY + 12);

  doc.save(`Ledger_${account.name.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.pdf`);
}

export function generatePartyLedgerPDF(
  party: Party,
  rows: PartyLedgerRow[],
  settings?: AppSettings
) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const businessName = settings?.businessName || 'OILFLOW PETROLEUM & LUBRICANTS';
  const depotName = settings?.depotName || 'Central Depot & Terminal Operations';

  // Header banner
  doc.setFillColor(84, 48, 156);
  doc.rect(0, 0, 210, 26, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text(businessName, 14, 11);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`${depotName} · Party Account Ledger Statement`, 14, 18);
  doc.text(`Generated: ${new Date().toLocaleString()}`, 196, 18, { align: 'right' });

  // Party Details
  doc.setTextColor(20, 30, 45);
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text(party.name, 14, 35);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(80, 80, 90);
  doc.text(`Type: ${party.type} · Phone: ${party.phone || 'N/A'} · City: ${party.city}`, 14, 41);
  if (party.address) {
    doc.text(`Address: ${party.address}`, 14, 46);
  }

  // Summary box
  const totalDebit = rows.reduce((s, r) => s + r.debit, 0);
  const totalCredit = rows.reduce((s, r) => s + r.credit, 0);
  const isReceivable = party.currentBalance >= 0;

  doc.setFillColor(242, 246, 255);
  doc.setDrawColor(220, 230, 245);
  doc.roundedRect(14, 50, 182, 18, 2, 2, 'FD');

  doc.setFontSize(8);
  doc.setTextColor(100, 100, 115);
  doc.text('TOTAL DEBIT', 20, 56);
  doc.text('TOTAL CREDIT', 80, 56);
  doc.text('CURRENT NET BALANCE', 140, 56);

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(20, 30, 45);
  doc.text(`Rs. ${totalDebit.toLocaleString()}`, 20, 63);
  doc.text(`Rs. ${totalCredit.toLocaleString()}`, 80, 63);

  if (isReceivable) {
    doc.setTextColor(0, 100, 40); // Green receivable
    doc.text(`Rs. ${Math.abs(party.currentBalance).toLocaleString()} (Receivable)`, 140, 63);
  } else {
    doc.setTextColor(180, 20, 20); // Red payable
    doc.text(`Rs. ${Math.abs(party.currentBalance).toLocaleString()} (Payable)`, 140, 63);
  }

  // Table
  const tableData = rows.map((r) => [
    r.date,
    r.docNumber,
    r.type,
    r.description,
    r.debit > 0 ? `Rs. ${r.debit.toLocaleString()}` : '-',
    r.credit > 0 ? `Rs. ${r.credit.toLocaleString()}` : '-',
    `Rs. ${Math.abs(r.runningBalance).toLocaleString()} ${r.runningBalance >= 0 ? 'Dr' : 'Cr'}`,
  ]);

  autoTable(doc, {
    startY: 74,
    head: [['Date', 'Doc #', 'Type', 'Description / Goods', 'Debit (Rs.)', 'Credit (Rs.)', 'Balance']],
    body: tableData.length > 0 ? tableData : [['-', '-', '-', 'No entries recorded yet', '-', '-', '-']],
    theme: 'grid',
    headStyles: {
      fillColor: [84, 48, 156],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8,
      halign: 'left',
    },
    bodyStyles: {
      fontSize: 8,
      textColor: [30, 30, 35],
    },
    columnStyles: {
      0: { cellWidth: 22 },
      1: { cellWidth: 24, fontStyle: 'bold' },
      2: { cellWidth: 20 },
      3: { cellWidth: 'auto' },
      4: { cellWidth: 24, halign: 'right' },
      5: { cellWidth: 24, halign: 'right' },
      6: { cellWidth: 28, halign: 'right', fontStyle: 'bold' },
    },
    alternateRowStyles: {
      fillColor: [248, 250, 254],
    },
    margin: { left: 14, right: 14 },
    foot: [
      [
        'Total',
        '',
        '',
        `${rows.length} total entries`,
        `Rs. ${totalDebit.toLocaleString()}`,
        `Rs. ${totalCredit.toLocaleString()}`,
        `Rs. ${Math.abs(party.currentBalance).toLocaleString()} ${party.currentBalance >= 0 ? 'Dr' : 'Cr'}`,
      ],
    ],
    footStyles: {
      fillColor: [230, 238, 255],
      textColor: [20, 30, 50],
      fontStyle: 'bold',
      fontSize: 8,
    },
  });

  const finalY = (doc as any).lastAutoTable?.finalY || 240;
  const sigY = Math.min(270, Math.max(finalY + 18, 250));

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(110, 110, 120);

  doc.line(16, sigY, 65, sigY);
  doc.text('Accountant Signature', 16, sigY + 5);

  doc.line(145, sigY, 194, sigY);
  doc.text('Customer / Authorized Seal', 145, sigY + 5);

  doc.text('Thank you for your business. OilFlow Petroleum & Lubricants.', 14, sigY + 12);

  doc.save(`Party_Ledger_${party.name.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.pdf`);
}

export function generateProductLedgerPDF(
  product: Product,
  rows: ProductLedgerRow[],
  settings?: AppSettings
) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const businessName = settings?.businessName || 'OILFLOW PETROLEUM & LUBRICANTS';
  const depotName = settings?.depotName || 'Central Depot & Terminal Operations';

  // Header banner
  doc.setFillColor(84, 48, 156);
  doc.rect(0, 0, 210, 26, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text(businessName, 14, 11);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`${depotName} · Product Stock Movement Ledger`, 14, 18);
  doc.text(`Generated: ${new Date().toLocaleString()}`, 196, 18, { align: 'right' });

  // Product Details
  doc.setTextColor(20, 30, 45);
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text(product.name, 14, 35);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(80, 80, 90);
  const sizeStr = `${product.packingSize} ${product.packingUnit} ${product.unit}`;
  doc.text(
    `Grade: ${product.grade} · Category: ${product.category} · Pack Size: ${sizeStr} · Location: ${product.tankLocation || 'Warehouse Main Bay'}`,
    14,
    41
  );

  // Financial & Stock summary box
  const totalIn = rows.reduce((s, r) => s + r.qtyIn, 0);
  const totalOut = rows.reduce((s, r) => s + r.qtyOut, 0);
  const currentValuation = product.currentStock * product.purchaseCost;

  doc.setFillColor(242, 246, 255);
  doc.setDrawColor(220, 230, 245);
  doc.roundedRect(14, 47, 182, 18, 2, 2, 'FD');

  doc.setFontSize(8);
  doc.setTextColor(100, 100, 115);
  doc.text('TOTAL INWARD (+)', 20, 53);
  doc.text('TOTAL OUTWARD (-)', 75, 53);
  doc.text('CURRENT STOCK ON HAND', 130, 53);

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0, 100, 40); // Green
  doc.text(`+${totalIn.toLocaleString()} ${product.unit}s`, 20, 60);

  doc.setTextColor(180, 20, 20); // Red
  doc.text(`-${totalOut.toLocaleString()} ${product.unit}s`, 75, 60);

  doc.setTextColor(20, 30, 45);
  doc.text(`${product.currentStock.toLocaleString()} ${product.unit}s (Rs. ${currentValuation.toLocaleString()})`, 130, 60);

  // Table
  const tableData = rows.map((r) => [
    r.date,
    r.docNumber,
    r.type,
    r.partyName || '-',
    r.rate > 0 ? `Rs. ${r.rate.toLocaleString()}` : '-',
    r.qtyIn > 0 ? `+${r.qtyIn}` : '-',
    r.qtyOut > 0 ? `-${r.qtyOut}` : '-',
    `${r.runningBalance} ${product.unit}s`,
    r.totalValue > 0 ? `Rs. ${r.totalValue.toLocaleString()}` : '-',
  ]);

  autoTable(doc, {
    startY: 72,
    head: [['Date', 'Doc #', 'Movement', 'Party / Remarks', 'Rate', 'In (+)', 'Out (-)', 'Balance', 'Value']],
    body: tableData.length > 0 ? tableData : [['-', '-', '-', 'No movement history recorded yet', '-', '-', '-', '-', '-']],
    theme: 'grid',
    headStyles: {
      fillColor: [84, 48, 156],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8,
      halign: 'left',
    },
    bodyStyles: {
      fontSize: 7.5,
      textColor: [30, 30, 35],
    },
    columnStyles: {
      0: { cellWidth: 20 },
      1: { cellWidth: 22, fontStyle: 'bold' },
      2: { cellWidth: 20 },
      3: { cellWidth: 'auto' },
      4: { cellWidth: 18, halign: 'right' },
      5: { cellWidth: 14, halign: 'right' },
      6: { cellWidth: 14, halign: 'right' },
      7: { cellWidth: 20, halign: 'right', fontStyle: 'bold' },
      8: { cellWidth: 22, halign: 'right' },
    },
    alternateRowStyles: {
      fillColor: [248, 250, 254],
    },
    margin: { left: 14, right: 14 },
    foot: [
      [
        'Closing Stock',
        '',
        '',
        `${rows.length} total movement records`,
        '',
        `+${totalIn}`,
        `-${totalOut}`,
        `${product.currentStock} ${product.unit}s`,
        `Rs. ${currentValuation.toLocaleString()}`,
      ],
    ],
    footStyles: {
      fillColor: [230, 238, 255],
      textColor: [20, 30, 50],
      fontStyle: 'bold',
      fontSize: 8,
    },
  });

  const finalY = (doc as any).lastAutoTable?.finalY || 240;
  const sigY = Math.min(270, Math.max(finalY + 18, 250));

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(110, 110, 120);

  doc.line(16, sigY, 65, sigY);
  doc.text('Warehouse In-charge', 16, sigY + 5);

  doc.line(145, sigY, 194, sigY);
  doc.text('Authorized Signatory & Stamp', 145, sigY + 5);

  doc.text('Computer generated Stock Ledger report from OilFlow Management System.', 14, sigY + 12);

  doc.save(`Product_Ledger_${product.name.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.pdf`);
}

/**
 * Universal PDF Generator for Sales Invoices, Purchase Orders, and Transaction Vouchers
 */
export function generateTransactionPDF(
  tx: Transaction,
  settings?: AppSettings,
  party?: Party,
  account?: Account,
  action: 'download' | 'blob' = 'download'
): string | void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const businessName = settings?.businessName || 'OILFLOW PETROLEUM & LUBRICANTS';
  const depotName = settings?.depotName || 'Central Depot & Terminal Operations';

  const isSale = tx.type === 'Sale';
  const isPurchase = tx.type === 'Purchase';
  const isReceive = tx.type === 'Receive';
  const isPay = tx.type === 'Pay';
  const isTransfer = tx.type === 'Transfer';
  const isJV = tx.docNumber?.startsWith('JV');

  let docTitle = 'TRANSACTION VOUCHER';
  let themeColor: [number, number, number] = [84, 48, 156]; // Brand purple
  let filePrefix = 'Transaction';

  if (isJV) {
    docTitle = 'OFFICIAL JOURNAL VOUCHER';
    themeColor = [84, 48, 156];
    filePrefix = 'Journal_Voucher';
  } else if (isSale) {
    docTitle = 'COMMERCIAL SALES INVOICE';
    themeColor = [84, 48, 156]; // Primary purple
    filePrefix = 'Sales_Invoice';
  } else if (isPurchase) {
    docTitle = 'PURCHASE ORDER & INTAKE BILL';
    themeColor = [15, 118, 110]; // Professional teal for procurement
    filePrefix = 'Purchase_Order';
  } else if (isReceive) {
    docTitle = 'OFFICIAL PAYMENT RECEIPT';
    themeColor = [16, 120, 60]; // Emerald green
    filePrefix = 'Payment_Receipt';
  } else if (isPay) {
    docTitle = 'PAYMENT DISBURSEMENT VOUCHER';
    themeColor = [185, 28, 28]; // Red
    filePrefix = 'Payment_Voucher';
  } else if (isTransfer) {
    docTitle = 'FUNDS TRANSFER VOUCHER';
    themeColor = [67, 56, 202]; // Indigo
    filePrefix = 'Transfer_Voucher';
  }

  // Header Banner
  doc.setFillColor(themeColor[0], themeColor[1], themeColor[2]);
  doc.rect(0, 0, 210, 28, 'F');

  // Business Name & Title
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(15);
  doc.setFont('helvetica', 'bold');
  doc.text(businessName, 14, 11);

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.text(`${depotName} · Bulk Petroleum & Packaging Terminal`, 14, 18);
  doc.text(`Official Terminal Accounting Document`, 14, 23);

  // Right Side Header Badge
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text(docTitle, 196, 11, { align: 'right' });

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`Doc #: ${tx.docNumber}`, 196, 18, { align: 'right' });
  doc.text(`Date: ${tx.date}  Time: ${tx.time || ''}`, 196, 23, { align: 'right' });

  // Information panel: Counterparty / Party info
  const startY = 33;

  doc.setFillColor(248, 250, 254);
  doc.setDrawColor(220, 228, 240);
  doc.roundedRect(14, startY, 182, 22, 2, 2, 'FD');

  doc.setTextColor(100, 105, 120);
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'bold');
  const partyLabel = isJV
    ? 'JOURNAL ACCOUNT / ENTITY:'
    : isSale
    ? 'BILL TO (CUSTOMER / BUYER):'
    : isPurchase
    ? 'VENDOR / SUPPLIER (PURCHASE FROM):'
    : isReceive
    ? 'RECEIVED FROM (CLIENT):'
    : isPay
    ? 'PAID TO (BENEFICIARY):'
    : 'TRANSFER DETAILS:';
  doc.text(partyLabel, 18, startY + 6);

  doc.setTextColor(20, 30, 45);
  doc.setFontSize(10.5);
  doc.setFont('helvetica', 'bold');
  const partyName = tx.expenseHeadName || tx.partyName || (party ? party.name : 'Counter Walk-in Client');
  doc.text(partyName, 18, startY + 12);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(70, 75, 85);

  const phoneText = party?.phone ? `Phone: ${party.phone}` : '';
  const cityText = party?.city ? `City: ${party.city}` : '';
  const addrText = party?.address ? `Address: ${party.address}` : '';
  const contactLine = [phoneText, cityText, addrText].filter(Boolean).join(' · ');
  if (contactLine) {
    doc.text(contactLine.slice(0, 95), 18, startY + 17.5);
  }

  // Products Table
  const tableStartY = startY + 27;
  const hasItems = tx.items && tx.items.length > 0;

  let tableData: any[][] = [];
  if (hasItems) {
    tableData = tx.items.map((it, idx) => [
      idx + 1,
      it.productName,
      it.packagingUnit || 'Unit',
      it.quantity.toString(),
      `${it.totalVolume} L/Kg`,
      `Rs. ${it.unitPrice.toLocaleString()}`,
      `Rs. ${it.subtotal.toLocaleString()}`,
    ]);
  } else {
    tableData = [
      [
        1,
        tx.notes || `${tx.type} Transaction Entry`,
        'Voucher',
        '1',
        '-',
        `Rs. ${tx.totalAmount.toLocaleString()}`,
        `Rs. ${tx.totalAmount.toLocaleString()}`,
      ],
    ];
  }

  const totalQty = hasItems ? tx.items.reduce((s, it) => s + it.quantity, 0) : 1;
  const totalVol = hasItems ? tx.items.reduce((s, it) => s + it.totalVolume, 0) : 0;

  autoTable(doc, {
    startY: tableStartY,
    head: [['#', isPurchase ? 'Item & Specification Ordered' : 'Product / Item Description', 'Packing', 'Qty', 'Total Vol', 'Rate (PKR)', 'Subtotal (PKR)']],
    body: tableData,
    theme: 'grid',
    headStyles: {
      fillColor: themeColor,
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8,
      halign: 'left',
    },
    bodyStyles: {
      fontSize: 8,
      textColor: [30, 35, 45],
    },
    columnStyles: {
      0: { cellWidth: 10, halign: 'center' },
      1: { cellWidth: 'auto', fontStyle: 'bold' },
      2: { cellWidth: 20, halign: 'center' },
      3: { cellWidth: 16, halign: 'center' },
      4: { cellWidth: 24, halign: 'right' },
      5: { cellWidth: 28, halign: 'right' },
      6: { cellWidth: 32, halign: 'right', fontStyle: 'bold' },
    },
    alternateRowStyles: {
      fillColor: [248, 250, 254],
    },
    margin: { left: 14, right: 14 },
    foot: [
      [
        'Total',
        hasItems ? `${tx.items.length} line item(s)` : 'Entry total',
        '',
        totalQty.toString(),
        totalVol > 0 ? `${totalVol} L/Kg` : '-',
        '',
        `Rs. ${tx.totalAmount.toLocaleString()}`,
      ],
    ],
    footStyles: {
      fillColor: [235, 242, 255],
      textColor: [20, 30, 50],
      fontStyle: 'bold',
      fontSize: 8,
    },
  });

  const afterTableY = (doc as any).lastAutoTable?.finalY || 160;

  // Totals & Financial Summary Card
  const summaryBoxY = afterTableY + 6;
  doc.setFillColor(246, 249, 255);
  doc.setDrawColor(215, 225, 240);
  doc.roundedRect(120, summaryBoxY, 76, 28, 2, 2, 'FD');

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(80, 85, 95);

  doc.text('Gross Document Total:', 124, summaryBoxY + 7);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(20, 30, 45);
  doc.text(`Rs. ${tx.totalAmount.toLocaleString()}`, 192, summaryBoxY + 7, { align: 'right' });

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(80, 85, 95);
  doc.text('Cleared / Paid Amount:', 124, summaryBoxY + 14);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0, 110, 45);
  doc.text(`Rs. ${tx.paidAmount.toLocaleString()}`, 192, summaryBoxY + 14, { align: 'right' });

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(80, 85, 95);
  doc.text('Net Balance Due on Account:', 124, summaryBoxY + 21);
  doc.setFont('helvetica', 'bold');
  if (tx.balanceDue > 0) {
    doc.setTextColor(180, 20, 20);
    doc.text(`Rs. ${tx.balanceDue.toLocaleString()}`, 192, summaryBoxY + 21, { align: 'right' });
  } else {
    doc.setTextColor(0, 110, 45);
    doc.text('Rs. 0 (Cleared)', 192, summaryBoxY + 21, { align: 'right' });
  }

  // Notes & Remarks Box
  doc.setFillColor(250, 250, 252);
  doc.setDrawColor(225, 230, 240);
  doc.roundedRect(14, summaryBoxY, 100, 28, 2, 2, 'FD');

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(90, 95, 105);
  doc.text('TERMS & DISPATCH REMARKS:', 18, summaryBoxY + 6);

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(60, 65, 75);

  if (tx.notes) {
    doc.text(`Memo / Ref: ${tx.notes}`, 18, summaryBoxY + 12);
  } else {
    doc.text('Standard commercial petroleum supply terms apply.', 18, summaryBoxY + 12);
  }

  const termsText = isPurchase
    ? 'All goods subject to laboratory gravity test and seal inspection upon tanker unloading.'
    : 'Goods received in sound order. Drums non-returnable unless empty deposit recorded.';
  doc.text(termsText, 18, summaryBoxY + 18);
  doc.text('All disputes subject to provincial commercial jurisdiction.', 18, summaryBoxY + 23);

  // Signatures
  const sigY = Math.min(270, Math.max(summaryBoxY + 36, 245));
  doc.setDrawColor(160, 165, 180);
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(90, 95, 105);

  doc.line(16, sigY, 70, sigY);
  const leftSig = isPurchase
    ? 'Vendor / Driver Delivery Sign & CNIC'
    : 'Customer / Receiver Signature & Stamp';
  doc.text(leftSig, 16, sigY + 5);

  doc.line(136, sigY, 194, sigY);
  const rightSig = isPurchase
    ? 'Depot Receiving Officer & Quality Stamp'
    : 'Authorized Signatory & Depot Stamp';
  doc.text(rightSig, 136, sigY + 5);

  doc.setFontSize(7);
  doc.setTextColor(130, 135, 145);
  doc.text(
    `Official electronic document generated by OilFlow Petroleum Operating System · ${new Date().toLocaleString()}`,
    14,
    sigY + 12
  );

  const cleanDoc = tx.docNumber.replace(/[^a-zA-Z0-9_-]/g, '_');
  const fileName = `${filePrefix}_${cleanDoc}_${tx.date}.pdf`;

  if (action === 'blob') {
    const blob = doc.output('blob');
    return URL.createObjectURL(blob);
  }

  doc.save(fileName);
}

export function generateSalesInvoicePDF(
  tx: Transaction,
  settings?: AppSettings,
  party?: Party,
  account?: Account,
  action: 'download' | 'blob' = 'download'
): string | void {
  return generateTransactionPDF(tx, settings, party, account, action);
}

export function generatePurchaseOrderPDF(
  tx: Transaction,
  settings?: AppSettings,
  party?: Party,
  account?: Account,
  action: 'download' | 'blob' = 'download'
): string | void {
  return generateTransactionPDF(tx, settings, party, account, action);
}

/**
 * Generates high-fidelity, print-ready HTML document for iframe preview
 */
export function generateTransactionHTML(
  tx: Transaction,
  settings?: AppSettings,
  party?: Party,
  account?: Account
): string {
  const businessName = settings?.businessName || 'OILFLOW PETROLEUM & LUBRICANTS';
  const depotName = settings?.depotName || 'Central Depot & Terminal Operations';

  const isSale = tx.type === 'Sale';
  const isPurchase = tx.type === 'Purchase';
  const isReceive = tx.type === 'Receive';
  const isPay = tx.type === 'Pay';
  const isTransfer = tx.type === 'Transfer';
  const isJV = tx.docNumber?.startsWith('JV');

  let docTitle = 'TRANSACTION VOUCHER';
  let themeColor = '#54309c'; // Purple
  let themeBadge = 'VOUCHER';

  if (isJV) {
    docTitle = 'OFFICIAL JOURNAL VOUCHER';
    themeColor = '#54309c';
    themeBadge = 'JOURNAL VOUCHER';
  } else if (isSale) {
    docTitle = 'COMMERCIAL SALES INVOICE';
    themeColor = '#54309c';
    themeBadge = 'SALES INVOICE';
  } else if (isPurchase) {
    docTitle = 'PURCHASE ORDER & INTAKE BILL';
    themeColor = '#0f766e';
    themeBadge = 'PURCHASE BILL';
  } else if (isReceive) {
    docTitle = 'OFFICIAL PAYMENT RECEIPT';
    themeColor = '#10783c';
    themeBadge = 'PAYMENT RECEIPT';
  } else if (isPay) {
    docTitle = 'PAYMENT DISBURSEMENT VOUCHER';
    themeColor = '#b91c1c';
    themeBadge = 'DISBURSEMENT VOUCHER';
  } else if (isTransfer) {
    docTitle = 'FUNDS TRANSFER VOUCHER';
    themeColor = '#4338ca';
    themeBadge = 'TRANSFER VOUCHER';
  }

  const partyLabel = isJV
    ? 'JOURNAL ACCOUNT / ENTITY:'
    : isSale
    ? 'BILL TO (CUSTOMER / BUYER):'
    : isPurchase
    ? 'VENDOR / SUPPLIER (PURCHASE FROM):'
    : isReceive
    ? 'RECEIVED FROM (CLIENT):'
    : isPay
    ? 'PAID TO (BENEFICIARY):'
    : 'TRANSFER DETAILS:';

  const partyName = tx.expenseHeadName || tx.partyName || (party ? party.name : 'Counter Walk-in Client');
  const acctName = tx.accountName || account?.name || 'Cash Safe Vault';
  const paymentStatus = tx.paymentStatus || 'Paid';
  const totalAmount = tx.totalAmount ?? 0;
  const paidAmount = tx.paidAmount ?? 0;
  const balanceDue = tx.balanceDue ?? 0;

  const hasItems = tx.items && tx.items.length > 0;

  const itemsHtml = hasItems
    ? tx.items
        .map(
          (it, idx) => `
        <tr>
          <td style="text-align: center;">${idx + 1}</td>
          <td><strong>${it.productName || 'Product'}</strong></td>
          <td style="text-align: center;">${it.packagingUnit || 'Unit'}</td>
          <td style="text-align: center;">${it.quantity ?? 1}</td>
          <td style="text-align: right;">${it.totalVolume ?? 0} L/Kg</td>
          <td style="text-align: right;">Rs. ${(it.unitPrice ?? 0).toLocaleString()}</td>
          <td style="text-align: right; font-weight: 700;">Rs. ${(it.subtotal ?? 0).toLocaleString()}</td>
        </tr>
      `
        )
        .join('')
    : `
        <tr>
          <td style="text-align: center;">1</td>
          <td colspan="4"><strong>${tx.notes || `${tx.type} Transaction Entry`}</strong></td>
          <td style="text-align: right;">Rs. ${totalAmount.toLocaleString()}</td>
          <td style="text-align: right; font-weight: 700;">Rs. ${totalAmount.toLocaleString()}</td>
        </tr>
      `;

  const totalQty = hasItems ? tx.items.reduce((s, it) => s + (it.quantity || 0), 0) : 1;
  const totalVol = hasItems ? tx.items.reduce((s, it) => s + (it.totalVolume || 0), 0) : 0;

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>${docTitle} - ${tx.docNumber}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background: #f1f5f9;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      color: #1e293b;
      padding: 24px 16px;
      display: flex;
      justify-content: center;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    .sheet {
      background: #ffffff;
      width: 100%;
      max-width: 820px;
      min-height: 1020px;
      box-shadow: 0 10px 25px -5px rgba(0,0,0,0.08), 0 8px 10px -6px rgba(0,0,0,0.04);
      border-radius: 10px;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      position: relative;
    }
    .header {
      background-color: ${themeColor};
      color: #ffffff;
      padding: 24px 28px;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      border-bottom: 3px solid rgba(0,0,0,0.1);
    }
    .business-name {
      font-size: 20px;
      font-weight: 800;
      letter-spacing: 0.5px;
      text-transform: uppercase;
      line-height: 1.2;
    }
    .depot-name {
      font-size: 12px;
      opacity: 0.92;
      margin-top: 5px;
    }
    .doc-meta {
      text-align: right;
    }
    .doc-title {
      font-size: 16px;
      font-weight: 800;
      letter-spacing: 0.5px;
      text-transform: uppercase;
    }
    .doc-num {
      font-size: 13px;
      font-weight: 700;
      margin-top: 4px;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      letter-spacing: 0.5px;
    }
    .doc-datetime {
      font-size: 11px;
      opacity: 0.85;
      margin-top: 3px;
    }
    .content {
      padding: 24px 28px;
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 20px;
    }
    .panels-row {
      display: grid;
      grid-template-columns: 1fr;
      gap: 16px;
    }
    .panel-box {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 14px 16px;
    }
    .panel-label {
      font-size: 10px;
      font-weight: 700;
      color: #64748b;
      letter-spacing: 0.6px;
      margin-bottom: 6px;
      text-transform: uppercase;
    }
    .panel-title {
      font-size: 15px;
      font-weight: 700;
      color: #0f172a;
      margin-bottom: 4px;
    }
    .panel-line {
      font-size: 12px;
      color: #475569;
      margin-top: 3px;
    }
    .badge {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 12px;
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
    }
    .badge-paid { background: #dcfce7; color: #15803d; }
    .badge-partial { background: #fef3c7; color: #b45309; }
    .badge-pending { background: #fee2e2; color: #b91c1c; }
    table.items-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 4px;
      border-radius: 6px;
      overflow: hidden;
      border: 1px solid #e2e8f0;
    }
    table.items-table th {
      background-color: ${themeColor};
      color: #ffffff;
      font-size: 11px;
      font-weight: 700;
      text-align: left;
      padding: 10px 12px;
      letter-spacing: 0.3px;
    }
    table.items-table td {
      padding: 10px 12px;
      font-size: 12px;
      border-bottom: 1px solid #e2e8f0;
      color: #1e293b;
    }
    table.items-table tr:nth-child(even) td {
      background: #f8fafc;
    }
    table.items-table tr.total-row td {
      background: #eff6ff;
      font-weight: 700;
      font-size: 12px;
      color: #0f172a;
      border-top: 2px solid ${themeColor};
    }
    .summary-row {
      display: grid;
      grid-template-columns: 1.1fr 0.9fr;
      gap: 16px;
      margin-top: 4px;
    }
    .terms-box {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 14px 16px;
      font-size: 11px;
      color: #475569;
    }
    .totals-box {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 14px 16px;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    .total-item {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
      color: #64748b;
    }
    .total-item strong {
      color: #0f172a;
      font-size: 13px;
    }
    .total-item.highlight {
      border-top: 1px dashed #cbd5e1;
      padding-top: 8px;
      margin-top: 2px;
    }
    .signatures {
      margin-top: auto;
      padding-top: 40px;
      display: flex;
      justify-content: space-between;
      padding-bottom: 16px;
    }
    .sig-block {
      text-align: center;
      width: 220px;
    }
    .sig-line {
      border-bottom: 1.5px solid #94a3b8;
      margin-bottom: 8px;
    }
    .sig-label {
      font-size: 11px;
      font-weight: 600;
      color: #64748b;
    }
    .footer-audit {
      border-top: 1px solid #e2e8f0;
      padding: 10px 28px;
      font-size: 11px;
      color: #94a3b8;
      display: flex;
      justify-content: space-between;
      background: #f8fafc;
    }
    @media print {
      body {
        background: #ffffff;
        padding: 0;
      }
      .sheet {
        box-shadow: none;
        border-radius: 0;
        max-width: 100%;
        min-height: auto;
      }
    }
  </style>
</head>
<body>
  <div class="sheet">
    <div class="header">
      <div>
        <div class="business-name">${businessName}</div>
        <div class="depot-name">${depotName} · Bulk Petroleum & Packaging Terminal</div>
        <div class="depot-name" style="opacity: 0.8; font-size: 11px; margin-top: 2px;">Official Terminal Accounting Document</div>
      </div>
      <div class="doc-meta">
        <div class="doc-title">${docTitle}</div>
        <div class="doc-num">Doc #: ${tx.docNumber}</div>
        <div class="doc-datetime">Date: ${tx.date} · Time: ${tx.time || ''}</div>
      </div>
    </div>

    <div class="content">
      <div class="panels-row">
        <div class="panel-box">
          <div class="panel-label">${partyLabel}</div>
          <div class="panel-title">${partyName}</div>
          ${party?.phone ? `<div class="panel-line">Phone: <strong>${party.phone}</strong></div>` : ''}
          ${party?.city ? `<div class="panel-line">City: ${party.city}</div>` : ''}
          ${party?.address ? `<div class="panel-line">Address: ${party.address}</div>` : ''}
        </div>
      </div>

      <table class="items-table">
        <thead>
          <tr>
            <th style="width: 40px; text-align: center;">#</th>
            ${
              hasItems
                ? `
              <th>Product / Item Description</th>
              <th style="text-align: center;">Packing</th>
              <th style="text-align: center;">Qty</th>
              <th style="text-align: right;">Total Vol</th>
              <th style="text-align: right;">Rate (PKR)</th>
              <th style="text-align: right;">Subtotal (PKR)</th>
            `
                : `
              <th colspan="4">Transaction Description / Particulars</th>
              <th style="text-align: right;">Rate (PKR)</th>
              <th style="text-align: right;">Subtotal (PKR)</th>
            `
            }
          </tr>
        </thead>
        <tbody>
          ${itemsHtml}
          <tr class="total-row">
            <td style="text-align: center;">Total</td>
            ${
              hasItems
                ? `
              <td>${tx.items.length} line item(s)</td>
              <td></td>
              <td style="text-align: center;">${totalQty}</td>
              <td style="text-align: right;">${totalVol > 0 ? `${totalVol} L/Kg` : '-'}</td>
              <td></td>
              <td style="text-align: right;">Rs. ${totalAmount.toLocaleString()}</td>
            `
                : `
              <td colspan="4">Voucher Entry Total</td>
              <td></td>
              <td style="text-align: right;">Rs. ${totalAmount.toLocaleString()}</td>
            `
            }
          </tr>
        </tbody>
      </table>

      <div class="summary-row">
        <div class="terms-box">
          <div class="panel-label">TERMS & DISPATCH REMARKS:</div>
          <div style="margin-top: 4px;"><strong>Memo / Ref:</strong> ${tx.notes || 'Standard petroleum account booking entry.'}</div>
          <div style="margin-top: 6px; font-size: 10.5px; line-height: 1.4;">
            ${
              isPurchase
                ? 'All goods subject to laboratory gravity test and seal inspection upon tanker unloading.'
                : 'Goods received in sound order. Official computer generated financial slip.'
            }
          </div>
          <div style="margin-top: 4px; font-size: 10px; color: #94a3b8;">All disputes subject to provincial commercial jurisdiction.</div>
        </div>

        <div class="totals-box">
          <div class="total-item">
            <span>Gross Document Total:</span>
            <strong>Rs. ${totalAmount.toLocaleString()}</strong>
          </div>
          <div class="total-item">
            <span>Cleared / Paid Amount:</span>
            <strong style="color: #15803d;">Rs. ${paidAmount.toLocaleString()}</strong>
          </div>
          <div class="total-item highlight">
            <span>Net Balance Due:</span>
            <strong style="color: ${balanceDue > 0 ? '#b91c1c' : '#15803d'};">
              ${balanceDue > 0 ? `Rs. ${balanceDue.toLocaleString()}` : 'Rs. 0 (Cleared)'}
            </strong>
          </div>
        </div>
      </div>

      <div class="signatures">
        <div class="sig-block">
          <div class="sig-line"></div>
          <div class="sig-label">${isPurchase ? 'Vendor / Driver Delivery Sign & CNIC' : 'Customer / Receiver Signature'}</div>
        </div>
        <div class="sig-block">
          <div class="sig-line"></div>
          <div class="sig-label">Authorized Signatory & Depot Stamp</div>
        </div>
      </div>
    </div>

    <div class="footer-audit">
      <span>Official Electronic Document · OilFlow Petroleum Operating System</span>
      <span>Doc ID: <strong>${tx.id}</strong></span>
    </div>
  </div>
</body>
</html>`;
}

// Sharing helpers
export function shareOnWhatsApp(text: string, phone?: string) {
  const cleanPhone = phone ? phone.replace(/[^0-9]/g, '') : '';
  const encodedText = encodeURIComponent(text);
  const url = cleanPhone
    ? `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodedText}`
    : `https://api.whatsapp.com/send?text=${encodedText}`;
  window.open(url, '_blank');
}

export async function shareNative(data: { title: string; text: string; url?: string }) {
  if (navigator.share) {
    try {
      await navigator.share(data);
      return true;
    } catch {
      return false;
    }
  }
  return false;
}

export async function copyTextToClipboard(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
    const textArea = document.createElement('textarea');
    textArea.value = text;
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand('copy');
    document.body.removeChild(textArea);
    return true;
  } catch {
    return false;
  }
}

export function generateReconciliationAuditPDF(
  report: ReconciliationReport,
  settings?: AppSettings
) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const businessName = settings?.businessName || 'OILFLOW PETROLEUM & LUBRICANTS';
  const depotName = settings?.depotName || 'Central Depot & Terminal Operations';

  // Header Banner
  doc.setFillColor(84, 48, 156);
  doc.rect(0, 0, 210, 26, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text(businessName, 14, 11);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`${depotName} · System Financial Reconciliation & Audit Report`, 14, 18);
  doc.text(`Audited: ${report.timestamp}`, 196, 18, { align: 'right' });

  // Status Banner
  const statusBg = report.hasDiscrepancies ? [254, 242, 242] : [240, 253, 244];
  const statusColor = report.hasDiscrepancies ? [185, 28, 28] : [21, 128, 61];
  doc.setFillColor(statusBg[0], statusBg[1], statusBg[2]);
  doc.rect(14, 30, 182, 14, 'F');
  doc.setTextColor(statusColor[0], statusColor[1], statusColor[2]);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  const statusText = report.hasDiscrepancies
    ? `AUDIT ALERT: ${report.totalDiscrepanciesCount} Discrepanc${report.totalDiscrepanciesCount === 1 ? 'y' : 'ies'} Detected. Auto-reconciliation available.`
    : `AUDIT VERIFIED: All Cash & Bank Accounts and Party Ledgers are 100% Balanced (Zero Discrepancy).`;
  doc.text(statusText, 18, 39);

  // Accounts Section
  doc.setTextColor(30, 41, 59);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('1. Cash & Bank Accounts Reconciliation', 14, 52);

  const accountRows = report.accounts.map((a) => [
    `${a.name} (${a.type})`,
    `Rs. ${a.openingBalance.toLocaleString()}`,
    `Rs. ${a.totalInflow.toLocaleString()}`,
    `Rs. ${a.totalOutflow.toLocaleString()}`,
    `Rs. ${a.calculatedBalance.toLocaleString()}`,
    `Rs. ${a.recordedBalance.toLocaleString()}`,
    a.status === 'balanced' ? 'Balanced' : `Diff: Rs. ${a.difference.toLocaleString()}`,
  ]);

  autoTable(doc, {
    startY: 55,
    head: [['Account Name', 'Opening', 'Total In (+)', 'Total Out (-)', 'Calculated', 'Recorded', 'Status']],
    body: accountRows,
    theme: 'striped',
    headStyles: {
      fillColor: [84, 48, 156],
      textColor: [255, 255, 255],
      fontSize: 8,
      fontStyle: 'bold',
    },
    styles: {
      fontSize: 8,
      cellPadding: 2,
    },
    columnStyles: {
      0: { cellWidth: 42 },
      1: { halign: 'right', cellWidth: 22 },
      2: { halign: 'right', cellWidth: 22 },
      3: { halign: 'right', cellWidth: 22 },
      4: { halign: 'right', cellWidth: 24 },
      5: { halign: 'right', cellWidth: 24 },
      6: { halign: 'center', cellWidth: 26 },
    },
  });

  // Parties Section
  // @ts-expect-error autoTable adds lastAutoTable to doc
  const finalY1 = doc.lastAutoTable ? doc.lastAutoTable.finalY + 8 : 130;

  doc.setTextColor(30, 41, 59);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('2. Customer & Supplier Balances Reconciliation', 14, finalY1);

  const partyRows = report.parties.slice(0, 15).map((p) => [
    `${p.name} (${p.type})`,
    `Rs. ${p.openingBalance.toLocaleString()}`,
    `Rs. ${p.totalInvoiced.toLocaleString()}`,
    `Rs. ${p.totalSettled.toLocaleString()}`,
    `Rs. ${p.calculatedBalance.toLocaleString()}`,
    `Rs. ${p.recordedBalance.toLocaleString()}`,
    p.status === 'balanced' ? 'Balanced' : `Diff: Rs. ${p.difference.toLocaleString()}`,
  ]);

  if (partyRows.length === 0) {
    partyRows.push(['No party records found', '-', '-', '-', '-', '-', 'N/A']);
  }

  autoTable(doc, {
    startY: finalY1 + 3,
    head: [['Party / Entity', 'Opening', 'Invoiced / Owed', 'Settled / Paid', 'Calculated', 'Recorded', 'Status']],
    body: partyRows,
    theme: 'striped',
    headStyles: {
      fillColor: [100, 116, 139],
      textColor: [255, 255, 255],
      fontSize: 8,
      fontStyle: 'bold',
    },
    styles: {
      fontSize: 8,
      cellPadding: 2,
    },
    columnStyles: {
      0: { cellWidth: 42 },
      1: { halign: 'right', cellWidth: 22 },
      2: { halign: 'right', cellWidth: 22 },
      3: { halign: 'right', cellWidth: 22 },
      4: { halign: 'right', cellWidth: 24 },
      5: { halign: 'right', cellWidth: 24 },
      6: { halign: 'center', cellWidth: 26 },
    },
  });

  // Footer notes
  const pageHeight = doc.internal.pageSize.getHeight();
  doc.setTextColor(140, 150, 160);
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.text(
    'Reconciliation Report generated by OilFlow Accounting Core. All cash/bank vouchers and invoices verified.',
    14,
    pageHeight - 8
  );
  doc.text(`Page 1 of 1`, 196, pageHeight - 8, { align: 'right' });

  doc.save(`OilFlow_Reconciliation_Report_${new Date().toISOString().slice(0, 10)}.pdf`);
}

export interface ProfitLossReportData {
  periodLabel: string;
  startDate: string;
  endDate: string;
  periodRangeStr: string;
  reportDateStr: string;
  currency: string;

  // Income
  salesLocal: number;
  salesExport: number;
  salesReturnsDiscounts: number;
  netSales: number;

  // Cost of Goods Sold
  openingStockDateStr: string;
  openingStockAmount: number;
  purchasesNet: number;
  purchaseReturns: number;
  freightInward: number;
  goodsAvailableForSale: number;
  closingStockDateStr: string;
  closingStockAmount: number;
  costOfGoodsSold: number;

  // Gross Profit
  grossProfit: number;
  grossMarginPct: number;

  // Operating Expenses
  operatingExpenseItems: { name: string; amount: number }[];
  totalOperatingExpenses: number;

  // Other Income
  otherIncomeItems: { name: string; amount: number }[];
  totalOtherIncome: number;

  // Final Net Profit Summary
  netProfitBeforeTax: number;
  taxRatePercent: number;
  taxExpense: number;
  netProfitAfterTax: number;
  netMarginPct: number;

  // Legacy drill-down details (optional)
  totalGrossRevenue?: number;
  totalSalesCashCollected?: number;
  totalSalesOnCredit?: number;
  totalCOGS?: number;
  totalPeriodPurchases?: number;
  operatingProfit?: number;
  netProfit?: number;
  productPerformance?: {
    productName: string;
    packagingUnit: string;
    qtySold: number;
    volumeSold: number;
    revenue: number;
    cost: number;
    grossProfit: number;
    marginPct: number;
  }[];
  expenseHeadBreakdown?: {
    name: string;
    category: string;
    amount: number;
    count: number;
  }[];
}

export function generateProfitLossPDF(data: ProfitLossReportData, settings?: AppSettings) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const businessName = settings?.businessName || 'Al Madina Traders';
  const currencyBadge = data.currency || 'PKR';

  const fmt = (num: number): string => {
    return Math.abs(num).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  // Header Box: Line chart icon in Navy
  doc.setFillColor(14, 27, 56); // #0e1b38
  doc.roundedRect(14, 11, 11, 11, 2, 2, 'F');

  // Draw miniature line chart inside navy icon
  doc.setDrawColor(255, 255, 255);
  doc.setLineWidth(0.6);
  doc.line(16.5, 18.5, 18.5, 15.5);
  doc.line(18.5, 15.5, 20.5, 17.5);
  doc.line(20.5, 17.5, 23, 13.5);

  // Title: PROFIT & LOSS STATEMENT
  doc.setTextColor(14, 27, 56);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14.5);
  doc.text('PROFIT & LOSS STATEMENT', 28, 16.5);

  // Subtitle: Business Name
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(75, 85, 99);
  doc.text(businessName, 28, 21.5);

  // Top Right Info Badges
  // 1. For the Period
  doc.setFontSize(7.5);
  doc.setTextColor(100, 116, 139);
  doc.text('For the Period', 115, 15);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.2);
  doc.setTextColor(30, 41, 59);
  doc.text(data.periodRangeStr || `${data.startDate} - ${data.endDate}`, 115, 20);

  // 2. Report Date
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(100, 116, 139);
  doc.text('Report Date', 160, 15);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.2);
  doc.setTextColor(30, 41, 59);
  doc.text(data.reportDateStr || new Date().toLocaleDateString('en-GB'), 160, 20);

  // 3. Currency
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(100, 116, 139);
  doc.text('Currency', 196, 15, { align: 'right' });
  doc.setFillColor(14, 27, 56);
  doc.roundedRect(184, 16.5, 12, 5.2, 1, 1, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.text(currencyBadge, 190, 20.2, { align: 'center' });

  // Divider line under top header
  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.3);
  doc.line(14, 24.5, 196, 24.5);

  // ==========================================
  // LEFT COLUMN: INCOME, COGS, GROSS PROFIT
  // Column Width: 88mm, Left Margin: 14mm
  // ==========================================

  // 1. INCOME TABLE
  const incomeRows: (string | number)[][] = [
    ['Sales (Local)', fmt(data.salesLocal)],
    ['Sales (Export)', fmt(data.salesExport)],
    ['Sales Returns / Discounts', data.salesReturnsDiscounts !== 0 ? `-${fmt(data.salesReturnsDiscounts)}` : '0.00'],
    ['NET SALES', fmt(data.netSales)],
  ];

  autoTable(doc, {
    startY: 27,
    margin: { left: 14, right: 108 },
    tableWidth: 88,
    head: [['INCOME', 'AMOUNT (PKR)']],
    body: incomeRows,
    theme: 'plain',
    headStyles: {
      fillColor: [14, 27, 56],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 7.5,
      cellPadding: 2,
    },
    styles: {
      fontSize: 7.5,
      cellPadding: 1.8,
      textColor: [30, 41, 59],
      lineWidth: 0.1,
      lineColor: [241, 245, 249],
    },
    columnStyles: {
      0: { cellWidth: 54 },
      1: { halign: 'right', cellWidth: 34 },
    },
    didParseCell: (hookData) => {
      if (hookData.section === 'body') {
        const raw0 = String((hookData.row.raw as any)?.[0] || '');
        if (raw0.includes('Returns / Discounts')) {
          hookData.cell.styles.textColor = [185, 28, 28]; // Red
        } else if (raw0 === 'NET SALES') {
          hookData.cell.styles.fontStyle = 'bold';
          hookData.cell.styles.fillColor = [238, 248, 242]; // Pale mint
          hookData.cell.styles.textColor = [10, 92, 54]; // Dark emerald
        }
      }
    },
  });

  // @ts-expect-error autoTable attaches lastAutoTable
  const incomeFinalY = doc.lastAutoTable ? doc.lastAutoTable.finalY : 50;

  // 2. COST OF GOODS SOLD TABLE
  const cogsRows: (string | number)[][] = [
    [`Opening Stock (${data.openingStockDateStr || data.startDate})`, fmt(data.openingStockAmount)],
    ['Purchases (Net)', fmt(data.purchasesNet)],
    ['Purchase Returns', data.purchaseReturns !== 0 ? `-${fmt(data.purchaseReturns)}` : '0.00'],
    ['Freight Inward', fmt(data.freightInward)],
    ['GOODS AVAILABLE FOR SALE', fmt(data.goodsAvailableForSale)],
    [`Closing Stock (${data.closingStockDateStr || data.endDate})`, data.closingStockAmount !== 0 ? `-${fmt(data.closingStockAmount)}` : '0.00'],
    ['COST OF GOODS SOLD', fmt(data.costOfGoodsSold)],
  ];

  autoTable(doc, {
    startY: incomeFinalY + 3.5,
    margin: { left: 14, right: 108 },
    tableWidth: 88,
    head: [['COST OF GOODS SOLD', 'AMOUNT (PKR)']],
    body: cogsRows,
    theme: 'plain',
    headStyles: {
      fillColor: [14, 27, 56],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 7.5,
      cellPadding: 2,
    },
    styles: {
      fontSize: 7.5,
      cellPadding: 1.8,
      textColor: [30, 41, 59],
      lineWidth: 0.1,
      lineColor: [241, 245, 249],
    },
    columnStyles: {
      0: { cellWidth: 54 },
      1: { halign: 'right', cellWidth: 34 },
    },
    didParseCell: (hookData) => {
      if (hookData.section === 'body') {
        const raw0 = String((hookData.row.raw as any)?.[0] || '');
        if (raw0.includes('Purchase Returns') || raw0.includes('Closing Stock')) {
          hookData.cell.styles.textColor = [185, 28, 28]; // Red
        } else if (raw0 === 'GOODS AVAILABLE FOR SALE') {
          hookData.cell.styles.fontStyle = 'bold';
          hookData.cell.styles.fillColor = [248, 250, 252];
          hookData.cell.styles.textColor = [15, 23, 42];
        } else if (raw0 === 'COST OF GOODS SOLD') {
          hookData.cell.styles.fontStyle = 'bold';
          hookData.cell.styles.textColor = [185, 28, 28]; // Red bold
        }
      }
    },
  });

  // @ts-expect-error autoTable attaches lastAutoTable
  const cogsFinalY = doc.lastAutoTable ? doc.lastAutoTable.finalY : 110;

  // 3. GROSS PROFIT HIGHLIGHT CARD
  const gpY = cogsFinalY + 3.5;
  doc.setFillColor(255, 251, 235); // amber-50
  doc.setDrawColor(254, 240, 138); // amber-200
  doc.roundedRect(14, gpY, 88, 8, 1.2, 1.2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(10, 92, 54);
  doc.text('GROSS PROFIT', 18, gpY + 5.2);

  doc.setFontSize(8.5);
  doc.text(fmt(data.grossProfit), 98, gpY + 5.2, { align: 'right' });

  const leftColumnFinalY = gpY + 8;

  // ==========================================
  // RIGHT COLUMN: OPERATING EXPENSES, OTHER INCOME
  // Column Width: 88mm, Left Margin: 108mm
  // ==========================================

  // 4. OPERATING EXPENSES TABLE
  const expenseRows: (string | number)[][] = data.operatingExpenseItems.map((item) => [
    item.name,
    fmt(item.amount),
  ]);
  expenseRows.push(['TOTAL OPERATING EXPENSES', fmt(data.totalOperatingExpenses)]);

  autoTable(doc, {
    startY: 27,
    margin: { left: 108, right: 14 },
    tableWidth: 88,
    head: [['OPERATING EXPENSES', 'AMOUNT (PKR)']],
    body: expenseRows,
    theme: 'plain',
    headStyles: {
      fillColor: [14, 27, 56],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 7.5,
      cellPadding: 2,
    },
    styles: {
      fontSize: 7.5,
      cellPadding: 1.6,
      textColor: [30, 41, 59],
      lineWidth: 0.1,
      lineColor: [241, 245, 249],
    },
    columnStyles: {
      0: { cellWidth: 54 },
      1: { halign: 'right', cellWidth: 34 },
    },
    didParseCell: (hookData) => {
      if (hookData.section === 'body') {
        const raw0 = String((hookData.row.raw as any)?.[0] || '');
        if (raw0 === 'TOTAL OPERATING EXPENSES') {
          hookData.cell.styles.fontStyle = 'bold';
          hookData.cell.styles.fillColor = [255, 245, 245];
          hookData.cell.styles.textColor = [185, 28, 28]; // Red
        }
      }
    },
  });

  // @ts-expect-error autoTable attaches lastAutoTable
  const expenseFinalY = doc.lastAutoTable ? doc.lastAutoTable.finalY : 100;

  // 5. OTHER INCOME TABLE
  const otherIncomeRows: (string | number)[][] = data.otherIncomeItems.map((item) => [
    item.name,
    fmt(item.amount),
  ]);
  otherIncomeRows.push(['TOTAL OTHER INCOME', fmt(data.totalOtherIncome)]);

  autoTable(doc, {
    startY: expenseFinalY + 3.5,
    margin: { left: 108, right: 14 },
    tableWidth: 88,
    head: [['OTHER INCOME', 'AMOUNT (PKR)']],
    body: otherIncomeRows,
    theme: 'plain',
    headStyles: {
      fillColor: [14, 27, 56],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 7.5,
      cellPadding: 2,
    },
    styles: {
      fontSize: 7.5,
      cellPadding: 1.8,
      textColor: [30, 41, 59],
      lineWidth: 0.1,
      lineColor: [241, 245, 249],
    },
    columnStyles: {
      0: { cellWidth: 54 },
      1: { halign: 'right', cellWidth: 34 },
    },
    didParseCell: (hookData) => {
      if (hookData.section === 'body') {
        const raw0 = String((hookData.row.raw as any)?.[0] || '');
        if (raw0 === 'TOTAL OTHER INCOME') {
          hookData.cell.styles.fontStyle = 'bold';
          hookData.cell.styles.fillColor = [240, 253, 244];
          hookData.cell.styles.textColor = [10, 92, 54]; // Dark emerald
        }
      }
    },
  });

  // @ts-expect-error autoTable attaches lastAutoTable
  const rightColumnFinalY = doc.lastAutoTable ? doc.lastAutoTable.finalY : 130;

  // ==========================================
  // FULL WIDTH BOTTOM SECTION
  // Width: 182mm, Margin: 14mm to 196mm
  // ==========================================
  const bottomStartY = Math.max(leftColumnFinalY, rightColumnFinalY) + 5;

  // 1. NET PROFIT BEFORE TAX
  doc.setFillColor(238, 248, 242); // Mint
  doc.setDrawColor(167, 243, 208); // Emerald border
  doc.roundedRect(14, bottomStartY, 182, 7.5, 1.2, 1.2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(10, 92, 54);
  doc.text('NET PROFIT BEFORE TAX', 18, bottomStartY + 5);
  doc.text(fmt(data.netProfitBeforeTax), 192, bottomStartY + 5, { align: 'right' });

  // 2. Tax Expense Row
  const taxY = bottomStartY + 7.5;
  doc.setFillColor(255, 255, 255);
  doc.setDrawColor(226, 232, 240);
  doc.rect(14, taxY, 182, 7, 'F');
  doc.setDrawColor(167, 243, 208);
  doc.line(14, taxY, 14, taxY + 7);
  doc.line(196, taxY, 196, taxY + 7);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(71, 85, 105);
  doc.text(`Tax Expense (${data.taxRatePercent || 15}%)`, 18, taxY + 4.8);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(185, 28, 28); // Red
  doc.text(data.taxExpense !== 0 ? `-${fmt(data.taxExpense)}` : '0.00', 192, taxY + 4.8, { align: 'right' });

  // 3. NET PROFIT AFTER TAX (Solid Deep Green Bar)
  const netAfterTaxY = taxY + 7;
  doc.setFillColor(7, 94, 58); // #075e3a
  doc.roundedRect(14, netAfterTaxY, 182, 10, 1.2, 1.2, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(255, 255, 255);
  doc.text('NET PROFIT AFTER TAX', 18, netAfterTaxY + 6.5);

  doc.setFontSize(12);
  doc.text(
    `${data.netProfitAfterTax < 0 ? '-' : ''}${fmt(data.netProfitAfterTax)}`,
    192,
    netAfterTaxY + 6.8,
    { align: 'right' }
  );

  // Footer & Accounting Attestation
  const pageHeight = doc.internal.pageSize.getHeight();
  doc.setDrawColor(226, 232, 240);
  doc.line(14, pageHeight - 16, 196, pageHeight - 16);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(100, 116, 139);
  doc.text(
    'Accounting Attestation: Prepared in compliance with standard trading accounting principles · All entries verified.',
    14,
    pageHeight - 10
  );
  doc.text('Authorized Signatory: _________________________', 135, pageHeight - 10);

  doc.save(`${businessName.replace(/\s+/g, '_')}_Profit_Loss_${data.startDate}_to_${data.endDate}.pdf`);
}



