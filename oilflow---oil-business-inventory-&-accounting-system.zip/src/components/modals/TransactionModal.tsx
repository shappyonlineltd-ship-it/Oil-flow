import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { TransactionType, TransactionItem, PaymentStatus, Transaction } from '../../types';

export const TransactionModal: React.FC = () => {
  const {
    transactionModalOpen,
    transactionModalInitialType,
    transactionModalInitialProduct,
    transactionModalInitialPartyId,
    closeTransactionModal,
    products,
    parties,
    accounts,
    createTransaction,
    editingTransaction,
    updateTransaction,
    closeEditTransactionModal,
    openPdfPreview,
    downloadTransactionPdf,
  } = useApp();

  const isEditing = !!editingTransaction;
  const isOpen = transactionModalOpen || isEditing;

  const [type, setType] = useState<TransactionType>('Sale');
  const [date, setDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [time, setTime] = useState<string>(
    new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
  );
  const [partyId, setPartyId] = useState<string>('');
  const [accountId, setAccountId] = useState<string>('');
  const [toAccountId, setToAccountId] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  // Items for Purchase and Sale
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [unitRate, setUnitRate] = useState<number>(0);
  const [itemsList, setItemsList] = useState<TransactionItem[]>([]);

  // Direct amounts for Receive / Pay / Transfer
  const [directAmount, setDirectAmount] = useState<number>(0);
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [paymentMode, setPaymentMode] = useState<'Paid' | 'Credit' | 'Partial'>('Paid');

  // Initialize form state
  useEffect(() => {
    // Choose sensible default account: first marked default, else first Cash, else first account
    const defaultAcc = accounts.find((a) => a.isDefault) || accounts.find((a) => a.type === 'Cash') || accounts[0];
    const defaultAccId = defaultAcc?.id || '';

    if (editingTransaction) {
      setType(editingTransaction.type);
      setDate(editingTransaction.date);
      setTime(editingTransaction.time);
      setPartyId(editingTransaction.partyId || '');
      setAccountId(editingTransaction.accountId || defaultAccId);
      setToAccountId(editingTransaction.toAccountId || '');
      setNotes(editingTransaction.notes || '');
      setItemsList(editingTransaction.items || []);
      setDirectAmount(editingTransaction.totalAmount);
      setPaidAmount(editingTransaction.paidAmount);
      if (editingTransaction.paidAmount === 0 && editingTransaction.balanceDue > 0) {
        setPaymentMode('Credit');
      } else if (editingTransaction.balanceDue > 0) {
        setPaymentMode('Partial');
      } else {
        setPaymentMode('Paid');
      }
    } else if (transactionModalOpen) {
      const initialType = transactionModalInitialType || 'Sale';
      setType(initialType);
      setDate(new Date().toISOString().slice(0, 10));
      setTime(new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }));
      setPartyId(transactionModalInitialPartyId || '');
      setAccountId(defaultAccId);
      const toAcc = accounts.find((a) => a.id !== defaultAccId) || accounts[1] || accounts[0];
      setToAccountId(toAcc?.id || '');
      setNotes('');
      setItemsList([]);
      setDirectAmount(0);
      setPaidAmount(0);
      setPaymentMode('Paid');

      // Preselect product if passed
      if (transactionModalInitialProduct) {
        const prod = products.find(
          (p) =>
            p.name.toLowerCase().includes(transactionModalInitialProduct.toLowerCase()) ||
            p.grade.toLowerCase().includes(transactionModalInitialProduct.toLowerCase())
        );
        if (prod) {
          setSelectedProductId(prod.id);
          setQuantity(initialType === 'Purchase' ? 5 : 1);
          const rate = initialType === 'Purchase' ? prod.purchaseCost : prod.salePrice;
          setUnitRate(rate);
        }
      } else if (products.length > 0) {
        setSelectedProductId(products[0].id);
        const rate = initialType === 'Purchase' ? products[0].purchaseCost : products[0].salePrice;
        setUnitRate(rate);
        setQuantity(1);
      }
    }
  }, [
    transactionModalOpen,
    editingTransaction,
    transactionModalInitialType,
    transactionModalInitialProduct,
    transactionModalInitialPartyId,
    products,
    accounts,
  ]);

  // Update unit rate when product changes
  const handleProductSelect = (id: string) => {
    setSelectedProductId(id);
    const prod = products.find((p) => p.id === id);
    if (prod) {
      const rate = type === 'Purchase' ? prod.purchaseCost : prod.salePrice;
      setUnitRate(rate);
    }
  };

  // Add Item to cart
  const handleAddItem = () => {
    const prod = products.find((p) => p.id === selectedProductId);
    if (!prod || quantity <= 0) return;

    const subtotal = quantity * unitRate;
    const newItem: TransactionItem = {
      id: 'item-' + Date.now(),
      productId: prod.id,
      productName: `${prod.name} (${prod.grade})`,
      packagingUnit: prod.unit,
      quantity,
      packingSize: prod.packingSize,
      totalVolume: quantity * prod.packingSize,
      unitPrice: unitRate,
      subtotal,
    };

    const updated = [...itemsList, newItem];
    setItemsList(updated);
    
    // Auto-update total and paid
    const newTotal = updated.reduce((s, it) => s + it.subtotal, 0);
    setDirectAmount(newTotal);
    if (paymentMode === 'Credit') {
      setPaidAmount(0);
    } else if (paymentMode === 'Paid') {
      setPaidAmount(newTotal);
    }

    // Reset current item inputs for next
    setQuantity(1);
  };

  const handleRemoveItem = (index: number) => {
    const updated = itemsList.filter((_, idx) => idx !== index);
    setItemsList(updated);
    const newTotal = updated.reduce((s, it) => s + it.subtotal, 0);
    setDirectAmount(newTotal);
    if (paymentMode === 'Credit') {
      setPaidAmount(0);
    } else if (paymentMode === 'Paid') {
      setPaidAmount(newTotal);
    } else {
      setPaidAmount(Math.min(paidAmount, newTotal));
    }
  };

  // Calculate totals
  const totalAmount =
    type === 'Sale' || type === 'Purchase'
      ? itemsList.length > 0
        ? itemsList.reduce((sum, it) => sum + it.subtotal, 0)
        : quantity * unitRate
      : directAmount;

  const effectivePaidAmount =
    type === 'Transfer' || type === 'Receive' || type === 'Pay'
      ? totalAmount
      : paymentMode === 'Credit'
      ? 0
      : paymentMode === 'Paid'
      ? totalAmount
      : paidAmount;

  const balanceDue = Math.max(0, totalAmount - effectivePaidAmount);

  const paymentStatus: PaymentStatus =
    effectivePaidAmount >= totalAmount
      ? 'Paid'
      : effectivePaidAmount > 0
      ? 'Partial'
      : 'Pending';

  // Filter parties by type
  const filteredParties = parties.filter((p) => {
    if (type === 'Sale' || type === 'Receive') return p.type === 'Customer' || p.type === 'Both';
    if (type === 'Purchase' || type === 'Pay') return p.type === 'Supplier' || p.type === 'Both';
    return true;
  });

  const buildPayload = () => {
    let finalItems = itemsList;
    if ((type === 'Sale' || type === 'Purchase') && itemsList.length === 0 && selectedProductId) {
      const prod = products.find((p) => p.id === selectedProductId);
      if (prod) {
        finalItems = [
          {
            id: 'item-' + Date.now(),
            productId: prod.id,
            productName: `${prod.name} (${prod.grade})`,
            packagingUnit: prod.unit,
            quantity,
            packingSize: prod.packingSize,
            totalVolume: quantity * prod.packingSize,
            unitPrice: unitRate,
            subtotal: quantity * unitRate,
          },
        ];
      }
    }

    const isCredit = (type === 'Sale' || type === 'Purchase') && (paymentMode === 'Credit' || effectivePaidAmount === 0);
    const selectedParty = parties.find((p) => p.id === partyId);
    // Strictly do NOT assign account if it's on credit or no payment occurred!
    const selectedAccount = !isCredit && effectivePaidAmount > 0 ? accounts.find((a) => a.id === accountId) : undefined;
    const selectedToAccount = accounts.find((a) => a.id === toAccountId);

    return {
      type,
      date,
      time,
      partyId: selectedParty?.id,
      partyName: selectedParty?.name,
      accountId: selectedAccount?.id,
      accountName: selectedAccount?.name,
      toAccountId: selectedToAccount?.id,
      toAccountName: selectedToAccount?.name,
      items: finalItems,
      totalAmount,
      paidAmount: isCredit ? 0 : effectivePaidAmount,
      balanceDue: isCredit ? totalAmount : balanceDue,
      paymentStatus: isCredit ? 'Pending' : paymentStatus,
      notes,
    };
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (totalAmount <= 0) {
      alert('Please enter a valid transaction amount or add at least one product.');
      return;
    }

    if (type === 'Transfer' && accountId === toAccountId) {
      alert('Source and destination accounts must be different.');
      return;
    }

    const payload = buildPayload();

    if (isEditing && editingTransaction) {
      updateTransaction(editingTransaction.id, payload);
      closeEditTransactionModal();
    } else {
      createTransaction(payload);
      closeTransactionModal();
    }
  };

  const handleSaveAndDownload = (e: React.MouseEvent) => {
    e.preventDefault();

    if (totalAmount <= 0) {
      alert('Please enter a valid transaction amount or add at least one product.');
      return;
    }

    if (type === 'Transfer' && accountId === toAccountId) {
      alert('Source and destination accounts must be different.');
      return;
    }

    const payload = buildPayload();
    let savedTx: Transaction;

    if (isEditing && editingTransaction) {
      updateTransaction(editingTransaction.id, payload);
      savedTx = { ...editingTransaction, ...payload };
      closeEditTransactionModal();
    } else {
      savedTx = createTransaction(payload);
      closeTransactionModal();
    }

    // Immediately generate and download the Sales Invoice or Purchase Order PDF
    downloadTransactionPdf(savedTx);
  };

  const handlePreviewPDF = (e: React.MouseEvent) => {
    e.preventDefault();

    if (totalAmount <= 0) {
      alert('Please add at least one item or enter a valid amount to preview the PDF.');
      return;
    }

    const payload = buildPayload();
    const tempDocNumber =
      editingTransaction?.docNumber ||
      (type === 'Sale' ? 'INV-PREVIEW' : type === 'Purchase' ? 'PO-PREVIEW' : 'VOUCHER-PREVIEW');

    const previewTx: Transaction = {
      ...payload,
      id: editingTransaction?.id || 'tx-preview',
      docNumber: tempDocNumber,
      createdAt: new Date().toISOString(),
    };

    openPdfPreview(previewTx);
  };

  const handleClose = () => {
    if (isEditing) {
      closeEditTransactionModal();
    } else {
      closeTransactionModal();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-inverse-surface/40 backdrop-blur-sm z-50 flex items-center justify-center p-space-sm sm:p-space-md animate-in fade-in duration-150">
      <div className="bg-surface-container-lowest w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border border-surface-container-high/60">
        {/* Header */}
        <div className="px-space-md sm:px-space-lg py-space-sm sm:py-space-md bg-surface-container-low flex items-center justify-between border-b border-surface-container-high/60">
          <div className="flex items-center gap-space-sm">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center shadow-xs ${
                type === 'Sale'
                  ? 'bg-primary-container text-on-primary'
                  : type === 'Purchase'
                  ? 'bg-secondary-container text-primary'
                  : type === 'Receive'
                  ? 'bg-tertiary-fixed text-on-tertiary-fixed'
                  : type === 'Pay'
                  ? 'bg-error-container text-on-error-container'
                  : 'bg-surface-container text-primary'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]">
                {type === 'Sale'
                  ? 'point_of_sale'
                  : type === 'Purchase'
                  ? 'shopping_cart'
                  : type === 'Receive'
                  ? 'input'
                  : type === 'Pay'
                  ? 'output'
                  : 'sync_alt'}
              </span>
            </div>
            <div>
              <h3 className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                {isEditing ? 'Edit Transaction' : `New ${type}`}
              </h3>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Instant ledger balancing and stock reconciliation
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="w-8 h-8 rounded-full hover:bg-surface-container-high text-on-surface-variant hover:text-on-surface flex items-center justify-center transition-colors"
            type="button"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Body Form */}
        <form onSubmit={handleSubmit} className="p-space-md sm:p-space-lg flex-1 overflow-y-auto space-y-space-md">
          {/* Top Row: Type & Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-space-md">
            <div className="flex flex-col gap-1">
              <label className="font-label-sm text-label-sm text-on-surface font-semibold">
                Transaction Type
              </label>
              <select
                value={type}
                onChange={(e) => {
                  const newType = e.target.value as TransactionType;
                  setType(newType);
                  if (selectedProductId) {
                    const prod = products.find((p) => p.id === selectedProductId);
                    if (prod) {
                      setUnitRate(newType === 'Purchase' ? prod.purchaseCost : prod.salePrice);
                    }
                  }
                }}
                className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm font-medium text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
              >
                <option value="Sale">Sale (Outflow / Invoice)</option>
                <option value="Purchase">Purchase (Stock In / Bill)</option>
                <option value="Receive">Receive Money (Customer Recovery)</option>
                <option value="Pay">Pay Money (Supplier Payout)</option>
                <option value="Transfer">Transfer Funds (Vault &lt;-&gt; Bank)</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="flex flex-col gap-1">
                <label className="font-label-sm text-label-sm text-on-surface font-semibold">Date</label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>
              <div className="flex flex-col gap-1">
                <label className="font-label-sm text-label-sm text-on-surface font-semibold">Time</label>
                <input
                  type="text"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>
            </div>
          </div>

          {/* Transfer Specific View */}
          {type === 'Transfer' ? (
            <div className="p-space-md bg-surface-container-low rounded-xl space-y-space-md border border-surface-container-high/40">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-space-md">
                <div className="flex flex-col gap-1">
                  <label className="font-label-sm text-label-sm text-on-surface font-semibold">
                    From Account (Source)
                  </label>
                  <select
                    value={accountId}
                    onChange={(e) => setAccountId(e.target.value)}
                    className="h-10 px-3 bg-surface-container-lowest rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                  >
                    {accounts.map((acc) => (
                      <option key={acc.id} value={acc.id}>
                        {acc.name} (Rs. {acc.balance.toLocaleString()})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex flex-col gap-1">
                  <label className="font-label-sm text-label-sm text-on-surface font-semibold">
                    To Account (Destination)
                  </label>
                  <select
                    value={toAccountId}
                    onChange={(e) => setToAccountId(e.target.value)}
                    className="h-10 px-3 bg-surface-container-lowest rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                  >
                    {accounts.map((acc) => (
                      <option key={acc.id} value={acc.id}>
                        {acc.name} (Rs. {acc.balance.toLocaleString()})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-label-sm text-label-sm text-on-surface font-semibold">
                  Transfer Amount (PKR)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-body-sm text-on-surface-variant font-medium">
                    Rs.
                  </span>
                  <input
                    type="number"
                    min="1"
                    value={directAmount === 0 ? '' : directAmount}
                    onChange={(e) => setDirectAmount(e.target.value === '' ? 0 : Number(e.target.value))}
                    placeholder="0.00"
                    className="w-full h-10 pl-9 pr-3 bg-surface-container-lowest rounded-lg text-body-sm font-semibold text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                </div>
              </div>
            </div>
          ) : (
            /* Standard Party Selection */
            <div className="flex flex-col gap-1">
              <div className="flex items-center justify-between">
                <label className="font-label-sm text-label-sm text-on-surface font-semibold">
                  {type === 'Sale' || type === 'Receive' ? 'Customer' : 'Supplier / Vendor'}{' '}
                  <span className="text-error">*</span>
                </label>
                {partyId && (
                  <span className="text-[12px] font-medium text-on-surface-variant">
                    Current Balance:{' '}
                    <span
                      className={
                        (parties.find((p) => p.id === partyId)?.currentBalance || 0) >= 0
                          ? 'text-tertiary font-bold'
                          : 'text-error font-bold'
                      }
                    >
                      Rs.{' '}
                      {Math.abs(
                        parties.find((p) => p.id === partyId)?.currentBalance || 0
                      ).toLocaleString()}
                      {(parties.find((p) => p.id === partyId)?.currentBalance || 0) >= 0
                        ? ' (Receivable)'
                        : ' (Payable)'}
                    </span>
                  </span>
                )}
              </div>
              <select
                value={partyId}
                onChange={(e) => setPartyId(e.target.value)}
                required
                className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
              >
                <option value="">
                  {filteredParties.length === 0
                    ? `-- No ${type === 'Sale' || type === 'Receive' ? 'customers' : 'suppliers'} registered yet --`
                    : '-- Select Party --'}
                </option>
                {filteredParties.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.city}) — Bal: Rs. {p.currentBalance.toLocaleString()}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Products & Inventory Section for Sale and Purchase */}
          {(type === 'Sale' || type === 'Purchase') && (
            <div className="bg-surface-container-low p-space-md rounded-xl space-y-space-sm border border-surface-container-high/40">
              <div className="flex items-center justify-between">
                <span className="font-label-sm text-label-sm text-primary uppercase font-bold tracking-wider">
                  Oil Products &amp; Packaging
                </span>
                <span className="text-[11px] text-on-surface-variant">
                  {type === 'Purchase' ? 'Manual purchase rate' : 'Customer selling rate'}
                </span>
              </div>

              {/* Items Table if added */}
              {itemsList.length > 0 && (
                <div className="overflow-x-auto rounded-lg border border-surface-container-high bg-surface-container-lowest">
                  <table className="w-full text-left text-body-sm">
                    <thead>
                      <tr className="bg-surface-container-low text-[11px] uppercase tracking-wider text-on-surface-variant">
                        <th className="py-2 px-3">Product</th>
                        <th className="py-2 px-3 text-center">Qty</th>
                        <th className="py-2 px-3 text-right">Volume</th>
                        <th className="py-2 px-3 text-right">Rate</th>
                        <th className="py-2 px-3 text-right">Subtotal</th>
                        <th className="py-2 px-2 text-center"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-surface-container-low">
                      {itemsList.map((it, idx) => (
                        <tr key={it.id || idx}>
                          <td className="py-2 px-3 font-medium text-on-surface">{it.productName}</td>
                          <td className="py-2 px-3 text-center">
                            {it.quantity} {it.packagingUnit}s
                          </td>
                          <td className="py-2 px-3 text-right text-on-surface-variant">
                            {it.totalVolume} L/Kg
                          </td>
                          <td className="py-2 px-3 text-right">Rs. {it.unitPrice.toLocaleString()}</td>
                          <td className="py-2 px-3 text-right font-bold text-on-surface">
                            Rs. {it.subtotal.toLocaleString()}
                          </td>
                          <td className="py-2 px-2 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveItem(idx)}
                              className="text-error hover:bg-error-container p-1 rounded"
                              title="Remove item"
                            >
                              <span className="material-symbols-outlined text-[16px]">delete</span>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Add item input row */}
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-1 items-end">
                <div className="sm:col-span-5 flex flex-col gap-1">
                  <label className="text-[11px] font-semibold text-on-surface-variant">
                    Select Product / Drum Spec
                  </label>
                  <select
                    value={selectedProductId}
                    onChange={(e) => handleProductSelect(e.target.value)}
                    className="h-9 px-2 bg-surface-container-lowest rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-1 focus:ring-primary"
                  >
                    {products.length === 0 ? (
                      <option value="">-- No products in catalog yet (Add product first) --</option>
                    ) : (
                      products.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} ({p.unit} - {p.packingSize} {p.packingUnit}) · Stock: {p.currentStock}
                        </option>
                      ))
                    )}
                  </select>
                </div>

                <div className="sm:col-span-2 flex flex-col gap-1">
                  <label className="text-[11px] font-semibold text-on-surface-variant">Qty</label>
                  <input
                    type="number"
                    min="1"
                    value={quantity === 0 ? '' : quantity}
                    placeholder="1"
                    onChange={(e) => setQuantity(e.target.value === '' ? 0 : Number(e.target.value))}
                    className="h-9 px-2 bg-surface-container-lowest rounded-lg text-body-sm text-on-surface text-center focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                </div>

                <div className="sm:col-span-3 flex flex-col gap-1">
                  <label className="text-[11px] font-semibold text-on-surface-variant">
                    {type === 'Purchase' ? 'Cost / Unit' : 'Price / Unit'}
                  </label>
                  <div className="relative">
                    <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[11px] text-on-surface-variant">
                      Rs.
                    </span>
                    <input
                      type="number"
                      min="0"
                      value={unitRate === 0 ? '' : unitRate}
                      placeholder="0.00"
                      onChange={(e) => setUnitRate(e.target.value === '' ? 0 : Number(e.target.value))}
                      className="w-full h-9 pl-7 pr-2 bg-surface-container-lowest rounded-lg text-body-sm text-on-surface font-semibold focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>
                </div>

                <div className="sm:col-span-2">
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="w-full h-9 px-2 rounded-lg bg-surface-container-high hover:bg-surface-container text-on-surface text-[12px] font-semibold flex items-center justify-center gap-1 transition-colors"
                  >
                    <span className="material-symbols-outlined text-[16px]">add</span> Add Item
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Direct Amount Entry for Receive & Pay */}
          {(type === 'Receive' || type === 'Pay') && (
            <div className="flex flex-col gap-1">
              <label className="font-label-sm text-label-sm text-on-surface font-semibold">
                {type === 'Receive' ? 'Receipt Amount Received (PKR)' : 'Payment Amount Paid (PKR)'}
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-body-sm text-on-surface-variant font-medium">
                  Rs.
                </span>
                <input
                  type="number"
                  min="1"
                  value={directAmount === 0 ? '' : directAmount}
                  onChange={(e) => {
                    const amt = e.target.value === '' ? 0 : Number(e.target.value);
                    setDirectAmount(amt);
                    setPaidAmount(amt);
                  }}
                  placeholder="0.00"
                  required
                  className="w-full h-10 pl-9 pr-3 bg-surface-container-low rounded-lg text-body-sm font-semibold text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>
            </div>
          )}

          {/* Payment & Settlement Channel */}
          {type !== 'Transfer' && (
            <div className="space-y-space-sm pt-space-xs border-t border-surface-container-high/40">
              {/* For Sale and Purchase: 3-way Payment Mode Buttons */}
              {(type === 'Sale' || type === 'Purchase') && (
                <div className="space-y-1.5">
                  <label className="font-label-sm text-label-sm text-on-surface font-semibold flex items-center justify-between">
                    <span>Payment Terms (Cash/Bank vs Credit/Udhaar)</span>
                    <span className="text-[11px] font-normal text-on-surface-variant">
                      {paymentMode === 'Credit'
                        ? '100% Credit on Account'
                        : paymentMode === 'Paid'
                        ? 'Full Payment Cleared'
                        : 'Partial Payment + Balance on Account'}
                    </span>
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setPaymentMode('Credit');
                        setPaidAmount(0);
                      }}
                      className={`py-2 px-2 rounded-xl text-center border font-semibold text-[12px] flex items-center justify-center gap-1.5 transition-all ${
                        paymentMode === 'Credit'
                          ? 'bg-error-container text-on-error-container border-error shadow-xs'
                          : 'bg-surface-container-low text-on-surface border-surface-container-high/60 hover:bg-surface-container'
                      }`}
                    >
                      <span className="material-symbols-outlined text-[17px]">credit_card_off</span>
                      <span>Credit (Udhaar)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setPaymentMode('Paid');
                        setPaidAmount(totalAmount);
                      }}
                      className={`py-2 px-2 rounded-xl text-center border font-semibold text-[12px] flex items-center justify-center gap-1.5 transition-all ${
                        paymentMode === 'Paid'
                          ? 'bg-tertiary-fixed text-on-tertiary-fixed border-tertiary shadow-xs'
                          : 'bg-surface-container-low text-on-surface border-surface-container-high/60 hover:bg-surface-container'
                      }`}
                    >
                      <span className="material-symbols-outlined text-[17px]">payments</span>
                      <span>Full Payment</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setPaymentMode('Partial');
                        if (paidAmount === 0 || paidAmount >= totalAmount) {
                          setPaidAmount(Math.round(totalAmount / 2));
                        }
                      }}
                      className={`py-2 px-2 rounded-xl text-center border font-semibold text-[12px] flex items-center justify-center gap-1.5 transition-all ${
                        paymentMode === 'Partial'
                          ? 'bg-secondary-container text-on-secondary-fixed border-secondary shadow-xs'
                          : 'bg-surface-container-low text-on-surface border-surface-container-high/60 hover:bg-surface-container'
                      }`}
                    >
                      <span className="material-symbols-outlined text-[17px]">pie_chart</span>
                      <span>Partial Payment</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Financial Summary Strip */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-space-md">
                {/* Total Amount */}
                <div className="flex flex-col gap-1">
                  <label className="font-label-sm text-label-sm text-on-surface-variant">
                    Total Document Amount
                  </label>
                  <div className="h-10 px-3 bg-surface-container-low rounded-lg flex items-center justify-between font-metric-md text-metric-md text-on-surface font-bold">
                    <span>Rs. {totalAmount.toLocaleString()}</span>
                    <span className="text-[12px] font-semibold text-primary">
                      {paymentMode === 'Credit' && (type === 'Sale' || type === 'Purchase')
                        ? '100% Pending'
                        : paymentStatus}
                    </span>
                  </div>
                </div>

                {/* Paid Amount */}
                {(type === 'Receive' || type === 'Pay' || paymentMode !== 'Credit') ? (
                  <div className="flex flex-col gap-1">
                    <label className="font-label-sm text-label-sm text-on-surface font-semibold">
                      {type === 'Receive'
                        ? 'Amount Received (PKR)'
                        : type === 'Pay'
                        ? 'Amount Paid (PKR)'
                        : 'Amount Settled Now (Cash / Bank)'}
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-body-sm text-on-surface-variant font-medium">
                        Rs.
                      </span>
                      <input
                        type="number"
                        min="0"
                        value={effectivePaidAmount === 0 ? '' : effectivePaidAmount}
                        placeholder="0.00"
                        disabled={paymentMode === 'Paid' && (type === 'Sale' || type === 'Purchase')}
                        onChange={(e) => setPaidAmount(e.target.value === '' ? 0 : Number(e.target.value))}
                        className="w-full h-10 pl-9 pr-3 bg-surface-container-low rounded-lg text-body-sm font-bold text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20 disabled:opacity-80"
                      />
                    </div>
                    {balanceDue > 0 && (
                      <span className="text-[11px] text-error font-medium">
                        Remaining credit due: Rs. {balanceDue.toLocaleString()} (Will be added to party balance)
                      </span>
                    )}
                  </div>
                ) : (
                  /* Credit Info Banner */
                  <div className="flex flex-col justify-center p-3 rounded-lg bg-surface-container-low border border-surface-container-high/60 text-[12px] text-on-surface-variant">
                    <span className="font-bold text-on-surface flex items-center gap-1">
                      <span className="material-symbols-outlined text-[16px] text-primary">info</span>
                      No Cash or Bank account affected
                    </span>
                    <p className="mt-0.5">
                      Full Rs. {totalAmount.toLocaleString()} will be recorded in {parties.find((p) => p.id === partyId)?.name || 'Party'}&apos;s Ledger Account.
                    </p>
                  </div>
                )}
              </div>

              {/* Settlement Channel Selection (ONLY shown when actual money moves, i.e., not pure credit!) */}
              {(type === 'Receive' || type === 'Pay' || paymentMode !== 'Credit') && effectivePaidAmount > 0 && (
                <div className="space-y-2 pt-1">
                  <label className="font-label-sm text-label-sm text-on-surface font-semibold block">
                    Select Cash / Bank Account for Payment <span className="text-error">*</span>
                  </label>

                  {/* Group 1: Cash accounts */}
                  <div>
                    <span className="text-[11px] font-bold text-on-surface-variant uppercase tracking-wider block mb-1">
                      Cash Safe Vault
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {accounts.filter((a) => a.type === 'Cash').map((acc) => (
                        <label
                          key={acc.id}
                          className={`cursor-pointer p-2.5 rounded-xl flex items-center justify-between border transition-all ${
                            accountId === acc.id
                              ? 'bg-primary-container text-on-primary border-primary font-semibold shadow-xs'
                              : 'bg-surface-container-low text-on-surface border-surface-container-high/60 hover:bg-surface-container'
                          }`}
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <input
                              type="radio"
                              name="settlementAcc"
                              checked={accountId === acc.id}
                              onChange={() => setAccountId(acc.id)}
                              className="sr-only"
                            />
                            <span className="material-symbols-outlined text-[18px]">payments</span>
                            <div className="truncate">
                              <p className="text-[12px] font-semibold truncate">{acc.name}</p>
                              <p className="text-[10px] opacity-80">{acc.branch || 'Cash Vault'}</p>
                            </div>
                          </div>
                          <span className="text-[12px] font-bold shrink-0">Rs. {acc.balance.toLocaleString()}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Group 2: Bank accounts */}
                  {accounts.filter((a) => a.type === 'Bank').length > 0 && (
                    <div>
                      <span className="text-[11px] font-bold text-on-surface-variant uppercase tracking-wider block mb-1">
                        Bank Accounts
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {accounts.filter((a) => a.type === 'Bank').map((acc) => (
                          <label
                            key={acc.id}
                            className={`cursor-pointer p-2.5 rounded-xl flex items-center justify-between border transition-all ${
                              accountId === acc.id
                                ? 'bg-primary-container text-on-primary border-primary font-semibold shadow-xs'
                                : 'bg-surface-container-low text-on-surface border-surface-container-high/60 hover:bg-surface-container'
                            }`}
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <input
                                type="radio"
                                name="settlementAcc"
                                checked={accountId === acc.id}
                                onChange={() => setAccountId(acc.id)}
                                className="sr-only"
                              />
                              <span className="material-symbols-outlined text-[18px]">account_balance</span>
                              <div className="truncate">
                                <p className="text-[12px] font-semibold truncate">{acc.name}</p>
                                <p className="text-[10px] opacity-80">{acc.bankName || 'Bank'}</p>
                              </div>
                            </div>
                            <span className="text-[12px] font-bold shrink-0">Rs. {acc.balance.toLocaleString()}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Notes */}
          <div className="flex flex-col gap-1">
            <label className="font-label-sm text-label-sm text-on-surface-variant">
              Remarks / Bilty # / Memo
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Tanker slip #4409, dispatch via Khan Logistics, cash voucher"
              className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface placeholder:text-on-surface-variant focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>

          {/* Footer Actions */}
          <div className="pt-space-sm flex flex-wrap items-center justify-between gap-space-sm border-t border-surface-container-high/40">
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={handlePreviewPDF}
                className="px-3 h-10 text-body-sm font-semibold rounded-lg bg-surface-container-low hover:bg-surface-container text-on-surface flex items-center gap-1.5 transition-colors border border-surface-container-high/60"
                title="Preview PDF document without saving"
              >
                <span className="material-symbols-outlined text-[18px] text-primary">visibility</span>
                <span>Preview PDF</span>
              </button>
            </div>

            <div className="flex items-center gap-2 ml-auto">
              <button
                type="button"
                onClick={handleClose}
                className="px-space-md h-10 text-body-sm font-label-md rounded-lg bg-surface-container text-on-surface hover:bg-surface-container-high transition-colors"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleSaveAndDownload}
                className="px-3.5 h-10 text-body-sm font-semibold rounded-lg bg-primary-container text-on-primary hover:bg-primary transition-colors shadow-sm flex items-center gap-1.5 active:scale-98"
                title="Save transaction and immediately download PDF document"
              >
                <span className="material-symbols-outlined text-[18px]">picture_as_pdf</span>
                <span>
                  {type === 'Sale'
                    ? 'Save & Download Invoice'
                    : type === 'Purchase'
                    ? 'Save & Download PO'
                    : 'Save & Download PDF'}
                </span>
              </button>

              <button
                type="submit"
                className="px-4 h-10 text-body-sm font-semibold rounded-lg bg-primary text-on-primary hover:bg-primary-container transition-colors shadow-sm active:scale-98"
              >
                {isEditing ? 'Save Changes' : 'Save Only'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
