import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../context/AppContext';

export const JournalEntryModal: React.FC = () => {
  const {
    journalModalOpen,
    journalModalInitialType,
    journalModalInitialExpenseHeadId,
    closeJournalModal,
    accounts,
    parties,
    expenseHeads,
    addExpenseHead,
    getExpenseHeadSpending,
    createTransaction,
    formatCurrency,
  } = useApp();

  const [entryType, setEntryType] = useState<'In' | 'Out'>('In');
  const [targetType, setTargetType] = useState<'Expense' | 'Party'>('Party');
  const [date, setDate] = useState<string>(() => new Date().toISOString().slice(0, 10));
  const [time, setTime] = useState<string>(() =>
    new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
  );
  const [accountId, setAccountId] = useState<string>('');
  const [partyId, setPartyId] = useState<string>('');
  const [expenseHeadId, setExpenseHeadId] = useState<string>('');
  const [partySearch, setPartySearch] = useState<string>('');
  const [amount, setAmount] = useState<string>('');
  const [remarks, setRemarks] = useState<string>('');

  // Quick inline add Expense Head modal state
  const [showQuickAddHead, setShowQuickAddHead] = useState(false);
  const [newHeadName, setNewHeadName] = useState('');
  const [newHeadCategory, setNewHeadCategory] = useState('General');
  const [newHeadDesc, setNewHeadDesc] = useState('');

  // Reset form when modal opens
  useEffect(() => {
    if (journalModalOpen) {
      const initialType = journalModalInitialType || 'In';
      setEntryType(initialType);

      // When opening as 'Out', default target to 'Expense' (user request)
      if (initialType === 'Out') {
        setTargetType('Expense');
      } else {
        setTargetType('Party');
      }

      setDate(new Date().toISOString().slice(0, 10));
      setTime(new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }));

      // Set default account (first account or default)
      const defaultAcc = accounts.find((a) => a.isDefault) || accounts[0];
      setAccountId(defaultAcc ? defaultAcc.id : '');

      // Select initial expense head if provided or first head
      if (journalModalInitialExpenseHeadId) {
        setExpenseHeadId(journalModalInitialExpenseHeadId);
      } else if (expenseHeads.length > 0) {
        setExpenseHeadId(expenseHeads[0].id);
      } else {
        setExpenseHeadId('');
      }

      // Select first party if available
      setPartyId(parties.length > 0 ? parties[0].id : '');
      setPartySearch('');
      setAmount('');
      setRemarks('');
      setShowQuickAddHead(false);
    }
  }, [journalModalOpen, journalModalInitialType, journalModalInitialExpenseHeadId, accounts, parties, expenseHeads]);

  // When entryType changes
  const handleTypeChange = (newType: 'In' | 'Out') => {
    setEntryType(newType);
    if (newType === 'Out') {
      // Default to Expense Head when Out is selected
      setTargetType('Expense');
      if (!expenseHeadId && expenseHeads.length > 0) {
        setExpenseHeadId(expenseHeads[0].id);
      }
    } else {
      // Money In comes from Party recovery
      setTargetType('Party');
    }
  };

  // Selected account, party, and expense head details
  const selectedAccount = useMemo(() => {
    return accounts.find((a) => a.id === accountId);
  }, [accounts, accountId]);

  const selectedParty = useMemo(() => {
    return parties.find((p) => p.id === partyId);
  }, [parties, partyId]);

  const selectedExpenseHead = useMemo(() => {
    return expenseHeads.find((h) => h.id === expenseHeadId);
  }, [expenseHeads, expenseHeadId]);

  // Group expense heads by category
  const expenseHeadsByCategory = useMemo(() => {
    const groups: Record<string, typeof expenseHeads> = {};
    expenseHeads.forEach((h) => {
      const cat = h.category || 'General';
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(h);
    });
    return groups;
  }, [expenseHeads]);

  // Filter parties if user types in search
  const filteredParties = useMemo(() => {
    if (!partySearch.trim()) return parties;
    const q = partySearch.toLowerCase();
    return parties.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.type.toLowerCase().includes(q) ||
        p.city.toLowerCase().includes(q) ||
        p.phone.includes(q)
    );
  }, [parties, partySearch]);

  const customersList = useMemo(() => {
    return filteredParties.filter((p) => p.type === 'Customer' || p.type === 'Both');
  }, [filteredParties]);

  const suppliersList = useMemo(() => {
    return filteredParties.filter((p) => p.type === 'Supplier');
  }, [filteredParties]);

  const handleCreateQuickHead = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHeadName.trim()) {
      alert('Please enter expense head title.');
      return;
    }
    const created = addExpenseHead({
      name: newHeadName.trim(),
      category: newHeadCategory.trim() || 'General',
      description: newHeadDesc.trim(),
    });
    setExpenseHeadId(created.id);
    setNewHeadName('');
    setNewHeadDesc('');
    setShowQuickAddHead(false);
  };

  if (!journalModalOpen) return null;

  const numAmount = parseFloat(amount) || 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!accountId) {
      alert('Please select a Cash or Bank account.');
      return;
    }

    if (numAmount <= 0) {
      alert('Please enter a valid amount greater than 0.');
      return;
    }

    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const docNumber = `JV-2024-${randomSuffix}`;

    if (entryType === 'Out' && targetType === 'Expense') {
      if (!expenseHeadId) {
        alert('Please select an Expense Head.');
        return;
      }

      const headName = selectedExpenseHead?.name || 'Expense';
      const cleanRemarks = remarks.trim()
        ? `[Expense: ${headName}] ${remarks.trim()}`
        : `[Expense Out] ${headName}`;

      createTransaction({
        docNumber,
        type: 'Pay',
        date,
        time,
        expenseHeadId: selectedExpenseHead?.id,
        expenseHeadName: headName,
        accountId: selectedAccount?.id,
        accountName: selectedAccount?.name,
        items: [],
        totalAmount: numAmount,
        paidAmount: numAmount,
        balanceDue: 0,
        paymentStatus: 'Paid',
        notes: cleanRemarks,
      });
    } else {
      // Party Journal Entry (In or Out)
      if (!partyId && parties.length > 0) {
        alert('Please select a Party (Customer or Supplier).');
        return;
      }

      const txType = entryType === 'In' ? 'Receive' : 'Pay';
      const cleanRemarks = remarks.trim()
        ? `[Journal] ${remarks.trim()}`
        : `Journal Entry - ${entryType === 'In' ? 'Money In (Receipt)' : 'Money Out (Payment)'}`;

      createTransaction({
        docNumber,
        type: txType,
        date,
        time,
        partyId: selectedParty?.id,
        partyName: selectedParty?.name,
        accountId: selectedAccount?.id,
        accountName: selectedAccount?.name,
        items: [],
        totalAmount: numAmount,
        paidAmount: numAmount,
        balanceDue: 0,
        paymentStatus: 'Paid',
        notes: cleanRemarks,
      });
    }

    closeJournalModal();
  };

  return (
    <div className="fixed inset-0 bg-inverse-surface/40 backdrop-blur-sm z-50 flex items-center justify-center p-space-sm sm:p-space-md animate-in fade-in duration-150">
      <div className="bg-surface-container-lowest w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden border border-surface-container-high/60 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-space-md sm:px-space-lg py-3.5 bg-surface-container-low flex items-center justify-between border-b border-surface-container-high/60">
          <div className="flex items-center gap-space-sm">
            <div className="w-8 h-8 rounded-lg bg-primary-container text-on-primary flex items-center justify-center shadow-xs">
              <span className="material-symbols-outlined text-[19px]">edit_note</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                  Journal Entry
                </h3>
              </div>
              <p className="font-body-sm text-[12px] text-on-surface-variant">
                Direct Cash/Bank In &amp; Out entry for expenses, suppliers &amp; customers
              </p>
            </div>
          </div>
          <button
            onClick={closeJournalModal}
            className="w-8 h-8 rounded-full hover:bg-surface-container-high text-on-surface-variant flex items-center justify-center transition-colors"
            type="button"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Modal Form Body */}
        <form onSubmit={handleSubmit} className="p-space-md sm:p-space-lg overflow-y-auto space-y-space-md">
          {/* 1. Entry Type: In or Out */}
          <div>
            <label className="block font-label-sm text-label-sm font-semibold text-on-surface mb-1.5">
              Entry Type (In / Out) <span className="text-error">*</span>
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => handleTypeChange('In')}
                className={`py-2.5 px-3 rounded-xl border flex items-center justify-center gap-2 transition-all font-semibold text-[13px] ${
                  entryType === 'In'
                    ? 'bg-tertiary text-on-tertiary border-tertiary shadow-sm'
                    : 'bg-surface-container-low text-on-surface border-surface-container-high hover:bg-surface-container'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">call_received</span>
                <div className="text-left leading-tight">
                  <p>In (Money In)</p>
                  <p className="text-[10px] opacity-80 font-normal">Direct Receipt</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleTypeChange('Out')}
                className={`py-2.5 px-3 rounded-xl border flex items-center justify-center gap-2 transition-all font-semibold text-[13px] ${
                  entryType === 'Out'
                    ? 'bg-error text-on-error border-error shadow-sm'
                    : 'bg-surface-container-low text-on-surface border-surface-container-high hover:bg-surface-container'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">call_made</span>
                <div className="text-left leading-tight">
                  <p>Out (Money Out)</p>
                  <p className="text-[10px] opacity-80 font-normal">Direct Payment</p>
                </div>
              </button>
            </div>
          </div>

          {/* Date and Time Row */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block font-label-sm text-[12px] font-semibold text-on-surface mb-1">
                Date
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full h-9 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface border border-surface-container-high/60 focus:outline-none focus:ring-2 focus:ring-primary/20"
                required
              />
            </div>
            <div>
              <label className="block font-label-sm text-[12px] font-semibold text-on-surface mb-1">
                Time
              </label>
              <input
                type="text"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                placeholder="10:00 AM"
                className="w-full h-9 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface border border-surface-container-high/60 focus:outline-none focus:ring-2 focus:ring-primary/20"
              />
            </div>
          </div>

          {/* Cash / Bank Account Selector */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="font-label-sm text-label-sm font-semibold text-on-surface">
                Paid From / Into Account <span className="text-error">*</span>
              </label>
              {selectedAccount && (
                <span className="text-[11px] font-medium text-on-surface-variant">
                  Current Bal: <strong className="text-primary">{formatCurrency(selectedAccount.balance)}</strong>
                </span>
              )}
            </div>
            <select
              value={accountId}
              onChange={(e) => setAccountId(e.target.value)}
              className="w-full h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface border border-surface-container-high/60 focus:outline-none focus:ring-2 focus:ring-primary/20 font-medium"
              required
            >
              {accounts.map((acc) => (
                <option key={acc.id} value={acc.id}>
                  {acc.name} ({acc.type}) — Bal: Rs. {acc.balance.toLocaleString()}
                </option>
              ))}
            </select>
          </div>

          {/* When Out is chosen: Target Selector (Expense Head vs Party) */}
          {entryType === 'Out' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-label-sm text-label-sm font-semibold text-on-surface">
                  Payment Target <span className="text-error">*</span>
                </span>
                <span className="text-[11px] text-on-surface-variant font-medium">
                  {targetType === 'Expense' ? 'Depot Expense Head' : 'Party Ledger'}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 bg-surface-container-low p-1 rounded-xl border border-surface-container-high/40">
                <button
                  type="button"
                  onClick={() => setTargetType('Expense')}
                  className={`py-2 px-3 rounded-lg text-[12px] font-bold flex items-center justify-center gap-1.5 transition-all ${
                    targetType === 'Expense'
                      ? 'bg-surface-container-lowest text-primary shadow-xs border border-primary/20'
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  <span className="material-symbols-outlined text-[17px]">receipt_long</span>
                  <span>Expense Head</span>
                </button>
                <button
                  type="button"
                  onClick={() => setTargetType('Party')}
                  className={`py-2 px-3 rounded-lg text-[12px] font-bold flex items-center justify-center gap-1.5 transition-all ${
                    targetType === 'Party'
                      ? 'bg-surface-container-lowest text-primary shadow-xs border border-primary/20'
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  <span className="material-symbols-outlined text-[17px]">group</span>
                  <span>Party</span>
                </button>
              </div>
            </div>
          )}

          {/* TARGET 1: EXPENSE HEADS DROPDOWN (Shown on Out when target is Expense) */}
          {entryType === 'Out' && targetType === 'Expense' && (
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="font-label-sm text-label-sm font-semibold text-on-surface flex items-center gap-1">
                  <span>Expense Head</span>
                  <span className="text-error">*</span>
                </label>
                <button
                  type="button"
                  onClick={() => setShowQuickAddHead(!showQuickAddHead)}
                  className="text-[11px] font-bold text-primary hover:text-primary/80 flex items-center gap-0.5"
                >
                  <span className="material-symbols-outlined text-[14px]">add_circle</span>
                  <span>{showQuickAddHead ? 'Hide Form' : '+ Add New Head'}</span>
                </button>
              </div>

              {/* Inline Quick Add Head Drawer */}
              {showQuickAddHead && (
                <div className="p-3 bg-primary-container/10 border border-primary/20 rounded-xl space-y-2 mb-2 animate-in fade-in duration-150">
                  <div className="flex items-center justify-between">
                    <span className="text-[12px] font-bold text-primary">Add New Expense Head</span>
                    <button
                      type="button"
                      onClick={() => setShowQuickAddHead(false)}
                      className="text-on-surface-variant text-[14px] hover:text-on-surface"
                    >
                      ✕
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={newHeadName}
                      onChange={(e) => setNewHeadName(e.target.value)}
                      placeholder="Head Name (e.g. Generator Diesel)"
                      className="h-8 px-2.5 text-[12px] bg-surface-container-lowest rounded-md text-on-surface border border-surface-container-high focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                    <select
                      value={newHeadCategory}
                      onChange={(e) => setNewHeadCategory(e.target.value)}
                      className="h-8 px-2 text-[12px] bg-surface-container-lowest rounded-md text-on-surface border border-surface-container-high focus:outline-none focus:ring-1 focus:ring-primary"
                    >
                      <option value="Rent & Premises">Rent &amp; Premises</option>
                      <option value="Utilities">Utilities</option>
                      <option value="Utilities & Fuel">Utilities &amp; Fuel</option>
                      <option value="Labor & Wages">Labor &amp; Wages</option>
                      <option value="Logistics">Logistics &amp; Transport</option>
                      <option value="Office & Mess">Office &amp; Mess</option>
                      <option value="Maintenance">Maintenance</option>
                      <option value="Operations">Operations</option>
                      <option value="Miscellaneous">Miscellaneous</option>
                    </select>
                  </div>
                  <div className="flex items-center justify-end gap-1.5 pt-1">
                    <button
                      type="button"
                      onClick={() => setShowQuickAddHead(false)}
                      className="px-2.5 py-1 text-[11px] rounded bg-surface-container-low text-on-surface-variant font-medium"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleCreateQuickHead}
                      className="px-3 py-1 text-[11px] rounded bg-primary text-white font-semibold flex items-center gap-1 shadow-xs"
                    >
                      <span className="material-symbols-outlined text-[13px]">check</span>
                      <span>Save &amp; Select</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Expense Head Dropdown */}
              <select
                value={expenseHeadId}
                onChange={(e) => setExpenseHeadId(e.target.value)}
                className="w-full h-11 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface border border-surface-container-high/60 focus:outline-none focus:ring-2 focus:ring-primary/20 font-medium"
                required
              >
                <option value="" disabled>
                  -- Select Expense Head --
                </option>
                {Object.entries(expenseHeadsByCategory).map(([category, heads]) => (
                  <optgroup key={category} label={`── ${category} ──`}>
                    {heads.map((h) => {
                      const spending = getExpenseHeadSpending(h.id);
                      const spendingStr = spending > 0 ? ` (Total: Rs. ${spending.toLocaleString()})` : '';
                      return (
                        <option key={h.id} value={h.id}>
                          {h.name} {spendingStr}
                        </option>
                      );
                    })}
                  </optgroup>
                ))}
              </select>

              {/* Selected Head Info Pill */}
              {selectedExpenseHead && (
                <div className="flex items-center justify-between text-[11px] text-on-surface-variant px-1 pt-0.5">
                  <span className="truncate">
                    Category: <strong className="text-on-surface">{selectedExpenseHead.category}</strong>
                    {selectedExpenseHead.description && ` · ${selectedExpenseHead.description}`}
                  </span>
                  <span className="shrink-0 text-primary font-semibold">
                    Spent: Rs. {getExpenseHeadSpending(selectedExpenseHead.id).toLocaleString()}
                  </span>
                </div>
              )}
            </div>
          )}

          {/* TARGET 2: PARTY DROPDOWN (Shown on In, or on Out when target is Party) */}
          {(entryType === 'In' || (entryType === 'Out' && targetType === 'Party')) && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-label-sm text-label-sm font-semibold text-on-surface">
                  Party (Customer / Supplier) <span className="text-error">*</span>
                </label>
                {selectedParty && (
                  <span className="text-[11px] font-medium text-on-surface-variant">
                    {selectedParty.currentBalance > 0 ? (
                      <span className="text-tertiary font-semibold">
                        Receivable: {formatCurrency(selectedParty.currentBalance)}
                      </span>
                    ) : selectedParty.currentBalance < 0 ? (
                      <span className="text-error font-semibold">
                        Payable: {formatCurrency(Math.abs(selectedParty.currentBalance))}
                      </span>
                    ) : (
                      <span className="text-on-surface-variant font-semibold">Nil Balance</span>
                    )}
                  </span>
                )}
              </div>

              {/* Quick search filter for long party lists */}
              {parties.length > 5 && (
                <div className="relative mb-1.5">
                  <span className="material-symbols-outlined absolute left-2.5 top-1/2 -translate-y-1/2 text-on-surface-variant text-[16px]">
                    search
                  </span>
                  <input
                    type="text"
                    value={partySearch}
                    onChange={(e) => setPartySearch(e.target.value)}
                    placeholder="Filter customers or suppliers..."
                    className="w-full h-8 pl-8 pr-7 text-[12px] bg-surface-container-low rounded-md text-on-surface border border-surface-container-high/40 focus:outline-none focus:ring-1 focus:ring-primary/20"
                  />
                  {partySearch && (
                    <button
                      type="button"
                      onClick={() => setPartySearch('')}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-on-surface-variant hover:text-on-surface text-[14px]"
                    >
                      ×
                    </button>
                  )}
                </div>
              )}

              {/* Complete dropdown showing all suppliers and customers */}
              <select
                value={partyId}
                onChange={(e) => setPartyId(e.target.value)}
                className="w-full h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface border border-surface-container-high/60 focus:outline-none focus:ring-2 focus:ring-primary/20 font-medium"
                required
              >
                <option value="" disabled>
                  -- Select Customer or Supplier --
                </option>

                {customersList.length > 0 && (
                  <optgroup label="── Customers ──">
                    {customersList.map((p) => {
                      const balStr =
                        p.currentBalance > 0
                          ? `(Receivable: Rs. ${p.currentBalance.toLocaleString()})`
                          : p.currentBalance < 0
                          ? `(Advance: Rs. ${Math.abs(p.currentBalance).toLocaleString()})`
                          : '(Nil)';
                      return (
                        <option key={p.id} value={p.id}>
                          [Customer] {p.name} - {p.city} {balStr}
                        </option>
                      );
                    })}
                  </optgroup>
                )}

                {suppliersList.length > 0 && (
                  <optgroup label="── Suppliers ──">
                    {suppliersList.map((p) => {
                      const balStr =
                        p.currentBalance < 0
                          ? `(Payable: Rs. ${Math.abs(p.currentBalance).toLocaleString()})`
                          : p.currentBalance > 0
                          ? `(Advance Paid: Rs. ${p.currentBalance.toLocaleString()})`
                          : '(Nil)';
                      return (
                        <option key={p.id} value={p.id}>
                          [Supplier] {p.name} - {p.city} {balStr}
                        </option>
                      );
                    })}
                  </optgroup>
                )}
              </select>
            </div>
          )}

          {/* Amount Entry */}
          <div>
            <label className="block font-label-sm text-label-sm font-semibold text-on-surface mb-1">
              Amount <span className="text-error">*</span>
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 font-headline-sm text-[13px] font-bold text-on-surface-variant">
                Rs.
              </span>
              <input
                type="number"
                min="1"
                step="any"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full h-11 pl-10 pr-4 bg-surface-container-low rounded-lg text-[16px] font-bold text-on-surface border border-surface-container-high/60 focus:outline-none focus:ring-2 focus:ring-primary/20 placeholder:text-on-surface-variant/40"
                required
              />
            </div>
            {numAmount > 0 && (
              <p className="mt-1 text-[11px] font-medium text-on-surface-variant">
                Formatted: <span className="text-primary font-bold">{formatCurrency(numAmount)}</span>
              </p>
            )}
          </div>

          {/* Remarks */}
          <div>
            <label className="block font-label-sm text-label-sm font-semibold text-on-surface mb-1">
              Remarks
            </label>
            <textarea
              rows={2}
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder={
                entryType === 'Out' && targetType === 'Expense'
                  ? 'e.g. Paid cash for WAPDA bill, fuel for 20L diesel, or receipt #...'
                  : 'e.g. Cash recovery, cheque deposit, market advance, or reference #...'
              }
              className="w-full p-2.5 bg-surface-container-low rounded-lg text-body-sm text-on-surface border border-surface-container-high/60 focus:outline-none focus:ring-2 focus:ring-primary/20 placeholder:text-on-surface-variant/50 resize-none"
            />
          </div>

          {/* Effect Summary preview */}
          {numAmount > 0 && selectedAccount && (
            <div className="p-3 rounded-xl bg-surface-container-low/70 border border-surface-container-high/60 text-[12px] space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-on-surface-variant">Account Deduction/Credit:</span>
                <span className={`font-semibold ${entryType === 'In' ? 'text-tertiary' : 'text-error'}`}>
                  {selectedAccount.name} {entryType === 'In' ? `+${formatCurrency(numAmount)}` : `-${formatCurrency(numAmount)}`}
                </span>
              </div>
              {entryType === 'Out' && targetType === 'Expense' && selectedExpenseHead && (
                <div className="flex items-center justify-between">
                  <span className="text-on-surface-variant">Expense Head Posting:</span>
                  <span className="font-semibold text-error">
                    {selectedExpenseHead.name} (+{formatCurrency(numAmount)})
                  </span>
                </div>
              )}
              {targetType === 'Party' && selectedParty && (
                <div className="flex items-center justify-between">
                  <span className="text-on-surface-variant">Party Ledger ({selectedParty.name}):</span>
                  <span className="font-semibold text-on-surface">
                    {entryType === 'In' ? 'Credit (- balance)' : 'Debit (+ balance)'}
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Actions */}
          <div className="pt-2 flex items-center justify-end gap-2 border-t border-surface-container-high/60">
            <button
              type="button"
              onClick={closeJournalModal}
              className="h-10 px-4 rounded-lg bg-surface-container-low hover:bg-surface-container text-on-surface font-label-md text-label-md font-semibold transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`h-10 px-5 rounded-lg text-white font-label-md text-label-md font-semibold flex items-center gap-1.5 shadow-sm active:scale-[0.98] transition-all ${
                entryType === 'In'
                  ? 'bg-tertiary hover:opacity-95'
                  : 'bg-primary-container hover:bg-primary'
              }`}
            >
              <span className="material-symbols-outlined text-[18px]">check</span>
              <span>
                {entryType === 'Out' && targetType === 'Expense' ? 'Save Expense JV Out' : 'Save Journal Entry'}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
