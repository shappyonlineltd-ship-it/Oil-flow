import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductCategory, UnitType } from '../../types';

export const ProductDrawer: React.FC = () => {
  const { productDrawerOpen, closeProductDrawer, editingProduct, addProduct, updateProduct } = useApp();

  const [name, setName] = useState('');
  const [grade, setGrade] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<ProductCategory>('Engine Oils');
  const [unit, setUnit] = useState<UnitType>('Drum');
  const [packingSize, setPackingSize] = useState<number>(200);
  const [packingUnit, setPackingUnit] = useState<'Liter' | 'Kg' | 'Piece'>('Liter');
  const [currentStock, setCurrentStock] = useState<number>(10);
  const [purchaseCost, setPurchaseCost] = useState<number>(22000);
  const [salePrice, setSalePrice] = useState<number>(25500);
  const [minAlertThreshold, setMinAlertThreshold] = useState<number>(5);
  const [tankLocation, setTankLocation] = useState<string>('Tank #1');

  useEffect(() => {
    if (editingProduct) {
      setName(editingProduct.name);
      setGrade(editingProduct.grade);
      setDescription(editingProduct.description || '');
      setCategory(editingProduct.category);
      setUnit(editingProduct.unit);
      setPackingSize(editingProduct.packingSize);
      setPackingUnit(editingProduct.packingUnit);
      setCurrentStock(editingProduct.currentStock);
      setPurchaseCost(editingProduct.purchaseCost);
      setSalePrice(editingProduct.salePrice);
      setMinAlertThreshold(editingProduct.minAlertThreshold);
      setTankLocation(editingProduct.tankLocation || '');
    } else {
      setName('');
      setGrade('');
      setDescription('');
      setCategory('Engine Oils');
      setUnit('Drum');
      setPackingSize(200);
      setPackingUnit('Liter');
      setCurrentStock(0);
      setPurchaseCost(0);
      setSalePrice(0);
      setMinAlertThreshold(5);
      setTankLocation('');
    }
  }, [editingProduct, productDrawerOpen]);

  // Adjust default packing size based on unit
  const handleUnitChange = (newUnit: UnitType) => {
    setUnit(newUnit);
    if (newUnit === 'Drum') {
      setPackingSize(200);
      setPackingUnit('Liter');
    } else if (newUnit === 'Can') {
      setPackingSize(4);
      setPackingUnit('Liter');
    } else if (newUnit === 'Bottle') {
      setPackingSize(1);
      setPackingUnit('Liter');
    } else if (newUnit === 'Kg') {
      setPackingSize(1);
      setPackingUnit('Kg');
    } else if (newUnit === 'Bucket') {
      setPackingSize(16);
      setPackingUnit('Liter');
    } else if (newUnit === 'Piece') {
      setPackingSize(1);
      setPackingUnit('Piece');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Please enter product name.');
      return;
    }

    const payload = {
      name: name.trim(),
      grade: grade.trim(),
      description: description.trim(),
      category,
      unit,
      packingSize: Number(packingSize) || 1,
      packingUnit,
      currentStock: Number(currentStock) || 0,
      purchaseCost: Number(purchaseCost) || 0,
      salePrice: Number(salePrice) || 0,
      minAlertThreshold: Number(minAlertThreshold) || 1,
      tankLocation: tankLocation.trim(),
    };

    if (editingProduct) {
      updateProduct(editingProduct.id, payload);
    } else {
      addProduct(payload);
    }

    closeProductDrawer();
  };

  if (!productDrawerOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-inverse-surface/40 backdrop-blur-sm transition-opacity"
        onClick={closeProductDrawer}
      />

      {/* Slide-over Drawer */}
      <div className="relative w-full max-w-lg bg-surface-container-lowest shadow-2xl flex flex-col h-full z-10 animate-in slide-in-from-right duration-250">
        {/* Drawer Header */}
        <div className="p-space-lg bg-surface-container-low flex items-center justify-between border-b border-surface-container-high/60">
          <div>
            <div className="flex items-center gap-space-xs text-primary font-label-sm text-label-sm font-semibold uppercase tracking-wider">
              <span className="material-symbols-outlined text-[16px]">add_box</span>
              <span>{editingProduct ? 'Update Catalog Item' : 'New Catalog Item'}</span>
            </div>
            <h3 className="font-headline-md text-headline-md text-on-surface mt-1">
              {editingProduct ? 'Edit Stock Product' : 'Add Stock Product'}
            </h3>
            <p className="font-body-sm text-body-sm text-on-surface-variant">
              Register a petroleum lubricant or base grade into the warehouse depot.
            </p>
          </div>
          <button
            type="button"
            onClick={closeProductDrawer}
            className="w-8 h-8 rounded-lg hover:bg-surface-container-high flex items-center justify-center text-on-surface-variant transition-colors"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Drawer Body Form */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-space-lg space-y-space-md">
          {/* Field 1: Name */}
          <div className="flex flex-col gap-1">
            <label className="font-label-md text-label-md text-on-surface font-semibold">
              Product Name <span className="text-error">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Engine Oil 20W-50, Base Oil SN-150"
              required
              className="h-10 px-space-md bg-surface-container-low rounded-lg font-body-md text-body-md text-on-surface placeholder:text-on-surface-variant focus:outline-none focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary/20"
            />
          </div>

          {/* Field 1b: Viscosity / Grade */}
          <div className="flex flex-col gap-1">
            <label className="font-label-md text-label-md text-on-surface font-semibold">
              Viscosity Grade / Spec
            </label>
            <input
              type="text"
              value={grade}
              onChange={(e) => setGrade(e.target.value)}
              placeholder="e.g. SN-150, API SL/CF, ISO VG 68"
              className="h-10 px-space-md bg-surface-container-low rounded-lg font-body-md text-body-md text-on-surface placeholder:text-on-surface-variant focus:outline-none focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary/20"
            />
          </div>

          {/* Field 2 & 3: Category & Unit */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-space-md">
            <div className="flex flex-col gap-1">
              <label className="font-label-md text-label-md text-on-surface font-semibold">
                Category <span className="text-error">*</span>
              </label>
              <div className="relative">
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as ProductCategory)}
                  className="w-full h-10 px-space-md bg-surface-container-low rounded-lg font-body-md text-body-md text-on-surface appearance-none focus:outline-none focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary/20"
                >
                  <option value="Engine Oils">Engine Oils</option>
                  <option value="Base Oils">Base Oils</option>
                  <option value="Gear Oils">Gear Oils</option>
                  <option value="Greases">Greases</option>
                  <option value="Industrial Oils">Industrial Oils</option>
                  <option value="Transmission Fluids">Transmission Fluids</option>
                  <option value="Additives">Additives</option>
                </select>
                <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-on-surface-variant text-[18px]">
                  expand_more
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <label className="font-label-md text-label-md text-on-surface font-semibold">
                Measurement Unit <span className="text-error">*</span>
              </label>
              <div className="relative">
                <select
                  value={unit}
                  onChange={(e) => handleUnitChange(e.target.value as UnitType)}
                  className="w-full h-10 px-space-md bg-surface-container-low rounded-lg font-body-md text-body-md text-on-surface appearance-none focus:outline-none focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary/20"
                >
                  <option value="Drum">Drum</option>
                  <option value="Can">Can</option>
                  <option value="Bottle">Bottle</option>
                  <option value="Bucket">Bucket</option>
                  <option value="Kg">Kg / Pack</option>
                  <option value="Liter">Liter (Loose)</option>
                  <option value="Piece">Piece / Accessory</option>
                </select>
                <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-on-surface-variant text-[18px]">
                  expand_more
                </span>
              </div>
            </div>
          </div>

          {/* Field 4: Configurable Packing Size Spec */}
          <div className="flex flex-col gap-1">
            <label className="font-label-md text-label-md text-on-surface font-semibold">
              Configurable Packing Size (1 {unit} =)
            </label>
            <div className="flex items-center gap-space-xs">
              <input
                type="number"
                min="0.1"
                step="any"
                value={packingSize === 0 ? '' : packingSize}
                onChange={(e) => setPackingSize(e.target.value === '' ? 0 : Number(e.target.value))}
                placeholder="200"
                className="h-10 px-space-md bg-surface-container-low rounded-lg font-body-md text-body-md text-on-surface w-full focus:outline-none focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary/20"
              />
              <select
                value={packingUnit}
                onChange={(e) => setPackingUnit(e.target.value as 'Liter' | 'Kg' | 'Piece')}
                className="h-10 px-space-md bg-surface-container-high rounded-lg font-label-md text-label-md text-on-surface font-semibold focus:outline-none"
              >
                <option value="Liter">Liters</option>
                <option value="Kg">Kgs</option>
                <option value="Piece">Pieces</option>
              </select>
            </div>
            <p className="text-[11px] text-on-surface-variant">
              Example: 1 Drum = 200 Liters. If 10 drums purchased, stock = 10 Drums (2,000 Liters total).
            </p>
          </div>

          {/* Field 5: Current Physical Stock */}
          <div className="flex flex-col gap-1">
            <label className="font-label-md text-label-md text-on-surface font-semibold">
              Current Physical Stock (in {unit}s)
            </label>
            <input
              type="number"
              min="0"
              value={currentStock === 0 ? '' : currentStock}
              placeholder="0"
              onChange={(e) => setCurrentStock(e.target.value === '' ? 0 : Number(e.target.value))}
              className="h-10 px-space-md bg-surface-container-low rounded-lg font-body-md text-body-md text-on-surface focus:outline-none focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary/20"
            />
            <span className="text-[12px] text-primary font-semibold">
              Equates to {(currentStock * packingSize).toLocaleString()} {packingUnit}s total
            </span>
          </div>

          {/* Field 6 & 7: Manual Purchase Cost & Sale Price */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-space-md">
            <div className="flex flex-col gap-1">
              <label className="font-label-md text-label-md text-on-surface font-semibold">
                Purchase Cost (Rs. / {unit}) <span className="text-error">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 font-label-sm text-label-sm font-bold text-on-surface-variant">
                  Rs.
                </span>
                <input
                  type="number"
                  min="0"
                  value={purchaseCost === 0 ? '' : purchaseCost}
                  onChange={(e) => setPurchaseCost(e.target.value === '' ? 0 : Number(e.target.value))}
                  placeholder="0.00"
                  className="h-10 pl-10 pr-space-md bg-surface-container-low rounded-lg font-body-md text-body-md text-on-surface w-full focus:outline-none focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary/20"
                />
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <label className="font-label-md text-label-md text-on-surface font-semibold">
                Sale Price (Rs. / {unit}) <span className="text-error">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 font-label-sm text-label-sm font-bold text-on-surface-variant">
                  Rs.
                </span>
                <input
                  type="number"
                  min="0"
                  value={salePrice === 0 ? '' : salePrice}
                  onChange={(e) => setSalePrice(e.target.value === '' ? 0 : Number(e.target.value))}
                  placeholder="0.00"
                  className="h-10 pl-10 pr-space-md bg-surface-container-low rounded-lg font-body-md text-body-md text-on-surface w-full focus:outline-none focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary/20"
                />
              </div>
            </div>
          </div>

          {/* Live Calculated Total Stock Value Card */}
          <div className="p-space-md rounded-xl bg-surface-container-lowest border border-primary/20 shadow-xs flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="font-label-sm text-label-sm text-primary font-bold uppercase tracking-wider flex items-center gap-1">
                <span className="material-symbols-outlined text-[16px]">account_balance_wallet</span>
                <span>Individual Stock Valuation</span>
              </span>
              <span className="text-[11px] text-on-surface-variant font-medium">
                {currentStock} {unit}s in depot
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2 pt-1 border-t border-surface-container-high/40">
              <div>
                <span className="text-[11px] text-on-surface-variant block">Total Cost Value:</span>
                <span className="font-bold text-on-surface text-[15px]">
                  Rs. {(currentStock * purchaseCost).toLocaleString()}
                </span>
              </div>
              <div className="text-right">
                <span className="text-[11px] text-on-surface-variant block">Retail Worth:</span>
                <span className="font-bold text-tertiary text-[15px]">
                  Rs. {(currentStock * salePrice).toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* Field 8: Min Reorder Alert Threshold */}
          <div className="p-space-md rounded-xl bg-surface-container-low flex flex-col gap-2 border border-surface-container-high/40">
            <div className="flex items-center justify-between">
              <label className="font-label-md text-label-md text-on-surface font-semibold">
                Min Reorder Level (Low Stock Alert)
              </label>
              <span className="material-symbols-outlined text-primary text-[18px]">notifications_active</span>
            </div>
            <p className="font-body-sm text-body-sm text-on-surface-variant">
              Triggers warning badge and low stock banner once depot balance falls below this unit count.
            </p>
            <div className="flex items-center gap-space-xs mt-1">
              <input
                type="number"
                min="0"
                value={minAlertThreshold === 0 ? '' : minAlertThreshold}
                placeholder="0"
                onChange={(e) => setMinAlertThreshold(e.target.value === '' ? 0 : Number(e.target.value))}
                className="h-10 px-space-md bg-surface-container-lowest rounded-lg font-body-md text-body-md text-on-surface w-32 focus:outline-none focus:ring-2 focus:ring-primary/20"
              />
              <span className="font-label-md text-label-md text-on-surface-variant">{unit}s threshold</span>
            </div>
          </div>

          {/* Field 9: Location */}
          <div className="flex flex-col gap-1">
            <label className="font-label-md text-label-md text-on-surface font-semibold">
              Tank Farm / Yard Location
            </label>
            <input
              type="text"
              value={tankLocation}
              onChange={(e) => setTankLocation(e.target.value)}
              placeholder="e.g. Tank #1, Yard B, Rack Bay 04"
              className="h-10 px-space-md bg-surface-container-low rounded-lg font-body-md text-body-md text-on-surface focus:outline-none focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary/20"
            />
          </div>

          {/* Footer Actions */}
          <div className="p-space-md bg-surface-container-low flex items-center justify-end gap-space-sm rounded-xl">
            <button
              type="button"
              onClick={closeProductDrawer}
              className="h-10 px-space-md rounded-lg text-on-surface-variant hover:text-on-surface font-label-md text-label-md font-semibold transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="h-10 px-space-lg rounded-lg bg-primary text-on-primary hover:bg-primary-container font-label-md text-label-md font-semibold shadow-sm transition-colors active:scale-98"
            >
              {editingProduct ? 'Save Product Changes' : 'Save & Add Stock'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
