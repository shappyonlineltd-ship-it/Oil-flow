import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  generateAccountLedgerPDF,
  shareOnWhatsApp,
  shareNative,
  copyTextToClipboard,
} from '../../utils/pdfGenerator';

export const AccountLedgerModal: React.FC = () => {
  const {
    viewingAccountLedgerId,
    closeAccountLedgerModal,
    accounts,
    transactions,
    openViewTransactionModal,
    openPdfPreview,
    settings,
  } = useApp();

  const [viewMode, setViewMode] = useState<'standard' | 'pdf'>('standard');
  const [dateFilter, setDateFilter] = useState<'all' | '30days' | 'thisMonth'>('all');
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);

  const account = useMemo(() => {
    return accounts.find((a) => a.id === viewingAccountLedgerId);
  }, [accounts, viewingAccountLedgerId]);

  const allAccountHistory = useMemo(() => {
    if (!account) return [];

    const relevant = transactions
      .filter((t) => {
        if (t.type === 'Transfer') {
          return t.accountId === account.id || t.toAccountId === account.id;
        }
        return t.accountId === account.id && (t.paidAmount || 0) > 0;
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    let balance = account.openingBalance || 0;

    return relevant.map((tx) => {
      let inflow = 0;
      let outflow = 0;
      let desc = '';

      if (tx.type === 'Transfer') {
        if (tx.accountId === account.id) {
          outflow = tx.totalAmount;
          desc = `Transfer to ${tx.toAccountName}`;
          balance -= outflow;
        } else {
          inflow = tx.totalAmount;
          desc = `Transfer from ${tx.accountName}`;
          balance += inflow;
        }
      } else if (tx.type === 'Sale' || tx.type === 'Receive') {
        inflow = tx.paidAmount;
        desc = `${tx.type}: ${tx.partyName || tx.docNumber}`;
        balance += inflow;
      } else if (tx.type === 'Purchase' || tx.type === 'Pay') {
        outflow = tx.paidAmount;
        desc = tx.expenseHeadName ? `Expense: ${tx.expenseHeadName}` : `${tx.type}: ${tx.partyName || tx.docNumber}`;
        balance -= outflow;
      }

      return {
        id: tx.id,
        docNumber: tx.docNumber,
        date: tx.date,
        time: tx.time,
        type: tx.type,
        partyName: tx.partyName,
        description: desc,
        inflow,
        outflow,
        runningBalance: balance,
        rawTx: tx,
      };
    });
  }, [account, transactions]);

  const accountHistory = useMemo(() => {
    if (dateFilter === 'all') return allAccountHistory;

    const now = new Date();
    return allAccountHistory.filter((item) => {
      const itemDate = new Date(item.date);
      if (dateFilter === '30days') {
        const diffDays = (now.getTime() - itemDate.getTime()) / (1000 * 3600 * 24);
        return diffDays <= 30;
      }
      if (dateFilter === 'thisMonth') {
        return (
          itemDate.getMonth() === now.getMonth() &&
          itemDate.getFullYear() === now.getFullYear()
        );
      }
      return true;
    });
  }, [allAccountHistory, dateFilter]);

  if (!account) return null;

  const totalInflow = accountHistory.reduce((s, r) => s + r.inflow, 0);
  const totalOutflow = accountHistory.reduce((s, r) => s + r.outflow, 0);

  // PDF Export
  const handleDownloadPDF = () => {
    generateAccountLedgerPDF(account, accountHistory, settings);
  };

  // WhatsApp Share
  const handleWhatsAppShare = () => {
    const text = `*OILFLOW PETROLEUM - ACCOUNT STATEMENT*\n` +
      `--------------------------------\n` +
      `Account: ${account.name} (${account.type})\n` +
      `${account.bankName ? `Bank: ${account.bankName}\n` : ''}` +
      `${account.accountNumber ? `A/C #: ${account.accountNumber}\n` : ''}` +
      `Date: ${new Date().toLocaleDateString()}\n` +
      `Total Inflow (+): Rs. ${totalInflow.toLocaleString()}\n` +
      `Total Outflow (-): Rs. ${totalOutflow.toLocaleString()}\n` +
      `*Current Balance: Rs. ${account.balance.toLocaleString()}*\n` +
      `Total Entries: ${accountHistory.length}\n` +
      `--------------------------------\n` +
      `Generated from OilFlow ERP Management System.`;
    shareOnWhatsApp(text);
  };

  // Web Share
  const handleNativeShare = async () => {
    const text = `OilFlow Account Statement for ${account.name} - Available Balance: Rs. ${account.balance.toLocaleString()}. Inflow: Rs. ${totalInflow.toLocaleString()}, Outflow: Rs. ${totalOutflow.toLocaleString()}.`;
    const shared = await shareNative({
      title: `${account.name} Ledger Statement`,
      text,
      url: window.location.href,
    });
    if (!shared) {
      handleCopyText();
    }
  };

  // Copy statement text
  const handleCopyText = async () => {
    const text = `=== OILFLOW ACCOUNT LEDGER STATEMENT ===\n` +
      `Account: ${account.name} (${account.type})\n` +
      `${account.accountNumber ? `Account No: ${account.accountNumber}\n` : ''}` +
      `Current Balance: Rs. ${account.balance.toLocaleString()}\n` +
      `Total Inflow: Rs. ${totalInflow.toLocaleString()}\n` +
      `Total Outflow: Rs. ${totalOutflow.toLocaleString()}\n` +
      `Total Transactions: ${accountHistory.length}\n\n` +
      `Recent Entries:\n` +
      accountHistory
        .slice(-8)
        .map(
          (r) =>
            `${r.date} | ${r.docNumber} | ${r.description} | In: Rs.${r.inflow.toLocaleString()} | Out: Rs.${r.outflow.toLocaleString()} | Bal: Rs.${r.runningBalance.toLocaleString()}`
        )
        .join('\n');

    const ok = await copyTextToClipboard(text);
    if (ok) {
      setCopyFeedback('Statement copied to clipboard!');
      setTimeout(() => setCopyFeedback(null), 3000);
    }
  };

  return (
    <div className="flex flex-col w-full pb-space-xl animate-in fade-in duration-150">
      {/* Top In-Page Back Navigation */}
      <div className="flex items-center justify-between gap-space-sm mb-space-md no-print">
        <div className="flex items-center gap-space-sm">
          <button
            type="button"
            onClick={closeAccountLedgerModal}
            className="h-10 px-space-md bg-surface-container-low hover:bg-surface-container text-on-surface rounded-lg flex items-center gap-space-xs font-label-md text-label-md font-semibold transition-colors shadow-xs active:scale-98"
          >
            <span className="material-symbols-outlined text-[20px]">arrow_back</span>
            <span>Back to Accounts</span>
          </button>
          <div className="hidden sm:flex items-center gap-space-xs text-on-surface-variant font-label-sm uppercase tracking-wider">
            <span>Financials</span>
            <span className="material-symbols-outlined text-[14px]">chevron_right</span>
            <span>Banking &amp; Cash Book</span>
            <span className="material-symbols-outlined text-[14px]">chevron_right</span>
            <span className="text-primary font-semibold">{account.name} Ledger</span>
          </div>
        </div>
      </div>

      <div className="bg-surface-container-lowest w-full rounded-2xl shadow-sm overflow-hidden flex flex-col border border-surface-container-high/60 print-page">
        {/* Header - Hidden on physical print */}
        <div className="px-space-md sm:px-space-lg py-3.5 bg-surface-container-low flex flex-col md:flex-row md:items-center justify-between gap-space-sm border-b border-surface-container-high/60 no-print">
          <div className="flex items-center gap-space-sm">
            <div className="w-10 h-10 rounded-xl bg-primary-container text-on-primary flex items-center justify-center shadow-xs">
              <span className="material-symbols-outlined text-[20px]">
                {account.type === 'Cash' ? 'payments' : 'account_balance'}
              </span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-headline-md text-headline-md font-bold text-on-surface">
                  {account.name}
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-primary-fixed text-primary">
                  {account.type} Book
                </span>
              </div>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                {account.type === 'Cash'
                  ? 'Vault Safe Physical Cash Book'
                  : `${account.bankName || 'Bank'} · A/C: ${account.accountNumber || 'Primary'}`}
              </p>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-wrap items-center gap-1.5 self-end md:self-auto">
            {/* View Mode Switcher */}
            <div className="flex items-center bg-surface-container-lowest p-1 rounded-lg border border-surface-container-high/60 mr-1">
              <button
                type="button"
                onClick={() => setViewMode('standard')}
                className={`px-2.5 py-1 rounded-md text-[12px] font-semibold transition-colors flex items-center gap-1 ${
                  viewMode === 'standard'
                    ? 'bg-primary text-on-primary shadow-xs'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                <span className="material-symbols-outlined text-[15px]">table_rows</span>
                <span>Ledger</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('pdf')}
                className={`px-2.5 py-1 rounded-md text-[12px] font-semibold transition-colors flex items-center gap-1 ${
                  viewMode === 'pdf'
                    ? 'bg-primary text-on-primary shadow-xs'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                <span className="material-symbols-outlined text-[15px]">picture_as_pdf</span>
                <span>PDF View</span>
              </button>
            </div>

            {/* Download PDF button */}
            <button
              onClick={handleDownloadPDF}
              type="button"
              className="h-8 px-2.5 rounded-lg bg-primary text-on-primary hover:bg-primary-container text-[12px] font-semibold flex items-center gap-1 shadow-xs transition-colors"
              title="Download official PDF file"
            >
              <span className="material-symbols-outlined text-[16px]">download</span>
              <span className="hidden sm:inline">PDF</span>
            </button>

            {/* WhatsApp Share */}
            <button
              onClick={handleWhatsAppShare}
              type="button"
              className="h-8 px-2.5 rounded-lg bg-tertiary-fixed text-on-tertiary-fixed hover:bg-tertiary-fixed/80 text-[12px] font-semibold flex items-center gap-1 shadow-xs transition-colors"
              title="Share statement on WhatsApp"
            >
              <span className="material-symbols-outlined text-[16px]">share</span>
              <span>WhatsApp</span>
            </button>

            {/* Share / Copy */}
            <button
              onClick={handleNativeShare}
              type="button"
              className="h-8 px-2 rounded-lg bg-surface-container-lowest hover:bg-surface-container text-on-surface-variant text-[12px] font-semibold flex items-center gap-1 border border-surface-container-high/60 transition-colors"
              title="Share or Copy Statement"
            >
              <span className="material-symbols-outlined text-[16px]">content_copy</span>
              <span className="hidden sm:inline">Copy</span>
            </button>

            {/* Print button */}
            <button
              onClick={() => window.print()}
              type="button"
              className="w-8 h-8 rounded-lg bg-surface-container-lowest hover:bg-surface-container text-on-surface-variant flex items-center justify-center border border-surface-container-high/60 transition-colors"
              title="Print document or Save to PDF"
            >
              <span className="material-symbols-outlined text-[18px]">print</span>
            </button>

            {/* Close button */}
            <button
              onClick={closeAccountLedgerModal}
              className="w-8 h-8 rounded-full hover:bg-surface-container-high text-on-surface-variant flex items-center justify-center transition-colors ml-1"
              type="button"
            >
              <span className="material-symbols-outlined text-[20px]">close</span>
            </button>
          </div>
        </div>

        {/* Copy Feedback notification */}
        {copyFeedback && (
          <div className="bg-tertiary-fixed text-on-tertiary-fixed px-space-md py-1.5 text-center text-[12px] font-bold flex items-center justify-center gap-2 no-print animate-in fade-in">
            <span className="material-symbols-outlined text-[16px]">check_circle</span>
            <span>{copyFeedback}</span>
          </div>
        )}

        {/* Secondary Control Bar: Period Filter + Summary - Hidden on print */}
        <div className="p-space-md bg-surface-container-low/40 border-b border-surface-container-high/40 flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm no-print">
          <div className="flex items-center gap-space-sm">
            <span className="text-[11px] font-bold text-on-surface-variant uppercase tracking-wider">
              Period:
            </span>
            <div className="flex items-center gap-1">
              {[
                { id: 'all', label: 'All Postings' },
                { id: '30days', label: 'Last 30 Days' },
                { id: 'thisMonth', label: 'This Month' },
              ].map((filter) => (
                <button
                  key={filter.id}
                  type="button"
                  onClick={() => setDateFilter(filter.id as any)}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors ${
                    dateFilter === filter.id
                      ? 'bg-surface-container-highest text-primary font-bold shadow-xs'
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-space-md">
            <div>
              <span className="text-[10px] text-on-surface-variant uppercase font-semibold block">Inflow</span>
              <span className="text-[13px] font-bold text-tertiary">+Rs. {totalInflow.toLocaleString()}</span>
            </div>
            <div>
              <span className="text-[10px] text-on-surface-variant uppercase font-semibold block">Outflow</span>
              <span className="text-[13px] font-bold text-error">-Rs. {totalOutflow.toLocaleString()}</span>
            </div>
            <div className="pl-space-sm border-l border-surface-container-high">
              <span className="text-[10px] text-on-surface-variant uppercase font-semibold block">Available</span>
              <span className="text-[15px] font-bold text-on-surface">Rs. {account.balance.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Modal Main Body */}
        <div className="flex-1 overflow-y-auto p-space-md sm:p-space-lg bg-surface-container-lowest">
          {viewMode === 'standard' ? (
            /* Standard Interactive Table View */
            <div className="rounded-xl border border-surface-container-high overflow-hidden shadow-xs">
              <table className="w-full text-left border-collapse text-body-sm">
                <thead>
                  <tr className="bg-surface-container-low text-on-surface-variant font-label-sm text-[11px] uppercase tracking-wider font-semibold">
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Doc #</th>
                    <th className="py-2.5 px-3">Type</th>
                    <th className="py-2.5 px-3">Party / Reason</th>
                    <th className="py-2.5 px-3 text-right">Inflow (+Rs)</th>
                    <th className="py-2.5 px-3 text-right">Outflow (-Rs)</th>
                    <th className="py-2.5 px-3 text-right">Balance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-surface-container-low">
                  {accountHistory.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-on-surface-variant">
                        No transactions recorded for this selected period.
                      </td>
                    </tr>
                  ) : (
                    accountHistory.map((row) => (
                      <tr key={row.id} className="hover:bg-surface-container-low/40 transition-colors">
                        <td className="py-2.5 px-3 whitespace-nowrap font-medium text-on-surface">
                          {row.date}
                        </td>
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => openPdfPreview(row.rawTx)}
                            className="inline-flex items-center gap-1.5 font-mono text-primary text-[12px] font-semibold hover:underline cursor-pointer focus:outline-none transition-all"
                            title="Click to view & download PDF"
                          >
                            <span className="material-symbols-outlined text-[15px] opacity-75">picture_as_pdf</span>
                            <span>{row.docNumber}</span>
                          </button>
                        </td>
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              row.inflow > 0
                                ? 'bg-tertiary-fixed text-on-tertiary-fixed'
                                : 'bg-error-container text-on-error-container'
                            }`}
                          >
                            {row.type}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-on-surface max-w-xs truncate">
                          {row.description}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold text-tertiary whitespace-nowrap">
                          {row.inflow > 0 ? `+Rs. ${row.inflow.toLocaleString()}` : '-'}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold text-error whitespace-nowrap">
                          {row.outflow > 0 ? `-Rs. ${row.outflow.toLocaleString()}` : '-'}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold text-on-surface whitespace-nowrap">
                          Rs. {row.runningBalance.toLocaleString()}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          ) : (
            /* Authentic Printable PDF Document View */
            <div className="max-w-3xl mx-auto bg-white p-6 sm:p-8 rounded-xl border border-gray-300 shadow-sm text-gray-800 font-sans print:border-none print:p-0">
              {/* Document Letterhead */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b-2 border-primary gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-primary text-white flex items-center justify-center font-bold text-[14px]">
                      OF
                    </div>
                    <h2 className="text-xl font-bold text-gray-900 tracking-tight">
                      {settings?.businessName || 'OILFLOW PETROLEUM & LUBRICANTS'}
                    </h2>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    {settings?.depotName || 'Depot Terminal & Warehouse Operations'} · Financial Reconciliation Ledger
                  </p>
                </div>
                <div className="text-left sm:text-right">
                  <span className="inline-block bg-primary/10 text-primary px-2.5 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider">
                    Official Ledger Statement
                  </span>
                  <p className="text-xs text-gray-500 mt-1">
                    Generated: {new Date().toLocaleString()}
                  </p>
                </div>
              </div>

              {/* Account Profile Box */}
              <div className="my-5 p-4 rounded-lg bg-gray-50 border border-gray-200 flex flex-col sm:flex-row justify-between gap-4">
                <div>
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                    Account Details
                  </span>
                  <h4 className="text-lg font-bold text-gray-900 mt-0.5">{account.name}</h4>
                  <p className="text-xs text-gray-600 mt-0.5">
                    {account.type === 'Cash'
                      ? 'Physical Cash Vault Register'
                      : `${account.bankName || 'Bank'} · A/C: ${account.accountNumber || 'Primary'}`}
                    {account.branch ? ` · Branch: ${account.branch}` : ''}
                  </p>
                </div>

                <div className="flex gap-4 sm:border-l sm:border-gray-200 sm:pl-4">
                  <div>
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                      Total Inflow
                    </span>
                    <span className="text-sm font-bold text-green-700">
                      +Rs. {totalInflow.toLocaleString()}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                      Total Outflow
                    </span>
                    <span className="text-sm font-bold text-red-700">
                      -Rs. {totalOutflow.toLocaleString()}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                      Net Liquid Balance
                    </span>
                    <span className="text-base font-bold text-gray-900">
                      Rs. {account.balance.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Printable Table */}
              <div className="overflow-x-auto my-4">
                <table className="w-full text-left text-xs border border-gray-200">
                  <thead className="bg-gray-100 text-gray-700 font-bold uppercase text-[10px]">
                    <tr>
                      <th className="p-2 border border-gray-200">Date</th>
                      <th className="p-2 border border-gray-200">Doc #</th>
                      <th className="p-2 border border-gray-200">Type</th>
                      <th className="p-2 border border-gray-200">Description / Details</th>
                      <th className="p-2 text-right border border-gray-200">Inflow (PKR)</th>
                      <th className="p-2 text-right border border-gray-200">Outflow (PKR)</th>
                      <th className="p-2 text-right border border-gray-200">Balance</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {accountHistory.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="p-4 text-center text-gray-400">
                          No transactions recorded.
                        </td>
                      </tr>
                    ) : (
                      accountHistory.map((row) => (
                        <tr key={row.id} className="odd:bg-white even:bg-gray-50/50">
                          <td className="p-2 whitespace-nowrap text-gray-800 font-medium">{row.date}</td>
                          <td className="p-2 whitespace-nowrap font-mono font-bold text-primary">{row.docNumber}</td>
                          <td className="p-2 whitespace-nowrap">
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-gray-200 text-gray-800">
                              {row.type}
                            </span>
                          </td>
                          <td className="p-2 text-gray-700">{row.description}</td>
                          <td className="p-2 text-right font-bold text-green-700 whitespace-nowrap">
                            {row.inflow > 0 ? `+${row.inflow.toLocaleString()}` : '-'}
                          </td>
                          <td className="p-2 text-right font-bold text-red-700 whitespace-nowrap">
                            {row.outflow > 0 ? `-${row.outflow.toLocaleString()}` : '-'}
                          </td>
                          <td className="p-2 text-right font-bold text-gray-900 whitespace-nowrap">
                            Rs. {row.runningBalance.toLocaleString()}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                  <tfoot className="bg-gray-100 font-bold border-t-2 border-gray-300">
                    <tr>
                      <td colSpan={4} className="p-2 text-gray-800 uppercase text-[10px]">
                        Total Summary ({accountHistory.length} Postings)
                      </td>
                      <td className="p-2 text-right text-green-700 whitespace-nowrap">
                        +Rs. {totalInflow.toLocaleString()}
                      </td>
                      <td className="p-2 text-right text-red-700 whitespace-nowrap">
                        -Rs. {totalOutflow.toLocaleString()}
                      </td>
                      <td className="p-2 text-right text-gray-900 whitespace-nowrap">
                        Rs. {account.balance.toLocaleString()}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Signatures & Certification */}
              <div className="pt-8 mt-8 border-t border-gray-200 flex justify-between items-end text-xs text-gray-500">
                <div className="text-center w-40">
                  <div className="border-b border-gray-400 pb-1 mb-1" />
                  <span>Prepared By Accountant</span>
                </div>
                <div className="text-center">
                  <span className="text-[10px] text-gray-400 block mb-1">OFFICIAL RECONCILIATION</span>
                  <span className="px-2 py-0.5 border border-dashed border-gray-300 rounded text-[10px] text-gray-400">
                    OILFLOW VERIFIED
                  </span>
                </div>
                <div className="text-center w-40">
                  <div className="border-b border-gray-400 pb-1 mb-1" />
                  <span>Authorized Stamp &amp; Signature</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer - Hidden on print */}
        <div className="p-space-md bg-surface-container-low flex items-center justify-between border-t border-surface-container-high/60 no-print">
          <div className="flex items-center gap-space-xs text-on-surface-variant font-body-sm text-body-sm">
            <span className="material-symbols-outlined text-[16px]">verified</span>
            <span>{accountHistory.length} ledger postings reconciled</span>
          </div>

          <div className="flex items-center gap-space-sm">
            <button
              type="button"
              onClick={handleDownloadPDF}
              className="px-3 h-9 text-body-sm font-semibold rounded-lg bg-surface-container text-on-surface hover:bg-surface-container-high transition-colors flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[16px]">download</span>
              <span>Download PDF</span>
            </button>
            <button
              type="button"
              onClick={closeAccountLedgerModal}
              className="px-space-md h-9 text-body-sm font-semibold rounded-lg bg-primary text-on-primary hover:bg-primary-container transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
