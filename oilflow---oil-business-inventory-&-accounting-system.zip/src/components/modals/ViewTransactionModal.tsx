import React, { useRef } from 'react';
import { useApp } from '../../context/AppContext';

export const ViewTransactionModal: React.FC = () => {
  const {
    viewingTransaction,
    closeViewTransactionModal,
    openEditTransactionModal,
    deleteTransaction,
    settings,
    downloadTransactionPdf,
    openPdfPreview,
  } = useApp();

  const printAreaRef = useRef<HTMLDivElement>(null);

  if (!viewingTransaction) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDelete = () => {
    if (
      window.confirm(
        `Are you sure you want to delete transaction ${viewingTransaction.docNumber}? This will automatically reverse all stock changes, account balances, and party ledger entries.`
      )
    ) {
      deleteTransaction(viewingTransaction.id);
      closeViewTransactionModal();
    }
  };

  const handleEdit = () => {
    const txToEdit = viewingTransaction;
    closeViewTransactionModal();
    openEditTransactionModal(txToEdit);
  };

  return (
    <div className="fixed inset-0 bg-inverse-surface/40 backdrop-blur-sm z-50 flex items-center justify-center p-space-sm sm:p-space-md animate-in fade-in duration-150">
      <div className="bg-surface-container-lowest w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border border-surface-container-high/60">
        {/* Modal Top Bar */}
        <div className="px-space-md sm:px-space-lg py-3 bg-surface-container-low flex items-center justify-between border-b border-surface-container-high/60">
          <div className="flex items-center gap-space-xs text-primary font-label-sm font-semibold uppercase tracking-wider">
            <span className="material-symbols-outlined text-[18px]">receipt_long</span>
            <span>Transaction Document</span>
          </div>
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={() => openPdfPreview(viewingTransaction)}
              type="button"
              className="px-2 py-1.5 rounded-lg bg-surface-container hover:bg-surface-container-high text-primary transition-colors flex items-center gap-1 text-[12px] font-semibold"
              title="Show PDF Preview"
            >
              <span className="material-symbols-outlined text-[17px]">visibility</span>
              <span className="hidden sm:inline">Show PDF</span>
            </button>
            <button
              onClick={() => downloadTransactionPdf(viewingTransaction)}
              type="button"
              className="px-2.5 py-1.5 rounded-lg bg-primary text-on-primary hover:bg-primary-container transition-colors flex items-center gap-1 text-[12px] font-semibold shadow-xs"
              title={
                viewingTransaction.type === 'Sale'
                  ? 'Download Sales Invoice (PDF)'
                  : viewingTransaction.type === 'Purchase'
                  ? 'Download Purchase Order (PDF)'
                  : 'Download PDF'
              }
            >
              <span className="material-symbols-outlined text-[17px]">download</span>
              <span>
                {viewingTransaction.type === 'Sale'
                  ? 'Download Invoice'
                  : viewingTransaction.type === 'Purchase'
                  ? 'Download PO'
                  : 'Download PDF'}
              </span>
            </button>
            <button
              onClick={handlePrint}
              type="button"
              className="p-1.5 rounded-lg text-on-surface-variant hover:text-primary hover:bg-surface-container transition-colors flex items-center gap-1 text-[12px] font-semibold"
              title="Print slip"
            >
              <span className="material-symbols-outlined text-[18px]">print</span>
            </button>
            <button
              onClick={handleEdit}
              type="button"
              className="p-1.5 rounded-lg text-on-surface-variant hover:text-primary hover:bg-surface-container transition-colors flex items-center gap-1 text-[12px] font-semibold"
              title="Edit transaction"
            >
              <span className="material-symbols-outlined text-[18px]">edit</span>
            </button>
            <button
              onClick={handleDelete}
              type="button"
              className="p-1.5 rounded-lg text-error hover:bg-error-container transition-colors flex items-center gap-1 text-[12px] font-semibold"
              title="Delete transaction and reverse effects"
            >
              <span className="material-symbols-outlined text-[18px]">delete</span>
            </button>
            <button
              onClick={closeViewTransactionModal}
              className="w-8 h-8 ml-1 rounded-full hover:bg-surface-container-high text-on-surface-variant flex items-center justify-center"
              type="button"
              aria-label="Close"
            >
              <span className="material-symbols-outlined text-[20px]">close</span>
            </button>
          </div>
        </div>

        {/* Printable Voucher Content */}
        <div ref={printAreaRef} className="p-space-md sm:p-space-lg overflow-y-auto space-y-space-md text-on-surface">
          {/* Company & Doc Header */}
          <div className="flex items-start justify-between border-b border-surface-container pb-space-sm">
            <div>
              <h2 className="font-headline-md text-headline-md font-bold text-on-surface">
                {settings.businessName || 'Tariq Oil Traders'}
              </h2>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                {settings.depotName || 'Lahore Main Depot'} · Wholesale Petroleum Lubricants
              </p>
              <p className="font-label-sm text-label-sm text-on-surface-variant">
                Terminal Desk Slip: <span className="font-bold text-primary">{viewingTransaction.docNumber}</span>
              </p>
            </div>
            <div className="text-right">
              <span
                className={`inline-block px-2.5 py-1 rounded-full text-[11px] font-bold ${
                  viewingTransaction.type === 'Sale'
                    ? 'bg-primary-container text-on-primary'
                    : viewingTransaction.type === 'Purchase'
                    ? 'bg-secondary-container text-primary'
                    : viewingTransaction.type === 'Receive'
                    ? 'bg-tertiary-fixed text-on-tertiary-fixed'
                    : viewingTransaction.type === 'Pay'
                    ? 'bg-error-container text-on-error-container'
                    : 'bg-surface-container text-primary'
                }`}
              >
                {viewingTransaction.type} Voucher
              </span>
              <p className="font-body-sm text-body-sm text-on-surface-variant mt-1">
                {viewingTransaction.date} · {viewingTransaction.time}
              </p>
            </div>
          </div>

          {/* Party and Account Breakdown */}
          <div className="grid grid-cols-2 gap-space-md bg-surface-container-low p-space-sm rounded-xl text-body-sm">
            <div>
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase font-semibold block">
                {viewingTransaction.expenseHeadName ? 'Expense Head:' : 'Counterparty / Client:'}
              </span>
              <span className="font-headline-sm text-headline-sm font-semibold text-on-surface block mt-0.5">
                {viewingTransaction.expenseHeadName || viewingTransaction.partyName || 'Direct / Counter Sale'}
              </span>
            </div>

            <div>
              <span className="font-label-sm text-label-sm text-on-surface-variant uppercase font-semibold block">
                Settlement Channel:
              </span>
              <span className="font-headline-sm text-headline-sm font-semibold text-on-surface block mt-0.5">
                {viewingTransaction.type === 'Transfer'
                  ? `${viewingTransaction.accountName || 'Account'} → ${viewingTransaction.toAccountName || 'Account'}`
                  : (viewingTransaction.paidAmount || 0) <= 0
                  ? 'Credit (Udhaar) - No cash/bank movement'
                  : viewingTransaction.accountName || 'Cash Vault'}
              </span>
            </div>
          </div>

          {/* Items Table if any */}
          {viewingTransaction.items && viewingTransaction.items.length > 0 ? (
            <div className="rounded-xl border border-surface-container-high overflow-hidden">
              <table className="w-full text-left text-body-sm">
                <thead>
                  <tr className="bg-surface-container-low text-[11px] uppercase tracking-wider text-on-surface-variant font-semibold">
                    <th className="py-2.5 px-3">Item Description</th>
                    <th className="py-2.5 px-3 text-center">Unit</th>
                    <th className="py-2.5 px-3 text-center">Qty</th>
                    <th className="py-2.5 px-3 text-right">Vol (L/Kg)</th>
                    <th className="py-2.5 px-3 text-right">Rate (Rs.)</th>
                    <th className="py-2.5 px-3 text-right">Subtotal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-surface-container-low">
                  {viewingTransaction.items.map((it, idx) => (
                    <tr key={it.id || idx}>
                      <td className="py-2.5 px-3 font-medium text-on-surface">{it.productName}</td>
                      <td className="py-2.5 px-3 text-center text-on-surface-variant">{it.packagingUnit}</td>
                      <td className="py-2.5 px-3 text-center font-semibold">{it.quantity}</td>
                      <td className="py-2.5 px-3 text-right text-on-surface-variant">{it.totalVolume}</td>
                      <td className="py-2.5 px-3 text-right">{it.unitPrice.toLocaleString()}</td>
                      <td className="py-2.5 px-3 text-right font-bold text-on-surface">
                        Rs. {it.subtotal.toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : null}

          {/* Totals Summary */}
          <div className="bg-surface-container-lowest p-space-sm rounded-xl space-y-1.5 border border-surface-container-high/60">
            <div className="flex justify-between text-body-sm">
              <span className="text-on-surface-variant">Document Total Amount:</span>
              <span className="font-semibold text-on-surface">
                Rs. {viewingTransaction.totalAmount.toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between text-body-sm">
              <span className="text-on-surface-variant">Amount Cleared / Settled:</span>
              <span className="font-semibold text-tertiary">
                Rs. {viewingTransaction.paidAmount.toLocaleString()}
              </span>
            </div>
            {viewingTransaction.balanceDue > 0 && (
              <div className="flex justify-between text-body-sm">
                <span className="text-error font-medium">Balance Payable / Receivable:</span>
                <span className="font-bold text-error">
                  Rs. {viewingTransaction.balanceDue.toLocaleString()}
                </span>
              </div>
            )}
            <div className="border-t border-surface-container-high pt-2 flex justify-between items-center">
              <span className="font-label-md text-label-md font-semibold text-on-surface">Payment Status:</span>
              <span
                className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                  viewingTransaction.paymentStatus === 'Paid'
                    ? 'bg-tertiary-fixed text-on-tertiary-fixed'
                    : viewingTransaction.paymentStatus === 'Partial'
                    ? 'bg-secondary-container text-on-secondary-fixed'
                    : 'bg-error-container text-on-error-container'
                }`}
              >
                {viewingTransaction.paymentStatus}
              </span>
            </div>
          </div>

          {/* Remarks */}
          {viewingTransaction.notes && (
            <div className="text-[12px] bg-surface-container-low p-space-sm rounded-lg text-on-surface-variant">
              <span className="font-semibold text-on-surface">Remarks: </span>
              {viewingTransaction.notes}
            </div>
          )}

          {/* Audit Footer */}
          <div className="border-t border-dashed border-surface-container-high pt-space-xs flex justify-between items-center text-[11px] text-on-surface-variant">
            <span>Terminal: #DESK-1 (Verified)</span>
            <span>Recorded: {new Date(viewingTransaction.createdAt).toLocaleString()}</span>
          </div>
        </div>

        {/* Modal Bottom Bar */}
        <div className="px-space-lg py-3 bg-surface-container-low flex items-center justify-between border-t border-surface-container-high/60">
          <button
            type="button"
            onClick={() => downloadTransactionPdf(viewingTransaction)}
            className="px-3 h-9 text-body-sm font-semibold rounded-lg bg-primary-container text-on-primary hover:bg-primary transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <span className="material-symbols-outlined text-[17px]">picture_as_pdf</span>
            <span>
              {viewingTransaction.type === 'Sale'
                ? 'Download Sales Invoice (PDF)'
                : viewingTransaction.type === 'Purchase'
                ? 'Download Purchase Order (PDF)'
                : 'Download PDF'}
            </span>
          </button>
          <button
            type="button"
            onClick={closeViewTransactionModal}
            className="px-space-md h-9 text-body-sm font-semibold rounded-lg bg-surface-container text-on-surface hover:bg-surface-container-high transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
