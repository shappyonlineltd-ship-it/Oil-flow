import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { ReconciliationReport } from '../../types';
import { generateReconciliationAuditPDF } from '../../utils/pdfGenerator';

export const ReconciliationModal: React.FC = () => {
  const {
    reconcileModalOpen,
    closeReconcileModal,
    getReconciliationAudit,
    reconcileAll,
    settings,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'accounts' | 'parties' | 'stock'>('accounts');
  const [report, setReport] = useState<ReconciliationReport | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Load audit report whenever modal opens
  useEffect(() => {
    if (reconcileModalOpen) {
      const currentReport = getReconciliationAudit();
      setReport(currentReport);
      setToastMessage(null);
    }
  }, [reconcileModalOpen]);

  if (!reconcileModalOpen || !report) return null;

  const handleRunReconciliation = () => {
    setIsProcessing(true);
    setTimeout(() => {
      const updatedReport = reconcileAll();
      setReport(updatedReport);
      setIsProcessing(false);
      setToastMessage('Reconciliation Completed! All Cash, Bank & Party balances are now 100% matched.');
      setTimeout(() => setToastMessage(null), 4000);
    }, 300);
  };

  const handleDownloadPDF = () => {
    if (report) {
      generateReconciliationAuditPDF(report, settings);
    }
  };

  return (
    <div className="fixed inset-0 bg-inverse-surface/40 backdrop-blur-sm z-50 flex items-center justify-center p-space-sm sm:p-space-md animate-in fade-in duration-150">
      <div className="bg-surface-container-lowest w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border border-surface-container-high/60">
        {/* Header */}
        <div className="px-space-md sm:px-space-lg py-3.5 bg-surface-container-low flex items-center justify-between border-b border-surface-container-high/60">
          <div className="flex items-center gap-space-xs text-primary font-label-sm font-semibold uppercase tracking-wider">
            <span className="material-symbols-outlined text-[20px] text-tertiary">verified_user</span>
            <span>Accounting Audit &amp; Balance Reconciliation</span>
          </div>

          <div className="flex items-center gap-space-xs">
            <button
              onClick={handleDownloadPDF}
              type="button"
              className="px-3 py-1.5 rounded-lg bg-surface-container text-on-surface hover:bg-surface-container-high transition-colors flex items-center gap-1.5 text-label-md font-semibold text-xs shadow-2xs"
            >
              <span className="material-symbols-outlined text-[16px] text-primary">picture_as_pdf</span>
              <span className="hidden sm:inline">Export Audit PDF</span>
            </button>
            <button
              onClick={closeReconcileModal}
              className="w-8 h-8 rounded-full hover:bg-surface-container-high text-on-surface-variant flex items-center justify-center"
              type="button"
              aria-label="Close"
            >
              <span className="material-symbols-outlined text-[20px]">close</span>
            </button>
          </div>
        </div>

        {/* Top Status & Integrity Banner */}
        <div className="p-space-md sm:p-space-lg border-b border-surface-container-high/60 bg-surface-container-lowest space-y-space-md">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm">
            <div>
              <h2 className="font-headline-md text-headline-md font-bold text-on-surface">
                Financial Reconciliation Desk
              </h2>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Deep audit of Cash in Hand, Bank Accounts (HBL &amp; Meezan), and Customer/Supplier balances against genuine transactions.
              </p>
            </div>

            <button
              onClick={handleRunReconciliation}
              disabled={isProcessing}
              type="button"
              className={`h-10 px-space-lg rounded-xl font-label-md font-bold text-sm flex items-center gap-2 transition-all shadow-sm ${
                isProcessing
                  ? 'bg-surface-container text-on-surface-variant cursor-wait'
                  : 'bg-primary text-on-primary hover:bg-primary-container active:scale-98'
              }`}
            >
              <span className={`material-symbols-outlined text-[19px] ${isProcessing ? 'animate-spin' : ''}`}>
                {isProcessing ? 'refresh' : 'sync'}
              </span>
              <span>{isProcessing ? 'Auditing & Syncing...' : 'One-Click Auto Reconcile'}</span>
            </button>
          </div>

          {/* Feedback Alert Toast */}
          {toastMessage && (
            <div className="p-space-sm rounded-xl bg-tertiary-fixed text-on-tertiary-fixed text-body-sm font-semibold flex items-center gap-2 animate-in fade-in shadow-xs">
              <span className="material-symbols-outlined text-[18px]">check_circle</span>
              <span>{toastMessage}</span>
            </div>
          )}

          {/* Status Diagnostic Strip */}
          <div
            className={`p-space-sm sm:p-space-md rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm ${
              report.hasDiscrepancies
                ? 'bg-error-container/20 border-error/30 text-error'
                : 'bg-tertiary-container/15 border-tertiary/30 text-tertiary'
            }`}
          >
            <div className="flex items-center gap-space-sm">
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
                  report.hasDiscrepancies ? 'bg-error text-on-error' : 'bg-tertiary text-on-tertiary'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">
                  {report.hasDiscrepancies ? 'warning' : 'check'}
                </span>
              </div>
              <div>
                <p className="font-headline-sm font-bold text-on-surface text-sm">
                  {report.hasDiscrepancies
                    ? `${report.totalDiscrepanciesCount} Discrepanc${report.totalDiscrepanciesCount === 1 ? 'y' : 'ies'} Detected in Records`
                    : 'All Ledgers & Accounts are 100% Balanced'}
                </p>
                <p className="text-xs text-on-surface-variant mt-0.5">
                  {report.hasDiscrepancies
                    ? 'Some accounts or party balances differ from calculated transaction vouchers. Click "One-Click Auto Reconcile" to auto-align.'
                    : 'Zero discrepancy found between recorded balances and transaction vouchers. Bank accounts are insulated from unlinked credit invoices.'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-space-md text-xs font-semibold shrink-0">
              <span className="px-2.5 py-1 rounded-md bg-surface-container-low text-on-surface">
                Audited: {report.timestamp}
              </span>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex items-center gap-space-xs border-b border-surface-container-high/60 pt-1">
            <button
              onClick={() => setActiveTab('accounts')}
              type="button"
              className={`pb-2.5 px-space-md font-label-md text-sm font-semibold border-b-2 transition-all flex items-center gap-1.5 ${
                activeTab === 'accounts'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-on-surface-variant hover:text-on-surface'
              }`}
            >
              <span className="material-symbols-outlined text-[17px]">account_balance</span>
              <span>Cash &amp; Bank Accounts ({report.accounts.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('parties')}
              type="button"
              className={`pb-2.5 px-space-md font-label-md text-sm font-semibold border-b-2 transition-all flex items-center gap-1.5 ${
                activeTab === 'parties'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-on-surface-variant hover:text-on-surface'
              }`}
            >
              <span className="material-symbols-outlined text-[17px]">group</span>
              <span>Parties / Clients ({report.parties.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('stock')}
              type="button"
              className={`pb-2.5 px-space-md font-label-md text-sm font-semibold border-b-2 transition-all flex items-center gap-1.5 ${
                activeTab === 'stock'
                  ? 'border-primary text-primary'
                  : 'border-transparent text-on-surface-variant hover:text-on-surface'
              }`}
            >
              <span className="material-symbols-outlined text-[17px]">inventory_2</span>
              <span>Stock Verification ({report.stock.length})</span>
            </button>
          </div>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-space-md sm:p-space-lg space-y-space-md">
          {activeTab === 'accounts' && (
            <div className="space-y-space-md">
              <div className="flex items-center justify-between text-xs text-on-surface-variant font-medium">
                <span>
                  Showing all active Cash Vaults and Bank Accounts. Balances reconcile from Opening Balance + Cash/Bank Receipts - Cash/Bank Payments.
                </span>
              </div>

              <div className="rounded-xl border border-surface-container-high overflow-hidden shadow-2xs">
                <table className="w-full text-left text-body-sm">
                  <thead>
                    <tr className="bg-surface-container-low text-[11px] uppercase tracking-wider text-on-surface-variant font-semibold">
                      <th className="py-2.5 px-3">Account Title</th>
                      <th className="py-2.5 px-3 text-right">Opening</th>
                      <th className="py-2.5 px-3 text-right text-tertiary">Total In (+)</th>
                      <th className="py-2.5 px-3 text-right text-error">Total Out (-)</th>
                      <th className="py-2.5 px-3 text-right">Calculated</th>
                      <th className="py-2.5 px-3 text-right">Recorded</th>
                      <th className="py-2.5 px-3 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-surface-container-low">
                    {report.accounts.map((acc) => {
                      const isBalanced = acc.status === 'balanced';
                      return (
                        <tr key={acc.id} className="hover:bg-surface-container-low/50 transition-colors">
                          <td className="py-2.5 px-3">
                            <div className="flex items-center gap-2">
                              <span
                                className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                                  acc.type === 'Cash'
                                    ? 'bg-amber-100 text-amber-800'
                                    : 'bg-blue-100 text-blue-800'
                                }`}
                              >
                                <span className="material-symbols-outlined text-[16px]">
                                  {acc.type === 'Cash' ? 'payments' : 'account_balance'}
                                </span>
                              </span>
                              <div>
                                <span className="font-semibold text-on-surface block leading-snug">
                                  {acc.name}
                                </span>
                                <span className="text-[10px] text-on-surface-variant">
                                  {acc.type === 'Bank' ? acc.bankName || 'Bank' : 'Physical Cash Safe'} · {acc.transactionCount} vouchers
                                </span>
                              </div>
                            </div>
                          </td>

                          <td className="py-2.5 px-3 text-right text-on-surface-variant">
                            Rs. {acc.openingBalance.toLocaleString()}
                          </td>

                          <td className="py-2.5 px-3 text-right font-medium text-tertiary">
                            +Rs. {acc.totalInflow.toLocaleString()}
                          </td>

                          <td className="py-2.5 px-3 text-right font-medium text-error">
                            -Rs. {acc.totalOutflow.toLocaleString()}
                          </td>

                          <td className="py-2.5 px-3 text-right font-bold text-on-surface">
                            Rs. {acc.calculatedBalance.toLocaleString()}
                          </td>

                          <td className="py-2.5 px-3 text-right font-semibold text-on-surface">
                            Rs. {acc.recordedBalance.toLocaleString()}
                          </td>

                          <td className="py-2.5 px-3 text-center whitespace-nowrap">
                            {isBalanced ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-tertiary-container/15 text-tertiary">
                                <span className="material-symbols-outlined text-[13px]">check_circle</span>
                                Balanced
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-error-container text-on-error-container">
                                <span className="material-symbols-outlined text-[13px]">error</span>
                                Diff: Rs. {acc.difference.toLocaleString()}
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'parties' && (
            <div className="space-y-space-md">
              <div className="flex items-center justify-between text-xs text-on-surface-variant font-medium">
                <span>
                  Party ledger reconciliation: Positive = Client owes you (Receivable), Negative = You owe supplier (Payable).
                </span>
              </div>

              <div className="rounded-xl border border-surface-container-high overflow-hidden shadow-2xs">
                <table className="w-full text-left text-body-sm">
                  <thead>
                    <tr className="bg-surface-container-low text-[11px] uppercase tracking-wider text-on-surface-variant font-semibold">
                      <th className="py-2.5 px-3">Party Name</th>
                      <th className="py-2.5 px-3 text-center">Type</th>
                      <th className="py-2.5 px-3 text-right">Invoiced / Billed</th>
                      <th className="py-2.5 px-3 text-right">Settled / Paid</th>
                      <th className="py-2.5 px-3 text-right">Calculated Balance</th>
                      <th className="py-2.5 px-3 text-right">Recorded Balance</th>
                      <th className="py-2.5 px-3 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-surface-container-low">
                    {report.parties.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-6 text-center text-on-surface-variant text-sm">
                          No parties created yet.
                        </td>
                      </tr>
                    ) : (
                      report.parties.map((pty) => {
                        const isBalanced = pty.status === 'balanced';
                        return (
                          <tr key={pty.id} className="hover:bg-surface-container-low/50 transition-colors">
                            <td className="py-2.5 px-3 font-semibold text-on-surface">
                              {pty.name}
                            </td>

                            <td className="py-2.5 px-3 text-center">
                              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-surface-container text-on-surface-variant">
                                {pty.type}
                              </span>
                            </td>

                            <td className="py-2.5 px-3 text-right text-on-surface">
                              Rs. {pty.totalInvoiced.toLocaleString()}
                            </td>

                            <td className="py-2.5 px-3 text-right text-on-surface-variant">
                              Rs. {pty.totalSettled.toLocaleString()}
                            </td>

                            <td className="py-2.5 px-3 text-right font-bold text-on-surface">
                              Rs. {pty.calculatedBalance.toLocaleString()}
                            </td>

                            <td className="py-2.5 px-3 text-right font-semibold text-on-surface">
                              Rs. {pty.recordedBalance.toLocaleString()}
                            </td>

                            <td className="py-2.5 px-3 text-center whitespace-nowrap">
                              {isBalanced ? (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-tertiary-container/15 text-tertiary">
                                  <span className="material-symbols-outlined text-[13px]">check_circle</span>
                                  Balanced
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-error-container text-on-error-container">
                                  <span className="material-symbols-outlined text-[13px]">error</span>
                                  Diff: Rs. {pty.difference.toLocaleString()}
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'stock' && (
            <div className="space-y-space-md">
              <div className="flex items-center justify-between text-xs text-on-surface-variant font-medium">
                <span>
                  Physical inventory verification against total purchases and sales.
                </span>
              </div>

              <div className="rounded-xl border border-surface-container-high overflow-hidden shadow-2xs">
                <table className="w-full text-left text-body-sm">
                  <thead>
                    <tr className="bg-surface-container-low text-[11px] uppercase tracking-wider text-on-surface-variant font-semibold">
                      <th className="py-2.5 px-3">Product Name</th>
                      <th className="py-2.5 px-3">Grade</th>
                      <th className="py-2.5 px-3 text-right">Purchased Qty</th>
                      <th className="py-2.5 px-3 text-right">Sold Qty</th>
                      <th className="py-2.5 px-3 text-right">Current Stock</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-surface-container-low">
                    {report.stock.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="py-6 text-center text-on-surface-variant text-sm">
                          No products in inventory yet.
                        </td>
                      </tr>
                    ) : (
                      report.stock.map((stk) => (
                        <tr key={stk.id} className="hover:bg-surface-container-low/50 transition-colors">
                          <td className="py-2.5 px-3 font-semibold text-on-surface">
                            {stk.name}
                          </td>
                          <td className="py-2.5 px-3 text-on-surface-variant text-xs">
                            {stk.grade || '-'}
                          </td>
                          <td className="py-2.5 px-3 text-right text-tertiary font-medium">
                            +{stk.totalPurchased} {stk.unit}
                          </td>
                          <td className="py-2.5 px-3 text-right text-error font-medium">
                            -{stk.totalSold} {stk.unit}
                          </td>
                          <td className="py-2.5 px-3 text-right font-bold text-on-surface">
                            {stk.recordedStock} {stk.unit}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-space-md sm:px-space-lg py-3 bg-surface-container-low border-t border-surface-container-high/60 flex items-center justify-between">
          <div className="text-xs text-on-surface-variant flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[16px] text-tertiary">lock</span>
            <span>All reconciliation actions enforce double-entry audit standards.</span>
          </div>

          <div className="flex items-center gap-space-sm">
            <button
              onClick={closeReconcileModal}
              type="button"
              className="px-space-md py-1.5 rounded-lg border border-surface-container-high text-on-surface hover:bg-surface-container transition-colors text-label-md font-semibold text-xs"
            >
              Close
            </button>
            <button
              onClick={handleRunReconciliation}
              type="button"
              className="px-space-md py-1.5 rounded-lg bg-primary text-on-primary hover:bg-primary-container transition-colors text-label-md font-semibold text-xs shadow-2xs"
            >
              Re-Audit &amp; Align All
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
