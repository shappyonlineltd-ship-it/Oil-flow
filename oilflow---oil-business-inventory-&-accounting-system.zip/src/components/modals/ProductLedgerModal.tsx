import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductLedgerRow } from '../../types';
import {
  generateProductLedgerPDF,
  shareOnWhatsApp,
  copyTextToClipboard,
} from '../../utils/pdfGenerator';

export const ProductLedgerModal: React.FC = () => {
  const {
    viewingProductLedgerId,
    closeProductLedgerModal,
    products,
    transactions,
    openTransactionModal,
    openViewTransactionModal,
    openPdfPreview,
    settings,
  } = useApp();

  const [dateFilter, setDateFilter] = useState<'all' | '30days' | 'thisMonth'>('all');
  const [typeFilter, setTypeFilter] = useState<'all' | 'Purchase' | 'Sale'>('all');
  const [searchFilter, setSearchFilter] = useState('');
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);

  const product = useMemo(() => {
    return products.find((p) => p.id === viewingProductLedgerId);
  }, [products, viewingProductLedgerId]);

  // Compute product ledger entries & running stock balances chronologically
  const allProductHistory = useMemo(() => {
    if (!product) return [];

    // Filter transactions involving this product
    const relevantTx = transactions
      .filter((t) =>
        t.items?.some(
          (item) =>
            item.productId === product.id ||
            (!item.productId &&
              item.productName?.trim().toLowerCase() === product.name.trim().toLowerCase())
        )
      )
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    // Calculate sum of inward and outward from transactions
    let totalPurchased = 0;
    let totalSold = 0;

    relevantTx.forEach((tx) => {
      const matched = tx.items.find(
        (i) =>
          i.productId === product.id ||
          (!i.productId && i.productName?.trim().toLowerCase() === product.name.trim().toLowerCase())
      );
      if (matched) {
        if (tx.type === 'Purchase') totalPurchased += matched.quantity;
        if (tx.type === 'Sale') totalSold += matched.quantity;
      }
    });

    // Opening stock or adjustment delta so that final balance exactly matches currentStock
    const openingStock = product.currentStock - (totalPurchased - totalSold);
    let runningStock = openingStock > 0 ? openingStock : 0;
    let runningVol = runningStock * product.packingSize;

    const rows: ProductLedgerRow[] = [];

    // If opening stock exists, add an opening balance row
    if (openingStock > 0) {
      rows.push({
        id: `open-${product.id}`,
        docNumber: 'OPN-STOCK',
        date: product.createdAt || new Date().toISOString().slice(0, 10),
        time: '08:00 AM',
        type: 'Opening Stock',
        partyName: 'Depot Initial Inventory',
        rate: product.purchaseCost,
        qtyIn: openingStock,
        qtyOut: 0,
        volumeIn: openingStock * product.packingSize,
        volumeOut: 0,
        runningBalance: runningStock,
        runningVolume: runningVol,
        totalValue: openingStock * product.purchaseCost,
        notes: 'Initial depot opening inventory balance',
      });
    }

    relevantTx.forEach((tx) => {
      const item = tx.items.find(
        (i) =>
          i.productId === product.id ||
          (!i.productId && i.productName?.trim().toLowerCase() === product.name.trim().toLowerCase())
      );
      if (!item) return;

      const isPurchase = tx.type === 'Purchase';
      const isSale = tx.type === 'Sale';

      const inQty = isPurchase ? item.quantity : 0;
      const outQty = isSale ? item.quantity : 0;
      const inVol = isPurchase ? item.totalVolume : 0;
      const outVol = isSale ? item.totalVolume : 0;

      if (isPurchase) {
        runningStock += inQty;
        runningVol += inVol;
      } else if (isSale) {
        runningStock = Math.max(0, runningStock - outQty);
        runningVol = Math.max(0, runningVol - outVol);
      }

      rows.push({
        id: `${tx.id}-${item.id || item.productId}`,
        transactionId: tx.id,
        docNumber: tx.docNumber,
        date: tx.date,
        time: tx.time,
        type: tx.type,
        partyName: tx.partyName || (isPurchase ? 'Supplier' : 'Customer'),
        partyId: tx.partyId,
        rate: item.unitPrice,
        qtyIn: inQty,
        qtyOut: outQty,
        volumeIn: inVol,
        volumeOut: outVol,
        runningBalance: runningStock,
        runningVolume: runningVol,
        totalValue: item.subtotal || item.quantity * item.unitPrice,
        notes: tx.notes || `${tx.type} Invoice`,
        rawTx: tx,
      });
    });

    return rows;
  }, [product, transactions]);

  // Filtered rows by date, movement type, and search keyword
  const filteredHistory = useMemo(() => {
    return allProductHistory.filter((item) => {
      // Date filter
      if (dateFilter !== 'all') {
        const now = new Date();
        const itemDate = new Date(item.date);
        if (dateFilter === '30days') {
          const diffDays = (now.getTime() - itemDate.getTime()) / (1000 * 3600 * 24);
          if (diffDays > 30) return false;
        }
        if (dateFilter === 'thisMonth') {
          if (
            itemDate.getMonth() !== now.getMonth() ||
            itemDate.getFullYear() !== now.getFullYear()
          ) {
            return false;
          }
        }
      }

      // Movement type filter
      if (typeFilter !== 'all' && item.type !== typeFilter) {
        return false;
      }

      // Search keyword filter
      if (searchFilter.trim()) {
        const q = searchFilter.toLowerCase();
        const matchDoc = item.docNumber.toLowerCase().includes(q);
        const matchParty = item.partyName.toLowerCase().includes(q);
        const matchNotes = item.notes?.toLowerCase().includes(q);
        if (!matchDoc && !matchParty && !matchNotes) return false;
      }

      return true;
    });
  }, [allProductHistory, dateFilter, typeFilter, searchFilter]);

  if (!product || !viewingProductLedgerId) return null;

  const totalInwardQty = filteredHistory.reduce((s, r) => s + r.qtyIn, 0);
  const totalOutwardQty = filteredHistory.reduce((s, r) => s + r.qtyOut, 0);
  const totalInwardVol = filteredHistory.reduce((s, r) => s + r.volumeIn, 0);
  const totalOutwardVol = filteredHistory.reduce((s, r) => s + r.volumeOut, 0);
  const totalMovementValue = filteredHistory.reduce((s, r) => s + r.totalValue, 0);

  const stockValuationCost = product.currentStock * product.purchaseCost;
  const stockValuationSale = product.currentStock * product.salePrice;
  const isLowStock = product.currentStock > 0 && product.currentStock <= product.minAlertThreshold;
  const isOutOfStock = product.currentStock === 0;

  // PDF Export
  const handleDownloadPDF = () => {
    generateProductLedgerPDF(product, filteredHistory, settings);
  };

  // CSV Export
  const handleExportCSV = () => {
    const headers = [
      'Date',
      'Time',
      'Doc Number',
      'Movement Type',
      'Party / Description',
      'Rate (PKR)',
      `Quantity In (${product.unit})`,
      `Quantity Out (${product.unit})`,
      `Volume In (${product.packingUnit})`,
      `Volume Out (${product.packingUnit})`,
      `Closing Stock (${product.unit})`,
      'Total Amount (PKR)',
      'Remarks',
    ];

    const rows = filteredHistory.map((r) => [
      r.date,
      r.time || '',
      r.docNumber,
      r.type,
      `"${r.partyName.replace(/"/g, '""')}"`,
      r.rate,
      r.qtyIn,
      r.qtyOut,
      r.volumeIn,
      r.volumeOut,
      r.runningBalance,
      r.totalValue,
      `"${(r.notes || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `Stock_Ledger_${product.name.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // WhatsApp Share
  const handleWhatsAppShare = () => {
    const text =
      `*OILFLOW PETROLEUM - PRODUCT STOCK LEDGER*\n` +
      `--------------------------------\n` +
      `Product: ${product.name} (${product.grade})\n` +
      `Category: ${product.category}\n` +
      `Packaging: ${product.packingSize} ${product.packingUnit} ${product.unit}\n` +
      `Date: ${new Date().toLocaleDateString()}\n` +
      `Current Stock: ${product.currentStock} ${product.unit}s (${product.currentStock * product.packingSize} ${product.packingUnit}s)\n` +
      `Stock Value: Rs. ${stockValuationCost.toLocaleString()}\n` +
      `Total Inward (+): ${totalInwardQty} ${product.unit}s\n` +
      `Total Outward (-): ${totalOutwardQty} ${product.unit}s\n` +
      `Recorded Entries: ${filteredHistory.length}\n` +
      `--------------------------------\n` +
      `Generated from ${settings.businessName || 'OilFlow ERP'}`;
    shareOnWhatsApp(text);
  };

  // Copy Summary text
  const handleCopySummary = async () => {
    const text =
      `OilFlow Stock Ledger for ${product.name} (${product.grade})\n` +
      `Current Stock: ${product.currentStock} ${product.unit}s (${(product.currentStock * product.packingSize).toLocaleString()} ${product.packingUnit}s)\n` +
      `Valuation: Rs. ${stockValuationCost.toLocaleString()}\n` +
      `Total Inward: ${totalInwardQty} ${product.unit}s | Total Outward: ${totalOutwardQty} ${product.unit}s\n` +
      `Purchase Cost: Rs. ${product.purchaseCost.toLocaleString()} | Sale Price: Rs. ${product.salePrice.toLocaleString()}`;

    await copyTextToClipboard(text);
    setCopyFeedback('Summary copied to clipboard!');
    setTimeout(() => setCopyFeedback(null), 2500);
  };

  return (
    <div className="flex flex-col w-full pb-space-xl animate-in fade-in duration-150">
      {/* Top In-Page Back Navigation */}
      <div className="flex items-center justify-between gap-space-sm mb-space-md no-print">
        <div className="flex items-center gap-space-sm">
          <button
            type="button"
            onClick={closeProductLedgerModal}
            className="h-10 px-space-md bg-surface-container-low hover:bg-surface-container text-on-surface rounded-lg flex items-center gap-space-xs font-label-md text-label-md font-semibold transition-colors shadow-xs active:scale-98"
          >
            <span className="material-symbols-outlined text-[20px]">arrow_back</span>
            <span>Back to Inventory</span>
          </button>
          <div className="hidden sm:flex items-center gap-space-xs text-on-surface-variant font-label-sm uppercase tracking-wider">
            <span>Warehouse Operations</span>
            <span className="material-symbols-outlined text-[14px]">chevron_right</span>
            <span>Inventory &amp; Oil Stocks</span>
            <span className="material-symbols-outlined text-[14px]">chevron_right</span>
            <span className="text-primary font-semibold">{product.name} Stock Ledger</span>
          </div>
        </div>
      </div>

      <div className="bg-surface-container-lowest w-full rounded-2xl shadow-sm flex flex-col overflow-hidden border border-surface-container-high/60 print-page">
        {/* Top Header Bar */}
        <div className="p-4 sm:p-5 bg-surface-container-low flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-surface-container-high/60 no-print">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0 border border-primary/20">
              <span className="material-symbols-outlined text-[24px]">
                {product.unit === 'Drum' ? 'oil_barrel' : product.unit === 'Kg' ? 'layers' : 'inventory_2'}
              </span>
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-headline-sm text-headline-sm text-on-surface font-bold truncate">
                  {product.name}
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-surface-container-high text-on-surface-variant text-[11px] font-semibold">
                  {product.grade}
                </span>
                <span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-[11px] font-semibold">
                  {product.category}
                </span>
              </div>
              <p className="font-body-sm text-body-sm text-on-surface-variant mt-0.5">
                Product Stock Ledger Statement &middot; Pack: {product.packingSize} {product.packingUnit} {product.unit}
                {product.tankLocation ? ` &middot; Location: ${product.tankLocation}` : ''}
              </p>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="flex items-center gap-2 flex-wrap self-end sm:self-auto">
            <button
              type="button"
              onClick={() => {
                closeProductLedgerModal();
                openTransactionModal('Purchase', product.name);
              }}
              className="h-9 px-3 rounded-lg bg-surface-container hover:bg-surface-container-high text-on-surface font-label-sm text-label-sm font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
              title="Add Purchase for this product"
            >
              <span className="material-symbols-outlined text-[16px] text-tertiary">add_shopping_cart</span>
              <span>+ Purchase</span>
            </button>

            <button
              type="button"
              onClick={() => {
                closeProductLedgerModal();
                openTransactionModal('Sale', product.name);
              }}
              className="h-9 px-3 rounded-lg bg-surface-container hover:bg-surface-container-high text-on-surface font-label-sm text-label-sm font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
              title="Add Sale for this product"
            >
              <span className="material-symbols-outlined text-[16px] text-primary">point_of_sale</span>
              <span>+ Sale</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadPDF}
              className="h-9 px-3 rounded-lg bg-primary text-on-primary hover:bg-primary-container font-label-sm text-label-sm font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
              title="Download Stock Ledger PDF Statement"
            >
              <span className="material-symbols-outlined text-[16px]">picture_as_pdf</span>
              <span>PDF Report</span>
            </button>

            <button
              type="button"
              onClick={handleExportCSV}
              className="h-9 w-9 rounded-lg bg-surface-container hover:bg-surface-container-high text-on-surface-variant hover:text-on-surface flex items-center justify-center transition-colors"
              title="Export as CSV"
            >
              <span className="material-symbols-outlined text-[18px]">file_download</span>
            </button>

            <button
              type="button"
              onClick={handleWhatsAppShare}
              className="h-9 w-9 rounded-lg bg-surface-container hover:bg-surface-container-high text-tertiary flex items-center justify-center transition-colors"
              title="Share on WhatsApp"
            >
              <span className="material-symbols-outlined text-[18px]">share</span>
            </button>

            <button
              type="button"
              onClick={closeProductLedgerModal}
              className="h-9 w-9 rounded-lg bg-surface-container hover:bg-error-container hover:text-on-error-container text-on-surface-variant flex items-center justify-center transition-colors ml-1"
              title="Close"
            >
              <span className="material-symbols-outlined text-[20px]">close</span>
            </button>
          </div>
        </div>

        {/* Copy Feedback Toast */}
        {copyFeedback && (
          <div className="bg-tertiary-fixed text-on-tertiary-fixed text-center py-1.5 px-4 text-xs font-semibold">
            {copyFeedback}
          </div>
        )}

        {/* Body Container (Scrollable) */}
        <div className="overflow-y-auto flex-1 p-4 sm:p-5 space-y-4">
          
          {/* Key KPI Summary Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {/* KPI 1: Current Stock */}
            <div className="p-3.5 rounded-xl bg-surface-container-low border border-surface-container-high/60 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-1">
                <span className="font-label-sm text-label-sm text-on-surface-variant">Current Stock</span>
                <span
                  className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                    isOutOfStock
                      ? 'bg-surface-container-high text-on-surface-variant'
                      : isLowStock
                      ? 'bg-error-container text-on-error-container'
                      : 'bg-tertiary-fixed text-on-tertiary-fixed'
                  }`}
                >
                  {isOutOfStock ? 'Out of Stock' : isLowStock ? 'Low Stock' : 'In Stock'}
                </span>
              </div>
              <div>
                <div className="flex items-baseline gap-1.5">
                  <span className="font-headline-md text-headline-md font-bold text-on-surface">
                    {product.currentStock}
                  </span>
                  <span className="font-label-md text-label-md text-on-surface-variant">
                    {product.unit}s
                  </span>
                </div>
                <div className="text-[12px] text-on-surface-variant font-medium mt-0.5">
                  {(product.currentStock * product.packingSize).toLocaleString()} {product.packingUnit}s on hand
                </div>
              </div>
            </div>

            {/* KPI 2: Total Inward / Purchased */}
            <div className="p-3.5 rounded-xl bg-surface-container-low border border-surface-container-high/60 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-1">
                <span className="font-label-sm text-label-sm text-on-surface-variant">Total Inward</span>
                <span className="material-symbols-outlined text-tertiary text-[18px]">south_west</span>
              </div>
              <div>
                <div className="flex items-baseline gap-1.5">
                  <span className="font-headline-md text-headline-md font-bold text-tertiary">
                    +{totalInwardQty}
                  </span>
                  <span className="font-label-md text-label-md text-on-surface-variant">
                    {product.unit}s
                  </span>
                </div>
                <div className="text-[12px] text-on-surface-variant font-medium mt-0.5">
                  +{totalInwardVol.toLocaleString()} {product.packingUnit}s received
                </div>
              </div>
            </div>

            {/* KPI 3: Total Outward / Sold */}
            <div className="p-3.5 rounded-xl bg-surface-container-low border border-surface-container-high/60 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-1">
                <span className="font-label-sm text-label-sm text-on-surface-variant">Total Outward</span>
                <span className="material-symbols-outlined text-primary text-[18px]">north_east</span>
              </div>
              <div>
                <div className="flex items-baseline gap-1.5">
                  <span className="font-headline-md text-headline-md font-bold text-primary">
                    -{totalOutwardQty}
                  </span>
                  <span className="font-label-md text-label-md text-on-surface-variant">
                    {product.unit}s
                  </span>
                </div>
                <div className="text-[12px] text-on-surface-variant font-medium mt-0.5">
                  -{totalOutwardVol.toLocaleString()} {product.packingUnit}s dispatched
                </div>
              </div>
            </div>

            {/* KPI 4: Stock Valuation */}
            <div className="p-3.5 rounded-xl bg-surface-container-low border border-surface-container-high/60 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-1">
                <span className="font-label-sm text-label-sm text-on-surface-variant">Stock Valuation</span>
                <span className="material-symbols-outlined text-on-surface-variant text-[18px]">payments</span>
              </div>
              <div>
                <div className="flex items-baseline gap-1">
                  <span className="font-headline-md text-headline-md font-bold text-on-surface">
                    Rs. {stockValuationCost.toLocaleString()}
                  </span>
                </div>
                <div className="text-[11px] text-on-surface-variant font-medium mt-0.5 flex items-center justify-between">
                  <span>Cost: Rs. {product.purchaseCost.toLocaleString()}</span>
                  <span>Sale: Rs. {product.salePrice.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Filtration & Search Bar */}
          <div className="p-3 rounded-xl bg-surface-container-low border border-surface-container-high/60 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            {/* Search Input */}
            <div className="relative flex-1">
              <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-[18px]">
                search
              </span>
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder="Search by doc number, party, or remarks..."
                className="w-full h-9 pl-9 pr-3 bg-surface-container-lowest rounded-lg text-body-sm text-on-surface placeholder:text-on-surface-variant focus:outline-none focus:ring-1 focus:ring-primary border border-surface-container-high/40"
              />
            </div>

            {/* Date Segment */}
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[11px] uppercase font-bold text-on-surface-variant tracking-wider mr-1">
                Period:
              </span>
              {(['all', '30days', 'thisMonth'] as const).map((period) => (
                <button
                  key={period}
                  type="button"
                  onClick={() => setDateFilter(period)}
                  className={`px-2.5 py-1 rounded-md text-xs font-semibold transition-colors ${
                    dateFilter === period
                      ? 'bg-primary text-on-primary shadow-xs'
                      : 'bg-surface-container-lowest text-on-surface-variant hover:text-on-surface border border-surface-container-high/40'
                  }`}
                >
                  {period === 'all' ? 'All Time' : period === '30days' ? 'Last 30 Days' : 'This Month'}
                </button>
              ))}
            </div>

            {/* Movement Type Segment */}
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[11px] uppercase font-bold text-on-surface-variant tracking-wider mr-1">
                Type:
              </span>
              {(['all', 'Purchase', 'Sale'] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTypeFilter(t)}
                  className={`px-2.5 py-1 rounded-md text-xs font-semibold transition-colors ${
                    typeFilter === t
                      ? 'bg-primary text-on-primary shadow-xs'
                      : 'bg-surface-container-lowest text-on-surface-variant hover:text-on-surface border border-surface-container-high/40'
                  }`}
                >
                  {t === 'all' ? 'All' : t === 'Purchase' ? 'Purchases (In)' : 'Sales (Out)'}
                </button>
              ))}
            </div>

            {/* Quick Copy summary button */}
            <button
              type="button"
              onClick={handleCopySummary}
              className="h-9 px-2.5 rounded-lg bg-surface-container-lowest hover:bg-surface-container text-on-surface-variant hover:text-on-surface text-xs font-medium flex items-center gap-1 border border-surface-container-high/40 transition-colors"
              title="Copy text summary"
            >
              <span className="material-symbols-outlined text-[16px]">content_copy</span>
              <span>Copy</span>
            </button>
          </div>

          {/* Ledger Table */}
          <div className="rounded-xl border border-surface-container-high/60 overflow-hidden bg-surface-container-lowest shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-surface-container-low h-10 text-on-surface-variant font-label-sm text-[11px] uppercase tracking-wider border-b border-surface-container-high/60">
                    <th className="px-3 py-2 font-semibold">Date &amp; Time</th>
                    <th className="px-3 py-2 font-semibold">Doc #</th>
                    <th className="px-3 py-2 font-semibold">Movement</th>
                    <th className="px-3 py-2 font-semibold">Party / Counterparty</th>
                    <th className="px-3 py-2 font-semibold text-right">Rate / Unit</th>
                    <th className="px-3 py-2 font-semibold text-right">Inward (+)</th>
                    <th className="px-3 py-2 font-semibold text-right">Outward (-)</th>
                    <th className="px-3 py-2 font-semibold text-right">Stock Balance</th>
                    <th className="px-3 py-2 font-semibold text-right">Total (PKR)</th>
                    <th className="px-3 py-2 font-semibold">Remarks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-surface-container-low text-body-sm">
                  {filteredHistory.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="py-12 text-center text-on-surface-variant">
                        <div className="flex flex-col items-center justify-center gap-2">
                          <span className="material-symbols-outlined text-[36px] text-on-surface-variant/40">
                            history_toggle_off
                          </span>
                          <p className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                            No ledger movements found
                          </p>
                          <p className="font-body-sm text-body-sm text-on-surface-variant max-w-sm">
                            {allProductHistory.length === 0
                              ? `No purchase or sale transactions recorded yet for ${product.name}. Current stock is ${product.currentStock} ${product.unit}s.`
                              : 'No transactions match your active search or date filter criteria.'}
                          </p>
                          <div className="flex items-center gap-2 mt-2">
                            <button
                              type="button"
                              onClick={() => {
                                closeProductLedgerModal();
                                openTransactionModal('Purchase', product.name);
                              }}
                              className="px-3 py-1.5 rounded-lg bg-primary text-on-primary text-xs font-semibold"
                            >
                              + New Purchase
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                closeProductLedgerModal();
                                openTransactionModal('Sale', product.name);
                              }}
                              className="px-3 py-1.5 rounded-lg bg-surface-container text-on-surface text-xs font-semibold hover:bg-surface-container-high"
                            >
                              + New Sale
                            </button>
                          </div>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    filteredHistory.map((row) => {
                      const isPurchase = row.type === 'Purchase';
                      const isSale = row.type === 'Sale';
                      const isOpening = row.type === 'Opening Stock';

                      return (
                        <tr
                          key={row.id}
                          className="hover:bg-surface-container-low/50 transition-colors h-13"
                        >
                          {/* Date & Time */}
                          <td className="px-3 py-2 whitespace-nowrap">
                            <div className="flex flex-col">
                              <span className="font-semibold text-on-surface text-xs">{row.date}</span>
                              <span className="text-[11px] text-on-surface-variant">{row.time || '10:00 AM'}</span>
                            </div>
                          </td>

                          {/* Voucher / Doc # */}
                          <td className="px-3 py-2 whitespace-nowrap">
                            {row.rawTx ? (
                              <button
                                type="button"
                                onClick={() => openPdfPreview(row.rawTx!)}
                                className="font-mono text-xs font-bold text-primary hover:underline inline-flex items-center gap-1 group cursor-pointer focus:outline-none"
                                title="Click to view & download PDF"
                              >
                                <span className="material-symbols-outlined text-[14px] opacity-75">picture_as_pdf</span>
                                <span>{row.docNumber}</span>
                              </button>
                            ) : (
                              <span className="font-mono text-xs font-semibold text-on-surface-variant">
                                {row.docNumber}
                              </span>
                            )}
                          </td>

                          {/* Movement Type */}
                          <td className="px-3 py-2 whitespace-nowrap">
                            {isPurchase ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-tertiary-fixed text-on-tertiary-fixed">
                                <span className="w-1.5 h-1.5 rounded-full bg-tertiary" />
                                Stock In (Purchase)
                              </span>
                            ) : isSale ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-primary-container text-on-primary-container">
                                <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                                Stock Out (Sale)
                              </span>
                            ) : isOpening ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-surface-container text-on-surface-variant">
                                <span className="w-1.5 h-1.5 rounded-full bg-outline" />
                                Opening Stock
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-surface-container text-on-surface">
                                {row.type}
                              </span>
                            )}
                          </td>

                          {/* Party / Counterparty */}
                          <td className="px-3 py-2">
                            <div className="font-medium text-xs text-on-surface truncate max-w-[180px]">
                              {row.partyName}
                            </div>
                          </td>

                          {/* Rate */}
                          <td className="px-3 py-2 text-right whitespace-nowrap text-xs text-on-surface font-medium">
                            {row.rate > 0 ? `Rs. ${row.rate.toLocaleString()}` : '-'}
                          </td>

                          {/* Inward (+) */}
                          <td className="px-3 py-2 text-right whitespace-nowrap">
                            {row.qtyIn > 0 ? (
                              <div className="flex flex-col items-end">
                                <span className="font-bold text-xs text-tertiary">
                                  +{row.qtyIn} {product.unit}s
                                </span>
                                <span className="text-[10px] text-on-surface-variant font-medium">
                                  +{row.volumeIn.toLocaleString()} {product.packingUnit}s
                                </span>
                              </div>
                            ) : (
                              <span className="text-on-surface-variant text-xs">-</span>
                            )}
                          </td>

                          {/* Outward (-) */}
                          <td className="px-3 py-2 text-right whitespace-nowrap">
                            {row.qtyOut > 0 ? (
                              <div className="flex flex-col items-end">
                                <span className="font-bold text-xs text-primary">
                                  -{row.qtyOut} {product.unit}s
                                </span>
                                <span className="text-[10px] text-on-surface-variant font-medium">
                                  -{row.volumeOut.toLocaleString()} {product.packingUnit}s
                                </span>
                              </div>
                            ) : (
                              <span className="text-on-surface-variant text-xs">-</span>
                            )}
                          </td>

                          {/* Running Balance */}
                          <td className="px-3 py-2 text-right whitespace-nowrap">
                            <div className="flex flex-col items-end">
                              <span className="font-bold text-xs text-on-surface">
                                {row.runningBalance} {product.unit}s
                              </span>
                              <span className="text-[10px] text-on-surface-variant">
                                {row.runningVolume.toLocaleString()} {product.packingUnit}s
                              </span>
                            </div>
                          </td>

                          {/* Total Value */}
                          <td className="px-3 py-2 text-right whitespace-nowrap font-semibold text-xs text-on-surface">
                            {row.totalValue > 0 ? `Rs. ${row.totalValue.toLocaleString()}` : '-'}
                          </td>

                          {/* Remarks */}
                          <td className="px-3 py-2 text-xs text-on-surface-variant max-w-[150px] truncate">
                            {row.notes || '-'}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Table Footer Summary Row */}
            {filteredHistory.length > 0 && (
              <div className="p-3 bg-surface-container-low border-t border-surface-container-high/60 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                <div className="text-on-surface-variant font-medium">
                  Showing <span className="font-bold text-on-surface">{filteredHistory.length}</span> recorded movement entries
                </div>
                <div className="flex flex-wrap items-center gap-4">
                  <div>
                    <span className="text-on-surface-variant">Total Inward: </span>
                    <span className="font-bold text-tertiary">+{totalInwardQty} {product.unit}s</span>
                  </div>
                  <span className="w-1 h-1 rounded-full bg-outline-variant" />
                  <div>
                    <span className="text-on-surface-variant">Total Outward: </span>
                    <span className="font-bold text-primary">-{totalOutwardQty} {product.unit}s</span>
                  </div>
                  <span className="w-1 h-1 rounded-full bg-outline-variant" />
                  <div>
                    <span className="text-on-surface-variant">Closing Stock: </span>
                    <span className="font-bold text-on-surface">{product.currentStock} {product.unit}s</span>
                  </div>
                  <span className="w-1 h-1 rounded-full bg-outline-variant" />
                  <div>
                    <span className="text-on-surface-variant">Valuation: </span>
                    <span className="font-bold text-on-surface">Rs. {stockValuationCost.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Modal Bottom Bar */}
        <div className="px-4 py-3 bg-surface-container-low border-t border-surface-container-high/60 flex items-center justify-between">
          <div className="text-[12px] text-on-surface-variant flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[15px] text-primary">info</span>
            <span>Real-time perpetual stock inventory ledger synced with purchases &amp; sales.</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleDownloadPDF}
              className="h-8 px-3 rounded-lg bg-surface-container hover:bg-surface-container-high text-on-surface text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <span className="material-symbols-outlined text-[16px]">print</span>
              <span>Print / PDF</span>
            </button>
            <button
              type="button"
              onClick={closeProductLedgerModal}
              className="h-8 px-4 rounded-lg bg-primary text-on-primary hover:bg-primary-container text-xs font-semibold transition-colors"
            >
              Close
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
