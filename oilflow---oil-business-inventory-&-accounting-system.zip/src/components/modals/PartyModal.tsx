import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { PartyType } from '../../types';

export const PartyModal: React.FC = () => {
  const { partyModalOpen, closePartyModal, editingParty, addParty, updateParty } = useApp();

  const [name, setName] = useState('');
  const [type, setType] = useState<PartyType>('Customer');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [currentBalance, setCurrentBalance] = useState<number>(0);
  const [creditLimit, setCreditLimit] = useState<number>(100000);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (editingParty) {
      setName(editingParty.name);
      setType(editingParty.type);
      setPhone(editingParty.phone || '');
      setAddress(editingParty.address || '');
      setCity(editingParty.city || 'Lahore');
      setCurrentBalance(editingParty.currentBalance || 0);
      setCreditLimit(editingParty.creditLimit || 100000);
      setNotes(editingParty.notes || '');
    } else {
      setName('');
      setType('Customer');
      setPhone('');
      setAddress('');
      setCity('');
      setCurrentBalance(0);
      setCreditLimit(0);
      setNotes('');
    }
  }, [editingParty, partyModalOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Please enter party name.');
      return;
    }

    const payload = {
      name: name.trim(),
      type,
      phone: phone.trim(),
      address: address.trim(),
      city: city.trim() || 'Lahore',
      currentBalance: Number(currentBalance) || 0,
      creditLimit: Number(creditLimit) || 0,
      notes: notes.trim(),
    };

    if (editingParty) {
      updateParty(editingParty.id, payload);
    } else {
      addParty(payload);
    }

    closePartyModal();
  };

  if (!partyModalOpen) return null;

  return (
    <div className="fixed inset-0 bg-inverse-surface/40 backdrop-blur-sm z-50 flex items-center justify-center p-space-sm sm:p-space-md animate-in fade-in duration-150">
      <div className="bg-surface-container-lowest w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden flex flex-col border border-surface-container-high/60">
        <div className="px-space-lg py-space-md bg-surface-container-low flex items-center justify-between border-b border-surface-container-high/60">
          <div className="flex items-center gap-space-sm">
            <div className="w-8 h-8 rounded-lg bg-primary-container text-on-primary flex items-center justify-center">
              <span className="material-symbols-outlined text-[18px]">person_add</span>
            </div>
            <div>
              <h3 className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                {editingParty ? 'Edit Party Profile' : 'Add New Party'}
              </h3>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Customer, supplier, or transport contractor
              </p>
            </div>
          </div>
          <button
            onClick={closePartyModal}
            className="w-8 h-8 rounded-full hover:bg-surface-container-high text-on-surface-variant flex items-center justify-center"
            type="button"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-space-lg space-y-space-md overflow-y-auto max-h-[80vh]">
          {/* Party Name */}
          <div className="flex flex-col gap-1">
            <label className="font-label-sm text-label-sm text-on-surface font-semibold">
              Business / Party Name <span className="text-error">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Al-Rehman Auto Stores, Shell Depot"
              required
              className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>

          {/* Party Type */}
          <div className="flex flex-col gap-1">
            <label className="font-label-sm text-label-sm text-on-surface font-semibold">Party Category</label>
            <div className="grid grid-cols-3 gap-2">
              {(['Customer', 'Supplier', 'Both'] as PartyType[]).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setType(t)}
                  className={`h-9 rounded-lg font-label-md text-label-md font-semibold transition-all ${
                    type === t
                      ? 'bg-primary-container text-on-primary shadow-xs'
                      : 'bg-surface-container-low text-on-surface-variant hover:text-on-surface hover:bg-surface-container'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Phone & City */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-space-md">
            <div className="flex flex-col gap-1">
              <label className="font-label-sm text-label-sm text-on-surface font-semibold">Phone / WhatsApp</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="0300-1234567"
                className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="font-label-sm text-label-sm text-on-surface font-semibold">City / Depot Station</label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Lahore, Karachi, Rawalpindi"
                className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
              />
            </div>
          </div>

          {/* Address */}
          <div className="flex flex-col gap-1">
            <label className="font-label-sm text-label-sm text-on-surface font-semibold">Warehouse / Shop Address</label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="e.g. Shop 22, Auto Market, Badami Bagh"
              className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>

          {/* Opening Balance & Credit Limit */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-space-md">
            <div className="flex flex-col gap-1">
              <label className="font-label-sm text-label-sm text-on-surface font-semibold">
                Opening Balance (PKR)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-body-sm text-on-surface-variant font-medium">
                  Rs.
                </span>
                <input
                  type="number"
                  value={currentBalance === 0 ? '' : currentBalance}
                  onChange={(e) => setCurrentBalance(e.target.value === '' ? 0 : Number(e.target.value))}
                  placeholder="0.00"
                  className="w-full h-10 pl-9 pr-3 bg-surface-container-low rounded-lg text-body-sm font-semibold text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>
              <span className="text-[11px] text-on-surface-variant">
                Positive = Receivable (+Rs). Negative = Payable (-Rs).
              </span>
            </div>

            <div className="flex flex-col gap-1">
              <label className="font-label-sm text-label-sm text-on-surface font-semibold">
                Credit Limit (PKR)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-body-sm text-on-surface-variant font-medium">
                  Rs.
                </span>
                <input
                  type="number"
                  min="0"
                  value={creditLimit === 0 ? '' : creditLimit}
                  onChange={(e) => setCreditLimit(e.target.value === '' ? 0 : Number(e.target.value))}
                  placeholder="0.00"
                  className="w-full h-10 pl-9 pr-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                />
              </div>
            </div>
          </div>

          {/* Notes */}
          <div className="flex flex-col gap-1">
            <label className="font-label-sm text-label-sm text-on-surface-variant">Account Notes / Credit Terms</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. 15-day payment cycle, preferred transporter"
              className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>

          {/* Footer */}
          <div className="pt-space-sm flex items-center justify-end gap-space-sm border-t border-surface-container-high/40">
            <button
              type="button"
              onClick={closePartyModal}
              className="px-space-md h-10 text-body-sm font-label-md rounded-lg bg-surface-container text-on-surface hover:bg-surface-container-high transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-space-lg h-10 text-body-sm font-semibold rounded-lg bg-primary text-on-primary hover:bg-primary-container transition-colors shadow-sm active:scale-98"
            >
              {editingParty ? 'Save Changes' : 'Create Party Account'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
