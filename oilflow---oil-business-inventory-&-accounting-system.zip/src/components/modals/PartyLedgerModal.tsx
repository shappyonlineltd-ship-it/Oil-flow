import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  generatePartyLedgerPDF,
  shareOnWhatsApp,
  shareNative,
  copyTextToClipboard,
} from '../../utils/pdfGenerator';

export const PartyLedgerModal: React.FC = () => {
  const {
    viewingPartyLedgerId,
    closePartyLedgerModal,
    parties,
    transactions,
    openTransactionModal,
    openViewTransactionModal,
    openPdfPreview,
    settings,
  } = useApp();

  const [viewMode, setViewMode] = useState<'standard' | 'pdf'>('standard');
  const [dateFilter, setDateFilter] = useState<'all' | '30days' | 'thisMonth'>('all');
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);

  const party = useMemo(() => {
    return parties.find((p) => p.id === viewingPartyLedgerId);
  }, [parties, viewingPartyLedgerId]);

  // Compute party ledger entries and running balance from actual transactions
  const allPartyHistory = useMemo(() => {
    if (!party) return [];

    // Filter transactions involving this party
    const relevantTx = transactions
      .filter((t) => t.partyId === party.id)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    let runningBal = 0;

    return relevantTx.map((tx) => {
      let debit = 0;
      let credit = 0;
      let desc = tx.notes || '';

      if (tx.type === 'Sale') {
        debit = tx.totalAmount;
        credit = tx.paidAmount;
        desc = tx.items.map((i) => `${i.productName} × ${i.quantity}`).join(', ') || 'Sale invoice';
        runningBal += tx.balanceDue;
      } else if (tx.type === 'Purchase') {
        credit = tx.totalAmount;
        debit = tx.paidAmount;
        desc = tx.items.map((i) => `${i.productName} × ${i.quantity}`).join(', ') || 'Purchase bill';
        runningBal -= tx.balanceDue;
      } else if (tx.type === 'Receive') {
        credit = tx.paidAmount;
        desc = tx.notes || 'Ledger recovery payment';
        runningBal -= tx.paidAmount;
      } else if (tx.type === 'Pay') {
        debit = tx.paidAmount;
        desc = tx.notes || 'Supplier bill settlement';
        runningBal += tx.paidAmount;
      }

      return {
        id: tx.id,
        docNumber: tx.docNumber,
        date: tx.date,
        time: tx.time,
        type: tx.type,
        description: desc,
        accountName: tx.accountName,
        debit,
        credit,
        runningBalance: runningBal,
        rawTx: tx,
      };
    });
  }, [party, transactions]);

  const partyHistory = useMemo(() => {
    if (dateFilter === 'all') return allPartyHistory;

    const now = new Date();
    return allPartyHistory.filter((item) => {
      const itemDate = new Date(item.date);
      if (dateFilter === '30days') {
        const diffDays = (now.getTime() - itemDate.getTime()) / (1000 * 3600 * 24);
        return diffDays <= 30;
      }
      if (dateFilter === 'thisMonth') {
        return (
          itemDate.getMonth() === now.getMonth() &&
          itemDate.getFullYear() === now.getFullYear()
        );
      }
      return true;
    });
  }, [allPartyHistory, dateFilter]);

  if (!party) return null;

  const totalDebit = partyHistory.reduce((s, r) => s + r.debit, 0);
  const totalCredit = partyHistory.reduce((s, r) => s + r.credit, 0);
  const isReceivable = party.currentBalance >= 0;

  // PDF Export
  const handleDownloadPDF = () => {
    generatePartyLedgerPDF(party, partyHistory, settings);
  };

  // WhatsApp Share
  const handleWhatsAppShare = () => {
    const balStatus = isReceivable
      ? `Receivable: Rs. ${Math.abs(party.currentBalance).toLocaleString()}`
      : `Payable: Rs. ${Math.abs(party.currentBalance).toLocaleString()}`;

    const text = `*OILFLOW PETROLEUM - PARTY LEDGER STATEMENT*\n` +
      `--------------------------------\n` +
      `Party: ${party.name} (${party.type})\n` +
      `${party.phone ? `Phone: ${party.phone}\n` : ''}` +
      `Date: ${new Date().toLocaleDateString()}\n` +
      `Total Debit: Rs. ${totalDebit.toLocaleString()}\n` +
      `Total Credit: Rs. ${totalCredit.toLocaleString()}\n` +
      `*Net Balance: ${balStatus}*\n` +
      `Total Entries: ${partyHistory.length}\n` +
      `--------------------------------\n` +
      `Kindly verify and reconcile. Thank you!`;

    shareOnWhatsApp(text, party.phone);
  };

  // Native Share
  const handleNativeShare = async () => {
    const text = `OilFlow Ledger for ${party.name} - Outstanding Balance: Rs. ${Math.abs(party.currentBalance).toLocaleString()} (${isReceivable ? 'Receivable' : 'Payable'}).`;
    const shared = await shareNative({
      title: `${party.name} Ledger Statement`,
      text,
      url: window.location.href,
    });
    if (!shared) {
      handleCopyText();
    }
  };

  // Copy text
  const handleCopyText = async () => {
    const text = `=== OILFLOW PARTY LEDGER STATEMENT ===\n` +
      `Party: ${party.name} (${party.type})\n` +
      `Contact: ${party.phone} · ${party.city}\n` +
      `Current Balance: Rs. ${Math.abs(party.currentBalance).toLocaleString()} (${isReceivable ? 'Receivable' : 'Payable'})\n` +
      `Total Debit: Rs. ${totalDebit.toLocaleString()}\n` +
      `Total Credit: Rs. ${totalCredit.toLocaleString()}\n` +
      `Total Entries: ${partyHistory.length}\n\n` +
      `Recent Entries:\n` +
      partyHistory
        .slice(-8)
        .map(
          (r) =>
            `${r.date} | ${r.docNumber} | ${r.description} | Dr: Rs.${r.debit.toLocaleString()} | Cr: Rs.${r.credit.toLocaleString()} | Bal: Rs.${Math.abs(r.runningBalance).toLocaleString()}`
        )
        .join('\n');

    const ok = await copyTextToClipboard(text);
    if (ok) {
      setCopyFeedback('Ledger statement copied to clipboard!');
      setTimeout(() => setCopyFeedback(null), 3000);
    }
  };

  return (
    <div className="flex flex-col w-full pb-space-xl animate-in fade-in duration-150">
      {/* Top In-Page Back Navigation */}
      <div className="flex items-center justify-between gap-space-sm mb-space-md no-print">
        <div className="flex items-center gap-space-sm">
          <button
            type="button"
            onClick={closePartyLedgerModal}
            className="h-10 px-space-md bg-surface-container-low hover:bg-surface-container text-on-surface rounded-lg flex items-center gap-space-xs font-label-md text-label-md font-semibold transition-colors shadow-xs active:scale-98"
          >
            <span className="material-symbols-outlined text-[20px]">arrow_back</span>
            <span>Back to Parties</span>
          </button>
          <div className="hidden sm:flex items-center gap-space-xs text-on-surface-variant font-label-sm uppercase tracking-wider">
            <span>Counterparties</span>
            <span className="material-symbols-outlined text-[14px]">chevron_right</span>
            <span>Party Ledgers</span>
            <span className="material-symbols-outlined text-[14px]">chevron_right</span>
            <span className="text-primary font-semibold">{party.name} Statement</span>
          </div>
        </div>
      </div>

      <div className="bg-surface-container-lowest w-full rounded-2xl shadow-sm overflow-hidden flex flex-col border border-surface-container-high/60 print-page">
        {/* Header - Hidden on physical print */}
        <div className="px-space-md sm:px-space-lg py-3.5 bg-surface-container-low flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm border-b border-surface-container-high/60 no-print">
          <div className="flex items-center gap-space-sm">
            <div className="w-10 h-10 rounded-xl bg-primary-container text-on-primary flex items-center justify-center font-bold text-[16px] shadow-xs">
              {party.name.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-headline-md text-headline-md font-bold text-on-surface">
                  {party.name}
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-secondary-container text-on-secondary-fixed">
                  {party.type}
                </span>
              </div>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                {party.phone} · {party.address}, {party.city}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-1.5 self-end sm:self-auto">
            {/* View Mode Switcher */}
            <div className="flex items-center bg-surface-container-lowest p-1 rounded-lg border border-surface-container-high/60 mr-1">
              <button
                type="button"
                onClick={() => setViewMode('standard')}
                className={`px-2.5 py-1 rounded-md text-[12px] font-semibold transition-colors flex items-center gap-1 ${
                  viewMode === 'standard'
                    ? 'bg-primary text-on-primary shadow-xs'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                <span className="material-symbols-outlined text-[15px]">table_rows</span>
                <span>Ledger</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('pdf')}
                className={`px-2.5 py-1 rounded-md text-[12px] font-semibold transition-colors flex items-center gap-1 ${
                  viewMode === 'pdf'
                    ? 'bg-primary text-on-primary shadow-xs'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                <span className="material-symbols-outlined text-[15px]">picture_as_pdf</span>
                <span>PDF View</span>
              </button>
            </div>

            {/* Quick Financial Postings */}
            {party.type !== 'Supplier' && (
              <button
                type="button"
                onClick={() => {
                  closePartyLedgerModal();
                  openTransactionModal('Receive', undefined, party.id);
                }}
                className="h-8 px-2.5 rounded-lg bg-tertiary-fixed text-on-tertiary-fixed text-[12px] font-bold hover:bg-tertiary-fixed/80 transition-colors flex items-center gap-1 shadow-xs"
              >
                <span className="material-symbols-outlined text-[16px]">input</span>
                <span className="hidden sm:inline">Receive</span>
              </button>
            )}

            {party.type !== 'Customer' && (
              <button
                type="button"
                onClick={() => {
                  closePartyLedgerModal();
                  openTransactionModal('Pay', undefined, party.id);
                }}
                className="h-8 px-2.5 rounded-lg bg-error-container text-on-error-container text-[12px] font-bold hover:bg-error-container/80 transition-colors flex items-center gap-1 shadow-xs"
              >
                <span className="material-symbols-outlined text-[16px]">output</span>
                <span className="hidden sm:inline">Pay</span>
              </button>
            )}

            {/* Download PDF button */}
            <button
              onClick={handleDownloadPDF}
              type="button"
              className="h-8 px-2.5 rounded-lg bg-primary text-on-primary hover:bg-primary-container text-[12px] font-semibold flex items-center gap-1 shadow-xs transition-colors"
              title="Download official PDF file"
            >
              <span className="material-symbols-outlined text-[16px]">download</span>
              <span className="hidden sm:inline">PDF</span>
            </button>

            {/* WhatsApp Share */}
            <button
              onClick={handleWhatsAppShare}
              type="button"
              className="h-8 px-2.5 rounded-lg bg-tertiary-fixed text-on-tertiary-fixed hover:bg-tertiary-fixed/80 text-[12px] font-semibold flex items-center gap-1 shadow-xs transition-colors"
              title="Send Ledger on WhatsApp"
            >
              <span className="material-symbols-outlined text-[16px]">share</span>
              <span>WhatsApp</span>
            </button>

            {/* Copy / Native Share */}
            <button
              onClick={handleNativeShare}
              type="button"
              className="h-8 px-2 rounded-lg bg-surface-container-lowest hover:bg-surface-container text-on-surface-variant text-[12px] font-semibold flex items-center gap-1 border border-surface-container-high/60 transition-colors"
              title="Share or Copy Statement"
            >
              <span className="material-symbols-outlined text-[16px]">content_copy</span>
              <span className="hidden sm:inline">Copy</span>
            </button>

            {/* Print */}
            <button
              onClick={() => window.print()}
              type="button"
              className="w-8 h-8 rounded-lg bg-surface-container-lowest hover:bg-surface-container text-on-surface-variant flex items-center justify-center border border-surface-container-high/60 transition-colors"
              title="Print statement"
            >
              <span className="material-symbols-outlined text-[18px]">print</span>
            </button>

            {/* Close */}
            <button
              onClick={closePartyLedgerModal}
              className="w-8 h-8 rounded-full hover:bg-surface-container-high text-on-surface-variant flex items-center justify-center transition-colors ml-1"
              type="button"
            >
              <span className="material-symbols-outlined text-[20px]">close</span>
            </button>
          </div>
        </div>

        {/* Copy Feedback notification */}
        {copyFeedback && (
          <div className="bg-tertiary-fixed text-on-tertiary-fixed px-space-md py-1.5 text-center text-[12px] font-bold flex items-center justify-center gap-2 no-print animate-in fade-in">
            <span className="material-symbols-outlined text-[16px]">check_circle</span>
            <span>{copyFeedback}</span>
          </div>
        )}

        {/* Current Balance Summary Banner - Hidden on print */}
        <div className="p-space-md bg-surface-container-low/40 border-b border-surface-container-high/40 flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm no-print">
          <div>
            <span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider font-semibold block">
              Net Outstanding Ledger Balance
            </span>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span
                className={`font-metric-xl text-metric-xl font-bold ${
                  party.currentBalance >= 0 ? 'text-tertiary' : 'text-error'
                }`}
              >
                Rs. {Math.abs(party.currentBalance).toLocaleString()}
              </span>
              <span className="font-label-md text-label-md font-semibold text-on-surface-variant">
                {party.currentBalance > 0
                  ? '(Customer Receivable)'
                  : party.currentBalance < 0
                  ? '(Supplier Payable)'
                  : '(Settled Balance)'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-space-md">
            <div>
              <span className="text-[10px] text-on-surface-variant uppercase font-semibold block">Total Debit</span>
              <span className="text-[13px] font-bold text-on-surface">Rs. {totalDebit.toLocaleString()}</span>
            </div>
            <div>
              <span className="text-[10px] text-on-surface-variant uppercase font-semibold block">Total Credit</span>
              <span className="text-[13px] font-bold text-on-surface">Rs. {totalCredit.toLocaleString()}</span>
            </div>
            {party.creditLimit ? (
              <div className="pl-space-sm border-l border-surface-container-high">
                <span className="text-[10px] text-on-surface-variant uppercase font-semibold block">Credit Limit</span>
                <span className="text-[13px] font-semibold text-on-surface">Rs. {party.creditLimit.toLocaleString()}</span>
              </div>
            ) : null}
          </div>
        </div>

        {/* Ledger Content */}
        <div className="flex-1 overflow-y-auto p-space-md sm:p-space-lg bg-surface-container-lowest">
          {viewMode === 'standard' ? (
            /* Interactive Table */
            <div className="rounded-xl border border-surface-container-high overflow-hidden shadow-xs">
              <table className="w-full text-left border-collapse text-body-sm">
                <thead>
                  <tr className="bg-surface-container-low text-on-surface-variant font-label-sm text-[11px] uppercase tracking-wider font-semibold">
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Doc #</th>
                    <th className="py-2.5 px-3">Type</th>
                    <th className="py-2.5 px-3">Description / Goods</th>
                    <th className="py-2.5 px-3 text-right">Debit (Rs.)</th>
                    <th className="py-2.5 px-3 text-right">Credit (Rs.)</th>
                    <th className="py-2.5 px-3 text-right">Balance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-surface-container-low">
                  {partyHistory.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-on-surface-variant">
                        No transactions recorded yet for this party.
                      </td>
                    </tr>
                  ) : (
                    partyHistory.map((row) => (
                      <tr key={row.id} className="hover:bg-surface-container-low/40 transition-colors">
                        <td className="py-2.5 px-3 whitespace-nowrap text-on-surface font-medium">
                          {row.date}
                        </td>
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => openPdfPreview(row.rawTx)}
                            className="inline-flex items-center gap-1.5 font-mono text-primary text-[12px] font-semibold hover:underline cursor-pointer focus:outline-none transition-all"
                            title="Click to view & download PDF"
                          >
                            <span className="material-symbols-outlined text-[15px] opacity-75">picture_as_pdf</span>
                            <span>{row.docNumber}</span>
                          </button>
                        </td>
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              row.type === 'Sale'
                                ? 'bg-primary-container text-on-primary'
                                : row.type === 'Purchase'
                                ? 'bg-secondary-container text-primary'
                                : row.type === 'Receive'
                                ? 'bg-tertiary-fixed text-on-tertiary-fixed'
                                : 'bg-error-container text-on-error-container'
                            }`}
                          >
                            {row.type}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 max-w-xs truncate text-on-surface">
                          {row.description}
                        </td>
                        <td className="py-2.5 px-3 text-right font-semibold text-on-surface whitespace-nowrap">
                          {row.debit > 0 ? `Rs. ${row.debit.toLocaleString()}` : '-'}
                        </td>
                        <td className="py-2.5 px-3 text-right font-semibold text-on-surface whitespace-nowrap">
                          {row.credit > 0 ? `Rs. ${row.credit.toLocaleString()}` : '-'}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold whitespace-nowrap">
                          <span className={row.runningBalance >= 0 ? 'text-tertiary' : 'text-error'}>
                            Rs. {Math.abs(row.runningBalance).toLocaleString()} {row.runningBalance >= 0 ? 'Dr' : 'Cr'}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          ) : (
            /* Authentic Printable PDF Document View */
            <div className="max-w-3xl mx-auto bg-white p-6 sm:p-8 rounded-xl border border-gray-300 shadow-sm text-gray-800 font-sans print:border-none print:p-0">
              {/* Document Letterhead */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b-2 border-primary gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-primary text-white flex items-center justify-center font-bold text-[14px]">
                      OF
                    </div>
                    <h2 className="text-xl font-bold text-gray-900 tracking-tight">
                      {settings?.businessName || 'OILFLOW PETROLEUM & LUBRICANTS'}
                    </h2>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    {settings?.depotName || 'Depot Terminal & Warehouse Operations'} · Party Account Ledger Statement
                  </p>
                </div>
                <div className="text-left sm:text-right">
                  <span className="inline-block bg-primary/10 text-primary px-2.5 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider">
                    Client Account Statement
                  </span>
                  <p className="text-xs text-gray-500 mt-1">
                    Generated: {new Date().toLocaleString()}
                  </p>
                </div>
              </div>

              {/* Counterparty Profile Box */}
              <div className="my-5 p-4 rounded-lg bg-gray-50 border border-gray-200 flex flex-col sm:flex-row justify-between gap-4">
                <div>
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                    Party / Counterparty Information
                  </span>
                  <h4 className="text-lg font-bold text-gray-900 mt-0.5">{party.name}</h4>
                  <p className="text-xs text-gray-600 mt-0.5">
                    Type: <span className="font-semibold">{party.type}</span> · Phone: {party.phone || 'N/A'} · City: {party.city}
                  </p>
                  {party.address && (
                    <p className="text-xs text-gray-500 mt-0.5">Address: {party.address}</p>
                  )}
                </div>

                <div className="flex gap-4 sm:border-l sm:border-gray-200 sm:pl-4">
                  <div>
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                      Total Debit
                    </span>
                    <span className="text-sm font-bold text-gray-900">
                      Rs. {totalDebit.toLocaleString()}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                      Total Credit
                    </span>
                    <span className="text-sm font-bold text-gray-900">
                      Rs. {totalCredit.toLocaleString()}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                      Net Balance
                    </span>
                    <span className={`text-base font-bold ${isReceivable ? 'text-green-700' : 'text-red-700'}`}>
                      Rs. {Math.abs(party.currentBalance).toLocaleString()} {isReceivable ? '(Dr)' : '(Cr)'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Printable Table */}
              <div className="overflow-x-auto my-4">
                <table className="w-full text-left text-xs border border-gray-200">
                  <thead className="bg-gray-100 text-gray-700 font-bold uppercase text-[10px]">
                    <tr>
                      <th className="p-2 border border-gray-200">Date</th>
                      <th className="p-2 border border-gray-200">Doc #</th>
                      <th className="p-2 border border-gray-200">Type</th>
                      <th className="p-2 border border-gray-200">Description / Items</th>
                      <th className="p-2 text-right border border-gray-200">Debit (Rs.)</th>
                      <th className="p-2 text-right border border-gray-200">Credit (Rs.)</th>
                      <th className="p-2 text-right border border-gray-200">Balance</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {partyHistory.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="p-4 text-center text-gray-400">
                          No ledger postings recorded.
                        </td>
                      </tr>
                    ) : (
                      partyHistory.map((row) => (
                        <tr key={row.id} className="odd:bg-white even:bg-gray-50/50">
                          <td className="p-2 whitespace-nowrap text-gray-800 font-medium">{row.date}</td>
                          <td className="p-2 whitespace-nowrap font-mono font-bold text-primary">{row.docNumber}</td>
                          <td className="p-2 whitespace-nowrap">
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-gray-200 text-gray-800">
                              {row.type}
                            </span>
                          </td>
                          <td className="p-2 text-gray-700">{row.description}</td>
                          <td className="p-2 text-right font-medium text-gray-900 whitespace-nowrap">
                            {row.debit > 0 ? `Rs. ${row.debit.toLocaleString()}` : '-'}
                          </td>
                          <td className="p-2 text-right font-medium text-gray-900 whitespace-nowrap">
                            {row.credit > 0 ? `Rs. ${row.credit.toLocaleString()}` : '-'}
                          </td>
                          <td className="p-2 text-right font-bold whitespace-nowrap">
                            <span className={row.runningBalance >= 0 ? 'text-green-700' : 'text-red-700'}>
                              Rs. {Math.abs(row.runningBalance).toLocaleString()} {row.runningBalance >= 0 ? 'Dr' : 'Cr'}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                  <tfoot className="bg-gray-100 font-bold border-t-2 border-gray-300">
                    <tr>
                      <td colSpan={4} className="p-2 text-gray-800 uppercase text-[10px]">
                        Closing Reconciliation ({partyHistory.length} Postings)
                      </td>
                      <td className="p-2 text-right text-gray-900 whitespace-nowrap">
                        Rs. {totalDebit.toLocaleString()}
                      </td>
                      <td className="p-2 text-right text-gray-900 whitespace-nowrap">
                        Rs. {totalCredit.toLocaleString()}
                      </td>
                      <td className="p-2 text-right whitespace-nowrap font-bold">
                        <span className={party.currentBalance >= 0 ? 'text-green-700' : 'text-red-700'}>
                          Rs. {Math.abs(party.currentBalance).toLocaleString()} {party.currentBalance >= 0 ? 'Dr' : 'Cr'}
                        </span>
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Signatures & Verification */}
              <div className="pt-8 mt-8 border-t border-gray-200 flex justify-between items-end text-xs text-gray-500">
                <div className="text-center w-40">
                  <div className="border-b border-gray-400 pb-1 mb-1" />
                  <span>Prepared By Accountant</span>
                </div>
                <div className="text-center">
                  <span className="text-[10px] text-gray-400 block mb-1">AUDIT VERIFIED</span>
                  <span className="px-2 py-0.5 border border-dashed border-gray-300 rounded text-[10px] text-gray-400">
                    CONFIRMED BALANCE
                  </span>
                </div>
                <div className="text-center w-40">
                  <div className="border-b border-gray-400 pb-1 mb-1" />
                  <span>Customer Sign &amp; Seal</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer - Hidden on print */}
        <div className="p-space-md bg-surface-container-low flex items-center justify-between border-t border-surface-container-high/60 no-print">
          <span className="font-body-sm text-body-sm text-on-surface-variant">
            {partyHistory.length} ledger statement entries recorded
          </span>
          <div className="flex items-center gap-space-sm">
            <button
              type="button"
              onClick={handleDownloadPDF}
              className="px-3 h-9 text-body-sm font-semibold rounded-lg bg-surface-container text-on-surface hover:bg-surface-container-high transition-colors flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[16px]">download</span>
              <span>Download PDF</span>
            </button>
            <button
              type="button"
              onClick={closePartyLedgerModal}
              className="px-space-md h-9 text-body-sm font-semibold rounded-lg bg-primary text-on-primary hover:bg-primary-container transition-colors"
            >
              Close Statement
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
