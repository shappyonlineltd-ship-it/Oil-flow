import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

export const AccountTransferModal: React.FC = () => {
  const { transferModalOpen, closeTransferModal, accounts, createTransaction } = useApp();

  const [fromAccountId, setFromAccountId] = useState(accounts[0]?.id || '');
  const [toAccountId, setToAccountId] = useState(accounts[1]?.id || accounts[0]?.id || '');
  const [amount, setAmount] = useState<number>(0);
  const [notes, setNotes] = useState('');

  if (!transferModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (fromAccountId === toAccountId) {
      alert('Source and destination accounts must be different.');
      return;
    }

    if (amount <= 0) {
      alert('Please enter a positive transfer amount.');
      return;
    }

    const fromAcc = accounts.find((a) => a.id === fromAccountId);
    const toAcc = accounts.find((a) => a.id === toAccountId);

    createTransaction({
      type: 'Transfer',
      date: new Date().toISOString().slice(0, 10),
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      accountId: fromAccountId,
      accountName: fromAcc?.name,
      toAccountId,
      toAccountName: toAcc?.name,
      items: [],
      totalAmount: amount,
      paidAmount: amount,
      balanceDue: 0,
      paymentStatus: 'Paid',
      notes: notes || `Vault/Bank transfer from ${fromAcc?.name} to ${toAcc?.name}`,
    });

    closeTransferModal();
  };

  return (
    <div className="fixed inset-0 bg-inverse-surface/40 backdrop-blur-sm z-50 flex items-center justify-center p-space-sm sm:p-space-md animate-in fade-in duration-150">
      <div className="bg-surface-container-lowest w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-surface-container-high/60">
        <div className="px-space-lg py-space-md bg-surface-container-low flex items-center justify-between border-b border-surface-container-high/60">
          <div className="flex items-center gap-space-sm">
            <div className="w-8 h-8 rounded-lg bg-primary-container text-on-primary flex items-center justify-center">
              <span className="material-symbols-outlined text-[18px]">sync_alt</span>
            </div>
            <div>
              <h3 className="font-headline-sm text-headline-sm text-on-surface font-semibold">
                Transfer Funds
              </h3>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Internal Vault &lt;-&gt; Bank adjustment
              </p>
            </div>
          </div>
          <button
            onClick={closeTransferModal}
            className="w-8 h-8 rounded-full hover:bg-surface-container-high text-on-surface-variant flex items-center justify-center"
            type="button"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-space-lg space-y-space-md">
          <div className="flex flex-col gap-1">
            <label className="font-label-sm text-label-sm text-on-surface font-semibold">
              From Account (Source)
            </label>
            <select
              value={fromAccountId}
              onChange={(e) => setFromAccountId(e.target.value)}
              className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
            >
              {accounts.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name} (Bal: Rs. {a.balance.toLocaleString()})
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1">
            <label className="font-label-sm text-label-sm text-on-surface font-semibold">
              To Account (Destination)
            </label>
            <select
              value={toAccountId}
              onChange={(e) => setToAccountId(e.target.value)}
              className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
            >
              {accounts.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name} (Bal: Rs. {a.balance.toLocaleString()})
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1">
            <label className="font-label-sm text-label-sm text-on-surface font-semibold">
              Transfer Amount (PKR)
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-body-sm text-on-surface-variant font-medium">
                Rs.
              </span>
              <input
                type="number"
                min="1"
                value={amount === 0 ? '' : amount}
                placeholder="0.00"
                onChange={(e) => setAmount(e.target.value === '' ? 0 : Number(e.target.value))}
                required
                className="w-full h-10 pl-9 pr-3 bg-surface-container-low rounded-lg text-body-sm font-bold text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
              />
            </div>
          </div>

          <div className="flex flex-col gap-1">
            <label className="font-label-sm text-label-sm text-on-surface-variant">
              Transfer Memo / Reason
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Deposit from Cash Safe to HBL"
              className="h-10 px-3 bg-surface-container-low rounded-lg text-body-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>

          <div className="pt-space-sm flex items-center justify-end gap-space-sm border-t border-surface-container-high/40">
            <button
              type="button"
              onClick={closeTransferModal}
              className="px-space-md h-10 text-body-sm font-label-md rounded-lg bg-surface-container text-on-surface hover:bg-surface-container-high transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-space-lg h-10 text-body-sm font-semibold rounded-lg bg-primary text-on-primary hover:bg-primary-container transition-colors shadow-sm"
            >
              Execute Transfer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
