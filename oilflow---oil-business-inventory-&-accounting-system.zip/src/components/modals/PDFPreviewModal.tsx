import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { generateTransactionPDF, generateTransactionHTML, shareOnWhatsApp } from '../../utils/pdfGenerator';

export const PDFPreviewModal: React.FC = () => {
  const {
    pdfPreviewTransaction,
    closePdfPreview,
    downloadTransactionPdf,
    settings,
    parties,
    accounts,
  } = useApp();

  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [srcDoc, setSrcDoc] = useState<string>('');
  const [blobUrl, setBlobUrl] = useState<string | null>(null);
  const [loadError, setLoadError] = useState(false);

  useEffect(() => {
    if (!pdfPreviewTransaction) {
      setSrcDoc('');
      setBlobUrl(null);
      setLoadError(false);
      return;
    }

    try {
      const pty = parties.find((p) => p.id === pdfPreviewTransaction.partyId);
      const acc = accounts.find((a) => a.id === pdfPreviewTransaction.accountId);

      // Generate HTML document for instant, reliable iframe rendering
      const html = generateTransactionHTML(
        pdfPreviewTransaction,
        settings,
        pty,
        acc
      );
      setSrcDoc(html);

      // Also generate PDF blob for download & print actions
      const url = generateTransactionPDF(
        pdfPreviewTransaction,
        settings,
        pty,
        acc,
        'blob'
      ) as string;

      setBlobUrl(url);
      setLoadError(false);

      return () => {
        if (url) {
          URL.revokeObjectURL(url);
        }
      };
    } catch (err) {
      console.error('Error generating PDF preview:', err);
      setLoadError(true);
    }
  }, [pdfPreviewTransaction, settings, parties, accounts]);

  if (!pdfPreviewTransaction) return null;

  const tx = pdfPreviewTransaction;
  const isSale = tx.type === 'Sale';
  const isPurchase = tx.type === 'Purchase';
  const isJV = tx.docNumber?.startsWith('JV');

  const docLabel = isSale
    ? 'Sales Invoice'
    : isPurchase
    ? 'Purchase Order'
    : isJV
    ? 'Journal Voucher'
    : `${tx.type} Voucher`;

  const handleDownload = () => {
    downloadTransactionPdf(tx);
  };

  const handlePrint = () => {
    if (iframeRef.current?.contentWindow) {
      try {
        iframeRef.current.contentWindow.focus();
        iframeRef.current.contentWindow.print();
        return;
      } catch (err) {
        console.error('Error printing from iframe:', err);
      }
    }
    if (blobUrl) {
      const printWin = window.open(blobUrl);
      if (printWin) {
        printWin.focus();
        setTimeout(() => {
          try {
            printWin.print();
          } catch {
            // ignore
          }
        }, 500);
        return;
      }
    }
    window.print();
  };

  const handleWhatsApp = () => {
    const pty = parties.find((p) => p.id === tx.partyId);
    const totalAmt = (tx.totalAmount ?? 0).toLocaleString();
    const paidAmt = (tx.paidAmount ?? 0).toLocaleString();
    const balDue = (tx.balanceDue ?? 0).toLocaleString();
    const status = tx.paymentStatus || 'Paid';
    const text = `*${settings.businessName || 'OilFlow'} - ${docLabel}*\nDoc #: ${tx.docNumber}\nDate: ${tx.date}\nParty: ${tx.partyName || 'Counter Sale'}\nTotal Amount: Rs. ${totalAmt}\nCleared: Rs. ${paidAmt}\nBalance Due: Rs. ${balDue}\nStatus: ${status}`;
    shareOnWhatsApp(text, pty?.phone);
  };

  return (
    <div className="fixed inset-0 bg-inverse-surface/50 backdrop-blur-sm z-50 flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-surface-container-lowest w-full max-w-4xl h-[92vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-surface-container-high/60">
        {/* Top Control Header */}
        <div className="px-4 py-3 bg-surface-container-low flex flex-wrap items-center justify-between gap-2 border-b border-surface-container-high/60 shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                isSale
                  ? 'bg-primary-container text-on-primary'
                  : isPurchase
                  ? 'bg-secondary-container text-primary'
                  : isJV
                  ? 'bg-tertiary-fixed text-on-tertiary-fixed'
                  : 'bg-surface-container text-primary'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]">
                {isSale ? 'receipt_long' : isPurchase ? 'shopping_bag' : isJV ? 'edit_note' : 'picture_as_pdf'}
              </span>
            </div>
            <div className="truncate">
              <div className="flex items-center gap-2">
                <span className="font-headline-sm text-[15px] font-bold text-on-surface">
                  {docLabel}: <span className="text-primary">{tx.docNumber}</span>
                </span>
                <span
                  className={`text-[11px] px-2 py-0.5 rounded-full font-bold uppercase ${
                    (tx.paymentStatus || 'Paid') === 'Paid'
                      ? 'bg-tertiary-fixed text-on-tertiary-fixed'
                      : tx.paymentStatus === 'Partial'
                      ? 'bg-secondary-container text-on-secondary-fixed'
                      : 'bg-error-container text-on-error-container'
                  }`}
                >
                  {tx.paymentStatus || 'Paid'}
                </span>
              </div>
              <p className="text-[12px] text-on-surface-variant truncate">
                {tx.partyName || 'Counter Client'} · Total: Rs. {(tx.totalAmount ?? 0).toLocaleString()} · {tx.date}
              </p>
            </div>
          </div>

          {/* Action Buttons: Download PDF, Print, Share, Close */}
          <div className="flex items-center gap-1.5 ml-auto">
            <button
              type="button"
              onClick={handleDownload}
              className="px-3 h-9 rounded-lg bg-primary text-on-primary hover:bg-primary-container font-label-md text-label-md font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
              title="Download PDF file"
            >
              <span className="material-symbols-outlined text-[18px]">download</span>
              <span className="hidden sm:inline">Download PDF</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className="px-2.5 h-9 rounded-lg bg-surface-container hover:bg-surface-container-high text-on-surface font-label-md text-label-md font-semibold flex items-center gap-1 transition-colors"
              title="Print document"
            >
              <span className="material-symbols-outlined text-[18px]">print</span>
              <span className="hidden md:inline">Print</span>
            </button>

            <button
              type="button"
              onClick={handleWhatsApp}
              className="px-2.5 h-9 rounded-lg bg-emerald-600/10 text-emerald-700 hover:bg-emerald-600/20 font-label-md text-label-md font-semibold flex items-center gap-1 transition-colors"
              title="Share document details via WhatsApp"
            >
              <span className="material-symbols-outlined text-[18px]">share</span>
              <span className="hidden md:inline">WhatsApp</span>
            </button>

            <button
              type="button"
              onClick={closePdfPreview}
              className="w-9 h-9 rounded-full hover:bg-surface-container-high text-on-surface-variant hover:text-on-surface flex items-center justify-center transition-colors ml-1"
              aria-label="Close Preview"
            >
              <span className="material-symbols-outlined text-[20px]">close</span>
            </button>
          </div>
        </div>

        {/* PDF Viewer Body */}
        <div className="flex-1 bg-surface-container-high/30 relative flex flex-col items-center justify-center overflow-hidden">
          {(srcDoc || blobUrl) && !loadError ? (
            <iframe
              ref={iframeRef}
              srcDoc={srcDoc || undefined}
              src={!srcDoc && blobUrl ? blobUrl : undefined}
              title={`PDF Preview ${tx.docNumber}`}
              className="w-full h-full border-0"
            />
          ) : (
            <div className="flex flex-col items-center justify-center p-6 text-center max-w-md">
              <span className="material-symbols-outlined text-primary text-[48px] mb-2">
                picture_as_pdf
              </span>
              <h4 className="font-headline-sm text-headline-sm font-semibold text-on-surface">
                {docLabel} Ready
              </h4>
              <p className="font-body-sm text-body-sm text-on-surface-variant mt-1 mb-4">
                Click below to download the official formatted PDF for {tx.docNumber}.
              </p>
              <button
                type="button"
                onClick={handleDownload}
                className="px-4 py-2.5 rounded-lg bg-primary text-on-primary font-semibold flex items-center gap-2 shadow-sm"
              >
                <span className="material-symbols-outlined text-[20px]">download</span>
                Download {docLabel} PDF
              </button>
            </div>
          )}
        </div>

        {/* Bottom Bar Info */}
        <div className="px-4 py-2 bg-surface-container-low text-[11px] text-on-surface-variant flex items-center justify-between border-t border-surface-container-high/60 shrink-0">
          <span>Official OilFlow Petroleum Audit Document</span>
          <span>
            Doc ID: <span className="font-mono text-on-surface">{tx.id}</span>
          </span>
        </div>
      </div>
    </div>
  );
};
