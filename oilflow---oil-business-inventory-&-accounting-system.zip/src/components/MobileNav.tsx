import React from 'react';
import { useApp } from '../context/AppContext';
import { NavTab } from '../types';

export const MobileNav: React.FC = () => {
  const { activeTab, setActiveTab, openTransactionModal } = useApp();

  return (
    <nav className="lg:hidden fixed bottom-0 w-full z-40 pb-safe pointer-events-none">
      <div className="px-margin-sm pb-space-sm pointer-events-auto">
        <div className="bg-surface-container-lowest/95 backdrop-blur-xl rounded-full shadow-[0_4px_20px_rgba(11,28,48,0.12)] border border-surface-container-high px-2 h-16 flex items-center justify-between">
          {/* Tab 1: Home */}
          <button
            type="button"
            onClick={() => setActiveTab('dashboard')}
            className={`flex-1 flex flex-col items-center justify-center min-w-[44px] h-11 transition-colors ${
              activeTab === 'dashboard' ? 'text-primary font-bold' : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <span className="material-symbols-outlined text-[22px]">dashboard</span>
            <span className="font-label-sm text-[10px] mt-0.5">Home</span>
          </button>

          {/* Tab 2: Stock */}
          <button
            type="button"
            onClick={() => setActiveTab('inventory')}
            className={`flex-1 flex flex-col items-center justify-center min-w-[44px] h-11 transition-colors ${
              activeTab === 'inventory' ? 'text-primary font-bold' : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <span className="material-symbols-outlined text-[22px]">inventory_2</span>
            <span className="font-label-sm text-[10px] mt-0.5">Stock</span>
          </button>

          {/* Center Elevated Action: New Transaction */}
          <div className="flex-1 flex items-center justify-center">
            <button
              type="button"
              onClick={() => openTransactionModal('Sale')}
              aria-label="New Transaction"
              className="w-12 h-12 -mt-5 rounded-full bg-primary-container text-on-primary flex items-center justify-center shadow-lg shadow-primary-container/40 active:scale-95 transition-transform"
            >
              <span className="material-symbols-outlined text-[26px]">add</span>
            </button>
          </div>

          {/* Tab 4: Parties */}
          <button
            type="button"
            onClick={() => setActiveTab('parties')}
            className={`flex-1 flex flex-col items-center justify-center min-w-[44px] h-11 transition-colors ${
              activeTab === 'parties' ? 'text-primary font-bold' : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <span className="material-symbols-outlined text-[22px]">group</span>
            <span className="font-label-sm text-[10px] mt-0.5">Parties</span>
          </button>

          {/* Tab 5: Ledger */}
          <button
            type="button"
            onClick={() => setActiveTab('accounts-ledgers')}
            className={`flex-1 flex flex-col items-center justify-center min-w-[44px] h-11 transition-colors ${
              activeTab === 'accounts-ledgers' ? 'text-primary font-bold' : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <span className="material-symbols-outlined text-[22px]">account_balance_wallet</span>
            <span className="font-label-sm text-[10px] mt-0.5">Ledger</span>
          </button>
        </div>
      </div>
    </nav>
  );
};
