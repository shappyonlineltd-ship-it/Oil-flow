import React from 'react';
import { useApp } from '../context/AppContext';

export const Header: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    searchQuery,
    setSearchQuery,
    setIsMobileMenuOpen,
    lowStockCount,
    settings,
    openReconcileModal,
  } = useApp();

  const sectionTitles: Record<string, string> = {
    dashboard: 'Operations Desk',
    inventory: 'Inventory & Tanks',
    transactions: 'Transaction Log',
    parties: 'Party Ledgers',
    'accounts-ledgers': 'Accounts & Vault',
    'profit-loss': 'Profit & Loss Statement',
    expenses: 'Expense Heads & Overheads',
    settings: 'Settings & Cloud Sync',
  };

  const todayFormatted = new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }).format(new Date());

  return (
    <header className="fixed top-0 left-0 lg:left-[240px] right-0 h-16 bg-surface-container-lowest/90 backdrop-blur-md z-30 px-space-md lg:px-space-lg flex items-center justify-between shadow-[0_1px_8px_rgba(0,0,0,0.04)] border-b border-surface-container-high/40">
      {/* Left: Mobile hamburger or Desktop Breadcrumbs + Search */}
      <div className="flex items-center gap-space-sm lg:gap-space-md min-w-0 flex-1">
        {/* Mobile menu trigger */}
        <button
          onClick={() => setIsMobileMenuOpen(true)}
          className="lg:hidden p-2 rounded-lg text-on-surface-variant hover:text-on-surface hover:bg-surface-container-low transition-colors"
          aria-label="Open navigation menu"
        >
          <span className="material-symbols-outlined text-[24px]">menu</span>
        </button>

        {/* Desktop Breadcrumbs */}
        <div className="hidden sm:flex items-center gap-space-xs text-on-surface-variant font-body-sm text-body-sm shrink-0">
          <span
            className="hover:text-on-surface transition-colors cursor-pointer"
            onClick={() => setActiveTab('dashboard')}
          >
            BizFlow Desk
          </span>
          <span className="material-symbols-outlined text-[16px]">chevron_right</span>
          <span className="text-on-surface font-semibold truncate max-w-[140px]">
            {sectionTitles[activeTab] || 'Operations'}
          </span>
        </div>

        {/* Search Bar */}
        <div className="relative w-full max-w-xs sm:max-w-sm lg:max-w-md ml-1 sm:ml-space-md">
          <span className="material-symbols-outlined absolute left-space-sm top-1/2 -translate-y-1/2 text-on-surface-variant text-[18px]">
            search
          </span>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search products, parties, invoices..."
            className="w-full h-9 pl-9 pr-space-md bg-surface-container-low rounded-lg font-body-sm text-body-sm text-on-surface placeholder:text-on-surface-variant focus:outline-none focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary/20 transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-on-surface-variant hover:text-on-surface text-[14px]"
            >
              <span className="material-symbols-outlined text-[16px]">close</span>
            </button>
          )}
        </div>
      </div>

      {/* Right: Date, Notifications & Account Badge */}
      <div className="flex items-center gap-space-xs sm:gap-space-sm lg:gap-space-md shrink-0 ml-2">
        {/* Date pill */}
        <div className="hidden md:flex items-center gap-space-xs bg-surface-container-low px-space-sm py-1 rounded-full text-on-surface">
          <span className="material-symbols-outlined text-primary text-[16px]">calendar_today</span>
          <span className="font-label-sm text-label-sm font-medium">Today, {todayFormatted}</span>
        </div>

        {/* Reconcile Button */}
        <button
          onClick={openReconcileModal}
          type="button"
          className="h-8 px-2.5 sm:px-3 rounded-full bg-surface-container-low hover:bg-surface-container text-on-surface font-label-sm text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-2xs border border-surface-container-high/50"
          title="Open Reconciliation & Ledger Audit Center"
        >
          <span className="material-symbols-outlined text-[16px] text-tertiary">verified_user</span>
          <span className="hidden sm:inline">Reconcile</span>
        </button>

        {/* Notifications */}
        <button
          className="relative p-2 text-on-surface-variant hover:text-on-surface hover:bg-surface-container-low transition-colors rounded-lg"
          type="button"
          onClick={() => setActiveTab('inventory')}
          title={lowStockCount > 0 ? `${lowStockCount} items low on stock` : 'Notifications'}
        >
          <span className="material-symbols-outlined text-[22px]">notifications</span>
          {lowStockCount > 0 && (
            <span className="absolute top-1.5 right-1.5 min-w-[16px] h-4 px-1 rounded-full bg-error text-on-error font-bold text-[9px] flex items-center justify-center">
              {lowStockCount}
            </span>
          )}
        </button>

        {/* Profile Card */}
        <div className="flex items-center gap-space-xs sm:gap-space-sm bg-surface-container-low py-1 px-1.5 sm:px-space-sm rounded-full">
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center shrink-0 shadow-xs">
            <span className="material-symbols-outlined text-on-primary text-[18px]">person</span>
          </div>
          <div className="hidden lg:flex flex-col pr-space-xs text-left">
            <span className="font-label-md text-label-md font-semibold text-on-surface leading-tight truncate max-w-[130px]">
              {settings.businessName || 'Tariq Oil Traders'}
            </span>
            <span className="font-label-sm text-label-sm text-on-surface-variant leading-none">Cash &amp; Accounts</span>
          </div>
        </div>
      </div>
    </header>
  );
};
