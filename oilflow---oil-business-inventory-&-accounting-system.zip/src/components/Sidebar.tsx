import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { NavTab, TransactionType } from '../types';

export const Sidebar: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    openTransactionModal,
    openTransferModal,
    openJournalModal,
    settings,
    lowStockCount,
    isMobileMenuOpen,
    setIsMobileMenuOpen,
  } = useApp();

  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navItems: { tab: NavTab; label: string; icon: string; badge?: number }[] = [
    { tab: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
    { tab: 'inventory', label: 'Inventory', icon: 'inventory_2', badge: lowStockCount },
    { tab: 'transactions', label: 'Transactions', icon: 'swap_horiz' },
    { tab: 'parties', label: 'Parties', icon: 'group' },
    { tab: 'accounts-ledgers', label: 'Accounts & Ledgers', icon: 'account_balance' },
    { tab: 'profit-loss', label: 'Profit & Loss Statement', icon: 'trending_up' },
    { tab: 'expenses', label: 'Expense Heads', icon: 'receipt_long' },
    { tab: 'settings', label: 'Settings', icon: 'settings' },
  ];

  const handleQuickAction = (type: TransactionType) => {
    setDropdownOpen(false);
    if (type === 'Transfer') {
      openTransferModal();
    } else {
      openTransactionModal(type);
    }
  };

  const sidebarContent = (
    <div className="flex flex-col justify-between h-full">
      <div className="flex flex-col">
        {/* Brand Header */}
        <div className="h-16 px-space-md flex items-center justify-between gap-space-sm bg-surface-container-lowest border-b border-surface-container-low/60">
          <div className="flex items-center gap-space-sm cursor-pointer" onClick={() => setActiveTab('dashboard')}>
            <div className="w-8 h-8 rounded-lg bg-primary-container text-on-primary flex items-center justify-center shrink-0 shadow-sm">
              <span className="material-symbols-outlined text-[20px]">business_center</span>
            </div>
            <div className="flex flex-col">
              <span className="font-headline-sm text-headline-sm text-on-surface leading-tight font-semibold">
                BizFlow
              </span>
              <span className="font-label-sm text-label-sm text-on-surface-variant leading-none">
                Inventory &amp; Accounts
              </span>
            </div>
          </div>
          {/* Close for mobile drawer */}
          <button
            onClick={() => setIsMobileMenuOpen(false)}
            className="lg:hidden p-1 rounded-lg text-on-surface-variant hover:text-on-surface"
          >
            <span className="material-symbols-outlined text-[22px]">close</span>
          </button>
        </div>

        {/* Primary New Transaction Trigger with Dropdown */}
        <div className="px-space-md py-space-sm relative" ref={dropdownRef}>
          <button
            className="w-full h-10 px-space-md bg-primary-container text-on-primary rounded-lg flex items-center justify-between shadow-sm hover:bg-primary active:scale-[0.99] transition-all"
            type="button"
            onClick={() => setDropdownOpen(!dropdownOpen)}
          >
            <div className="flex items-center gap-space-xs">
              <span className="material-symbols-outlined text-[20px]">add</span>
              <span className="font-label-md text-label-md font-semibold">New Transaction</span>
            </div>
            <span className={`material-symbols-outlined text-[18px] transition-transform duration-200 ${dropdownOpen ? 'rotate-180' : ''}`}>
              expand_more
            </span>
          </button>

          {/* Quick Dropdown Menu */}
          {dropdownOpen && (
            <div className="absolute left-space-md right-space-md mt-1.5 bg-surface-container-lowest rounded-xl shadow-xl border border-surface-container-high py-1.5 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
              <button
                type="button"
                onClick={() => handleQuickAction('Sale')}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-left hover:bg-surface-container-low transition-colors group"
              >
                <div className="w-7 h-7 rounded-lg bg-primary-container/10 text-primary flex items-center justify-center">
                  <span className="material-symbols-outlined text-[18px]">point_of_sale</span>
                </div>
                <div>
                  <p className="font-headline-sm text-[13px] font-semibold text-on-surface">New Sale</p>
                  <p className="text-on-surface-variant text-[11px]">Customer invoice / cash</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleQuickAction('Purchase')}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-left hover:bg-surface-container-low transition-colors group"
              >
                <div className="w-7 h-7 rounded-lg bg-secondary-container text-on-secondary-fixed flex items-center justify-center">
                  <span className="material-symbols-outlined text-[18px]">shopping_cart</span>
                </div>
                <div>
                  <p className="font-headline-sm text-[13px] font-semibold text-on-surface">New Purchase</p>
                  <p className="text-on-surface-variant text-[11px]">Stock in, supplier bill</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleQuickAction('Receive')}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-left hover:bg-surface-container-low transition-colors group"
              >
                <div className="w-7 h-7 rounded-lg bg-tertiary-fixed text-on-tertiary-fixed flex items-center justify-center">
                  <span className="material-symbols-outlined text-[18px]">input</span>
                </div>
                <div>
                  <p className="font-headline-sm text-[13px] font-semibold text-on-surface">Receive Money</p>
                  <p className="text-on-surface-variant text-[11px]">Customer recovery</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleQuickAction('Pay')}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-left hover:bg-surface-container-low transition-colors group"
              >
                <div className="w-7 h-7 rounded-lg bg-error-container text-on-error-container flex items-center justify-center">
                  <span className="material-symbols-outlined text-[18px]">output</span>
                </div>
                <div>
                  <p className="font-headline-sm text-[13px] font-semibold text-on-surface">Pay Money</p>
                  <p className="text-on-surface-variant text-[11px]">Supplier payout / exp</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleQuickAction('Transfer')}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-left hover:bg-surface-container-low transition-colors group border-t border-surface-container-low mt-1 pt-1.5"
              >
                <div className="w-7 h-7 rounded-lg bg-surface-container text-primary flex items-center justify-center">
                  <span className="material-symbols-outlined text-[18px]">sync_alt</span>
                </div>
                <div>
                  <p className="font-headline-sm text-[13px] font-semibold text-on-surface">Transfer Money</p>
                  <p className="text-on-surface-variant text-[11px]">Vault &lt;-&gt; Bank</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setDropdownOpen(false);
                  openJournalModal('Out');
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-left hover:bg-surface-container-low transition-colors group border-t border-surface-container-low mt-1 pt-1.5"
              >
                <div className="w-7 h-7 rounded-lg bg-error-container/20 text-error flex items-center justify-center">
                  <span className="material-symbols-outlined text-[18px]">receipt_long</span>
                </div>
                <div>
                  <p className="font-headline-sm text-[13px] font-semibold text-on-surface">Expense Voucher (JV Out)</p>
                  <p className="text-on-surface-variant text-[11px]">Rent, bills, labor, diesel payout</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setDropdownOpen(false);
                  openJournalModal();
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-left hover:bg-surface-container-low transition-colors group"
              >
                <div className="w-7 h-7 rounded-lg bg-primary-container/20 text-primary flex items-center justify-center">
                  <span className="material-symbols-outlined text-[18px]">edit_note</span>
                </div>
                <div>
                  <p className="font-headline-sm text-[13px] font-semibold text-on-surface">Journal Entry</p>
                  <p className="text-on-surface-variant text-[11px]">Direct In / Out journal entry</p>
                </div>
              </button>
            </div>
          )}
        </div>

        {/* Navigation Items */}
        <nav className="flex flex-col gap-1 px-space-md mt-space-xs">
          {navItems.map((item) => {
            const isActive = activeTab === item.tab;
            return (
              <button
                key={item.tab}
                type="button"
                onClick={() => {
                  setActiveTab(item.tab);
                  setIsMobileMenuOpen(false);
                }}
                className={`flex items-center justify-between px-space-sm py-2.5 rounded-lg text-left transition-colors ${
                  isActive
                    ? 'bg-secondary-container text-on-secondary-fixed font-semibold shadow-xs'
                    : 'text-on-surface-variant hover:bg-surface-container-low hover:text-on-surface'
                }`}
              >
                <div className="flex items-center gap-space-sm min-w-0">
                  <span
                    className={`material-symbols-outlined text-[20px] ${
                      isActive ? 'text-primary' : 'text-on-surface-variant'
                    }`}
                  >
                    {item.icon}
                  </span>
                  <span className="font-body-md text-body-md truncate">{item.label}</span>
                </div>
                {item.badge && item.badge > 0 ? (
                  <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-error-container text-on-error-container">
                    {item.badge}
                  </span>
                ) : null}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Depot Profile */}
      <div className="p-space-md bg-surface-container-low border-t border-surface-container-high/40">
        <div className="flex items-center gap-space-xs text-on-surface-variant mb-space-xs">
          <span className="material-symbols-outlined text-[16px] text-primary">storefront</span>
          <span className="font-label-sm text-label-sm uppercase tracking-wider font-semibold text-on-surface truncate">
            {settings.depotName || 'Lahore Main Depot'}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex flex-col min-w-0">
            <span className="font-body-sm text-body-sm font-semibold text-on-surface truncate">
              {settings.ownerName || 'Muhammad Tariq'}
            </span>
            <span className="font-label-sm text-label-sm text-on-surface-variant">Owner / Admin</span>
          </div>
          <span className="material-symbols-outlined text-[18px] text-tertiary" title="Verified business terminal">
            verified
          </span>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden lg:flex fixed left-0 top-0 h-full w-[240px] bg-surface-container-lowest z-40 flex-col justify-between shadow-[0_1px_8px_rgba(0,0,0,0.04)] border-r border-surface-container-high/40">
        {sidebarContent}
      </aside>

      {/* Mobile Slide-Out Drawer */}
      {isMobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-inverse-surface/40 backdrop-blur-sm transition-opacity"
            onClick={() => setIsMobileMenuOpen(false)}
          />
          <div className="relative w-[280px] max-w-[80vw] bg-surface-container-lowest h-full shadow-2xl flex flex-col z-50">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
