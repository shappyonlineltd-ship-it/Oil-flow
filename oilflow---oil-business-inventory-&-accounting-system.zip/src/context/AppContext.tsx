import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  Product,
  Party,
  Account,
  Transaction,
  LedgerEntry,
  AppSettings,
  NavTab,
  ExpenseHead,
  ReconciliationReport,
  AccountReconciliationItem,
  PartyReconciliationItem,
  StockReconciliationItem,
} from '../types';
import {
  INITIAL_PRODUCTS,
  INITIAL_PARTIES,
  INITIAL_ACCOUNTS,
  INITIAL_TRANSACTIONS,
  INITIAL_SETTINGS,
  INITIAL_EXPENSE_HEADS,
} from '../data/initialData';
import { generateTransactionPDF } from '../utils/pdfGenerator';

interface AppContextType {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  isMobileMenuOpen: boolean;
  setIsMobileMenuOpen: (open: boolean) => void;

  pdfPreviewTransaction?: Transaction | null;
  openPdfPreview: (tx: Transaction) => void;
  closePdfPreview: () => void;
  downloadTransactionPdf: (tx: Transaction) => void;
  
  // Data entities
  products: Product[];
  parties: Party[];
  accounts: Account[];
  transactions: Transaction[];
  ledgerEntries: LedgerEntry[];
  settings: AppSettings;
  expenseHeads: ExpenseHead[];
  
  // Modals state
  transactionModalOpen: boolean;
  transactionModalInitialType?: Transaction['type'];
  transactionModalInitialProduct?: string;
  transactionModalInitialPartyId?: string;
  openTransactionModal: (type?: Transaction['type'], product?: string, partyId?: string) => void;
  closeTransactionModal: () => void;
  
  productDrawerOpen: boolean;
  editingProduct?: Product | null;
  openProductDrawer: (product?: Product) => void;
  closeProductDrawer: () => void;
  
  partyModalOpen: boolean;
  editingParty?: Party | null;
  openPartyModal: (party?: Party) => void;
  closePartyModal: () => void;
  
  viewingTransaction?: Transaction | null;
  openViewTransactionModal: (tx: Transaction) => void;
  closeViewTransactionModal: () => void;
  
  editingTransaction?: Transaction | null;
  openEditTransactionModal: (tx: Transaction) => void;
  closeEditTransactionModal: () => void;
  
  transferModalOpen: boolean;
  openTransferModal: () => void;
  closeTransferModal: () => void;

  journalModalOpen: boolean;
  journalModalInitialType?: 'In' | 'Out';
  journalModalInitialExpenseHeadId?: string;
  openJournalModal: (initialType?: 'In' | 'Out', initialExpenseHeadId?: string) => void;
  closeJournalModal: () => void;

  viewingPartyLedgerId?: string | null;
  openPartyLedgerModal: (partyId: string) => void;
  closePartyLedgerModal: () => void;

  viewingAccountLedgerId?: string | null;
  openAccountLedgerModal: (accountId: string) => void;
  closeAccountLedgerModal: () => void;

  viewingProductLedgerId?: string | null;
  openProductLedgerModal: (productId: string) => void;
  closeProductLedgerModal: () => void;

  reconcileModalOpen: boolean;
  openReconcileModal: () => void;
  closeReconcileModal: () => void;
  getReconciliationAudit: () => ReconciliationReport;
  reconcileAll: () => ReconciliationReport;

  // Actions
  addProduct: (product: Omit<Product, 'id' | 'createdAt'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  adjustStock: (id: string, newStock: number, reason?: string) => void;
  
  addParty: (party: Omit<Party, 'id' | 'createdAt'>) => void;
  updateParty: (id: string, party: Partial<Party>) => void;
  deleteParty: (id: string) => void;
  
  addAccount: (account: Omit<Account, 'id'>) => void;
  updateAccount: (id: string, account: Partial<Account>) => void;
  deleteAccount: (id: string) => { success: boolean; message?: string };
  reconcileAccountBalances: () => void;

  addExpenseHead: (head: Omit<ExpenseHead, 'id' | 'createdAt'>) => ExpenseHead;
  updateExpenseHead: (id: string, updated: Partial<ExpenseHead>) => void;
  deleteExpenseHead: (id: string) => void;
  getExpenseHeadSpending: (headId: string) => number;
  
  createTransaction: (data: Omit<Transaction, 'id' | 'docNumber' | 'createdAt'> & { docNumber?: string }) => Transaction;
  updateTransaction: (id: string, data: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
  
  updateSettings: (newSettings: Partial<AppSettings>) => void;

  // Calculated Metrics
  totalCash: number;
  totalBank: number;
  totalStockUnits: number;
  totalStockVolumeLiters: number;
  totalStockValue: number;
  totalCustomerReceivables: number;
  totalSupplierPayables: number;
  totalExpensesAllTime: number;
  todayExpenses: number;
  todayCashIn: number;
  todayCashOut: number;
  todayNetCash: number;
  lowStockCount: number;
  formatCurrency: (amount: number) => string;
  resetAllData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  PRODUCTS: 'oilflow_products_clean',
  PARTIES: 'oilflow_parties_clean',
  ACCOUNTS: 'oilflow_accounts_clean',
  TRANSACTIONS: 'oilflow_transactions_clean',
  LEDGER: 'oilflow_ledger_clean',
  SETTINGS: 'oilflow_settings_clean',
  EXPENSE_HEADS: 'oilflow_expense_heads_clean',
};

// Purge any legacy sample data keys
if (typeof window !== 'undefined') {
  try {
    ['oilflow_products_v1', 'oilflow_parties_v1', 'oilflow_accounts_v1', 'oilflow_transactions_v1', 'oilflow_ledger_v1'].forEach((k) => {
      localStorage.removeItem(k);
    });
  } catch {
    // ignore
  }
}

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Load state from local storage or defaults
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  const [parties, setParties] = useState<Party[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PARTIES);
      return saved ? JSON.parse(saved) : INITIAL_PARTIES;
    } catch {
      return INITIAL_PARTIES;
    }
  });

  const [accounts, setAccounts] = useState<Account[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ACCOUNTS);
      return saved ? JSON.parse(saved) : INITIAL_ACCOUNTS;
    } catch {
      return INITIAL_ACCOUNTS;
    }
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
      if (saved) {
        const parsed: Transaction[] = JSON.parse(saved);
        // Accounting fix: If non-transfer transaction has no paidAmount (unpaid/credit), ensure no account is linked
        return parsed.map((t) => {
          if (t.type !== 'Transfer' && (!t.paidAmount || t.paidAmount <= 0)) {
            return { ...t, accountId: undefined, accountName: undefined };
          }
          return t;
        });
      }
      return INITIAL_TRANSACTIONS;
    } catch {
      return INITIAL_TRANSACTIONS;
    }
  });

  const [ledgerEntries, setLedgerEntries] = useState<LedgerEntry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.LEDGER);
      if (saved) return JSON.parse(saved);
      // Auto generate from initial transactions if empty
      return [];
    } catch {
      return [];
    }
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
    } catch {
      return INITIAL_SETTINGS;
    }
  });

  const [expenseHeads, setExpenseHeads] = useState<ExpenseHead[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.EXPENSE_HEADS);
      if (saved) {
        const parsed: ExpenseHead[] = JSON.parse(saved);
        const legacyDefaultIds = [
          'exp-rent', 'exp-elec', 'exp-fuel', 'exp-labor', 'exp-transport',
          'exp-tea', 'exp-salary', 'exp-maint', 'exp-packing', 'exp-misc'
        ];
        return parsed.filter((h) => !legacyDefaultIds.includes(h.id));
      }
      return INITIAL_EXPENSE_HEADS;
    } catch {
      return INITIAL_EXPENSE_HEADS;
    }
  });

  // Modal states
  const [transactionModalOpen, setTransactionModalOpen] = useState(false);
  const [transactionModalInitialType, setTransactionModalInitialType] = useState<Transaction['type'] | undefined>();
  const [transactionModalInitialProduct, setTransactionModalInitialProduct] = useState<string | undefined>();
  const [transactionModalInitialPartyId, setTransactionModalInitialPartyId] = useState<string | undefined>();

  const [productDrawerOpen, setProductDrawerOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  const [partyModalOpen, setPartyModalOpen] = useState(false);
  const [editingParty, setEditingParty] = useState<Party | null>(null);

  const [viewingTransaction, setViewingTransaction] = useState<Transaction | null>(null);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);

  const [transferModalOpen, setTransferModalOpen] = useState(false);
  const [journalModalOpen, setJournalModalOpen] = useState(false);
  const [journalModalInitialType, setJournalModalInitialType] = useState<'In' | 'Out'>('In');
  const [journalModalInitialExpenseHeadId, setJournalModalInitialExpenseHeadId] = useState<string | undefined>(undefined);
  const [viewingPartyLedgerId, setViewingPartyLedgerId] = useState<string | null>(null);
  const [viewingAccountLedgerId, setViewingAccountLedgerId] = useState<string | null>(null);
  const [viewingProductLedgerId, setViewingProductLedgerId] = useState<string | null>(null);
  const [reconcileModalOpen, setReconcileModalOpen] = useState(false);
  const [pdfPreviewTransaction, setPdfPreviewTransaction] = useState<Transaction | null>(null);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PARTIES, JSON.stringify(parties));
  }, [parties]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(accounts));
  }, [accounts]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LEDGER, JSON.stringify(ledgerEntries));
  }, [ledgerEntries]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.EXPENSE_HEADS, JSON.stringify(expenseHeads));
  }, [expenseHeads]);

  // Modal helpers
  const openTransactionModal = (type?: Transaction['type'], product?: string, partyId?: string) => {
    setTransactionModalInitialType(type || 'Sale');
    setTransactionModalInitialProduct(product);
    setTransactionModalInitialPartyId(partyId);
    setTransactionModalOpen(true);
  };

  const closeTransactionModal = () => {
    setTransactionModalOpen(false);
    setTransactionModalInitialType(undefined);
    setTransactionModalInitialProduct(undefined);
    setTransactionModalInitialPartyId(undefined);
  };

  const openProductDrawer = (product?: Product) => {
    setEditingProduct(product || null);
    setProductDrawerOpen(true);
  };

  const closeProductDrawer = () => {
    setEditingProduct(null);
    setProductDrawerOpen(false);
  };

  const openPartyModal = (party?: Party) => {
    setEditingParty(party || null);
    setPartyModalOpen(true);
  };

  const closePartyModal = () => {
    setEditingParty(null);
    setPartyModalOpen(false);
  };

  const openViewTransactionModal = (tx: Transaction) => {
    setViewingTransaction(tx);
  };

  const closeViewTransactionModal = () => {
    setViewingTransaction(null);
  };

  const openPdfPreview = (tx: Transaction) => {
    setPdfPreviewTransaction(tx);
  };

  const closePdfPreview = () => {
    setPdfPreviewTransaction(null);
  };

  const downloadTransactionPdf = (tx: Transaction) => {
    const pty = parties.find((p) => p.id === tx.partyId);
    const acc = accounts.find((a) => a.id === tx.accountId);
    generateTransactionPDF(tx, settings, pty, acc, 'download');
  };

  const openEditTransactionModal = (tx: Transaction) => {
    setEditingTransaction(tx);
  };

  const closeEditTransactionModal = () => {
    setEditingTransaction(null);
  };

  const openTransferModal = () => {
    setTransferModalOpen(true);
  };

  const closeTransferModal = () => {
    setTransferModalOpen(false);
  };

  const openJournalModal = (initialType: 'In' | 'Out' = 'In', initialExpenseHeadId?: string) => {
    setJournalModalInitialType(initialType);
    setJournalModalInitialExpenseHeadId(initialExpenseHeadId);
    setJournalModalOpen(true);
  };

  const closeJournalModal = () => {
    setJournalModalOpen(false);
    setJournalModalInitialExpenseHeadId(undefined);
  };

  const openPartyLedgerModal = (partyId: string) => {
    setViewingPartyLedgerId(partyId);
    setActiveTab('parties');
  };

  const closePartyLedgerModal = () => {
    setViewingPartyLedgerId(null);
  };

  const openAccountLedgerModal = (accountId: string) => {
    setViewingAccountLedgerId(accountId);
    setActiveTab('accounts-ledgers');
  };

  const closeAccountLedgerModal = () => {
    setViewingAccountLedgerId(null);
  };

  const openProductLedgerModal = (productId: string) => {
    setViewingProductLedgerId(productId);
    setActiveTab('inventory');
  };

  const closeProductLedgerModal = () => {
    setViewingProductLedgerId(null);
  };

  const openReconcileModal = () => {
    setReconcileModalOpen(true);
  };

  const closeReconcileModal = () => {
    setReconcileModalOpen(false);
  };

  // Currency Formatter
  const formatCurrency = (amount: number): string => {
    const formatted = Math.abs(amount).toLocaleString('en-PK', {
      maximumFractionDigits: 0,
    });
    const prefix = amount < 0 ? '-Rs. ' : 'Rs. ';
    return `${prefix}${formatted}`;
  };

  // Accounting calculations
  const totalCash = useMemo(() => {
    return accounts
      .filter((a) => a.type === 'Cash')
      .reduce((sum, a) => sum + a.balance, 0);
  }, [accounts]);

  const totalBank = useMemo(() => {
    return accounts
      .filter((a) => a.type === 'Bank')
      .reduce((sum, a) => sum + a.balance, 0);
  }, [accounts]);

  const totalStockUnits = useMemo(() => {
    return products.reduce((sum, p) => sum + p.currentStock, 0);
  }, [products]);

  const totalStockVolumeLiters = useMemo(() => {
    return products.reduce((sum, p) => sum + (p.currentStock * p.packingSize), 0);
  }, [products]);

  const totalStockValue = useMemo(() => {
    return products.reduce((sum, p) => sum + (p.currentStock * p.purchaseCost), 0);
  }, [products]);

  const totalCustomerReceivables = useMemo(() => {
    return parties
      .filter((p) => p.currentBalance > 0)
      .reduce((sum, p) => sum + p.currentBalance, 0);
  }, [parties]);

  const totalSupplierPayables = useMemo(() => {
    return parties
      .filter((p) => p.currentBalance < 0)
      .reduce((sum, p) => sum + Math.abs(p.currentBalance), 0);
  }, [parties]);

  // Total Expenses (All-time and Today)
  const totalExpensesAllTime = useMemo(() => {
    return transactions
      .filter((t) => t.type === 'Pay' && (t.expenseHeadId || t.expenseHeadName))
      .reduce((sum, t) => sum + (t.paidAmount || t.totalAmount || 0), 0);
  }, [transactions]);

  const todayDateStr = new Date().toISOString().slice(0, 10);

  const todayExpenses = useMemo(() => {
    return transactions
      .filter(
        (t) =>
          t.date === todayDateStr &&
          t.type === 'Pay' &&
          (t.expenseHeadId || t.expenseHeadName)
      )
      .reduce((sum, t) => sum + (t.paidAmount || t.totalAmount || 0), 0);
  }, [transactions, todayDateStr]);

  const getExpenseHeadSpending = (headId: string): number => {
    return transactions
      .filter((t) => t.type === 'Pay' && t.expenseHeadId === headId)
      .reduce((sum, t) => sum + (t.paidAmount || t.totalAmount || 0), 0);
  };

  // Today's Cash In & Out
  const { todayCashIn, todayCashOut, todayNetCash } = useMemo(() => {
    let inAmount = 0;
    let outAmount = 0;

    transactions.forEach((tx) => {
      if (tx.date === todayDateStr) {
        const isCashAccount = tx.accountName?.toLowerCase().includes('cash');
        if (isCashAccount) {
          if (tx.type === 'Sale' || tx.type === 'Receive') {
            inAmount += tx.paidAmount;
          } else if (tx.type === 'Purchase' || tx.type === 'Pay') {
            outAmount += tx.paidAmount;
          }
        }
      }
    });

    return {
      todayCashIn: inAmount,
      todayCashOut: outAmount,
      todayNetCash: inAmount - outAmount,
    };
  }, [transactions, todayDateStr]);

  const lowStockCount = useMemo(() => {
    return products.filter((p) => p.currentStock <= p.minAlertThreshold).length;
  }, [products]);

  // ==========================================
  // TRANSACTION CREATION (STRICT ACCOUNTING LOGIC)
  // ==========================================
  const createTransaction = (data: Omit<Transaction, 'id' | 'docNumber' | 'createdAt'> & { docNumber?: string }): Transaction => {
    const timestamp = new Date();
    const id = 'tx-' + Date.now();
    
    // Generate Document Number
    const prefixMap: Record<Transaction['type'], string> = {
      Sale: 'INV-2024-',
      Purchase: 'BILL-',
      Receive: 'REC-',
      Pay: 'PAY-',
      Transfer: 'TRF-',
    };
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const docNumber = data.docNumber || `${prefixMap[data.type]}${randomSuffix}`;

    // If it's not a transfer and there's no actual cash/bank payment, do not attach an account
    const hasActualPayment = data.type === 'Transfer' || ((data.paidAmount || 0) > 0);
    const effectiveAccountId = hasActualPayment ? data.accountId : undefined;
    const effectiveAccountName = hasActualPayment ? data.accountName : undefined;

    const newTx: Transaction = {
      ...data,
      id,
      docNumber,
      accountId: effectiveAccountId,
      accountName: effectiveAccountName,
      createdAt: timestamp.toISOString(),
    };

    // 1. UPDATE PRODUCTS STOCK
    if (data.type === 'Purchase') {
      setProducts((prev) =>
        prev.map((p) => {
          const matchedItem = data.items.find((item) => item.productId === p.id);
          if (matchedItem) {
            return {
              ...p,
              currentStock: p.currentStock + matchedItem.quantity,
              // Update purchase cost if manually provided
              purchaseCost: matchedItem.unitPrice || p.purchaseCost,
            };
          }
          return p;
        })
      );
    } else if (data.type === 'Sale') {
      setProducts((prev) =>
        prev.map((p) => {
          const matchedItem = data.items.find((item) => item.productId === p.id);
          if (matchedItem) {
            return {
              ...p,
              currentStock: Math.max(0, p.currentStock - matchedItem.quantity),
            };
          }
          return p;
        })
      );
    }

    // 2. UPDATE CASH/BANK ACCOUNTS (Only when money actually moves)
    if (data.type === 'Transfer') {
      setAccounts((prev) =>
        prev.map((acc) => {
          if (acc.id === data.accountId) {
            // Source account decreases
            return { ...acc, balance: acc.balance - data.totalAmount };
          }
          if (acc.id === data.toAccountId) {
            // Destination account increases
            return { ...acc, balance: acc.balance + data.totalAmount };
          }
          return acc;
        })
      );
    } else if (effectiveAccountId && (data.paidAmount || 0) > 0) {
      setAccounts((prev) =>
        prev.map((acc) => {
          if (acc.id === effectiveAccountId) {
            if (data.type === 'Purchase' || data.type === 'Pay') {
              // Outflow: decrease account balance by paidAmount
              return { ...acc, balance: acc.balance - data.paidAmount };
            } else if (data.type === 'Sale' || data.type === 'Receive') {
              // Inflow: increase account balance by paidAmount
              return { ...acc, balance: acc.balance + data.paidAmount };
            }
          }
          return acc;
        })
      );
    }

    // 3. UPDATE PARTY RECEIVABLE / PAYABLE BALANCES
    if (data.partyId) {
      setParties((prev) =>
        prev.map((pty) => {
          if (pty.id !== data.partyId) return pty;

          if (data.type === 'Purchase') {
            // Unpaid balance increases supplier payable (makes balance more negative)
            const unpaidAmount = data.balanceDue || (data.totalAmount - data.paidAmount);
            return {
              ...pty,
              currentBalance: pty.currentBalance - unpaidAmount,
            };
          } else if (data.type === 'Sale') {
            // Unpaid balance increases customer receivable (makes balance more positive)
            const unpaidAmount = data.balanceDue || (data.totalAmount - data.paidAmount);
            return {
              ...pty,
              currentBalance: pty.currentBalance + unpaidAmount,
            };
          } else if (data.type === 'Receive') {
            // Customer payment: decreases customer receivable
            return {
              ...pty,
              currentBalance: pty.currentBalance - data.paidAmount,
            };
          } else if (data.type === 'Pay') {
            // Supplier payment: decreases supplier payable (moves balance closer to 0 or positive)
            return {
              ...pty,
              currentBalance: pty.currentBalance + data.paidAmount,
            };
          }
          return pty;
        })
      );
    }

    // 4. RECORD LEDGER ENTRIES
    const newEntries: LedgerEntry[] = [];
    if (data.partyId) {
      newEntries.push({
        id: 'led-' + Date.now() + '-p',
        transactionId: id,
        docNumber,
        date: data.date,
        partyId: data.partyId,
        partyName: data.partyName,
        accountId: effectiveAccountId,
        accountName: effectiveAccountName,
        type: data.type,
        description: data.notes || `${data.type} document ${docNumber}`,
        debit: data.type === 'Sale' || data.type === 'Pay' ? data.totalAmount : 0,
        credit: data.type === 'Purchase' || data.type === 'Receive' ? data.totalAmount : 0,
        balanceAfter: 0, // Calculated dynamically in Party Ledger
      });
    }

    // Account ledger entry - ONLY when actual money moved through this specific account!
    if (effectiveAccountId && (data.paidAmount || 0) > 0) {
      const desc = data.expenseHeadName
        ? `Expense: ${data.expenseHeadName}${data.notes ? ` - ${data.notes}` : ''}`
        : `${data.type}: ${data.partyName || docNumber}`;

      newEntries.push({
        id: 'led-' + Date.now() + '-a',
        transactionId: id,
        docNumber,
        date: data.date,
        partyId: data.partyId,
        partyName: data.partyName,
        expenseHeadId: data.expenseHeadId,
        expenseHeadName: data.expenseHeadName,
        accountId: effectiveAccountId,
        accountName: effectiveAccountName,
        type: data.type,
        description: desc,
        debit: data.type === 'Sale' || data.type === 'Receive' ? data.paidAmount : 0,
        credit: data.type === 'Purchase' || data.type === 'Pay' ? data.paidAmount : 0,
        balanceAfter: 0,
      });
    }

    setTransactions((prev) => [newTx, ...prev]);
    if (newEntries.length > 0) {
      setLedgerEntries((prev) => [...newEntries, ...prev]);
    }

    return newTx;
  };

  // ==========================================
  // TRANSACTION DELETION (FULL EFFECT REVERSAL)
  // ==========================================
  const deleteTransaction = (id: string) => {
    const tx = transactions.find((t) => t.id === id);
    if (!tx) return;

    // 1. REVERSE PRODUCT STOCK
    if (tx.type === 'Purchase') {
      setProducts((prev) =>
        prev.map((p) => {
          const item = tx.items.find((i) => i.productId === p.id);
          if (item) {
            return {
              ...p,
              currentStock: Math.max(0, p.currentStock - item.quantity),
            };
          }
          return p;
        })
      );
    } else if (tx.type === 'Sale') {
      setProducts((prev) =>
        prev.map((p) => {
          const item = tx.items.find((i) => i.productId === p.id);
          if (item) {
            return {
              ...p,
              currentStock: p.currentStock + item.quantity,
            };
          }
          return p;
        })
      );
    }

    // 2. REVERSE ACCOUNT BALANCES
    setAccounts((prev) =>
      prev.map((acc) => {
        if (tx.type === 'Transfer') {
          if (acc.id === tx.accountId) {
            // Restore source account
            return { ...acc, balance: acc.balance + tx.totalAmount };
          }
          if (acc.id === tx.toAccountId) {
            // Revert destination account
            return { ...acc, balance: acc.balance - tx.totalAmount };
          }
        } else if (acc.id === tx.accountId && (tx.paidAmount || 0) > 0) {
          if (tx.type === 'Purchase' || tx.type === 'Pay') {
            // Re-credit what was paid
            return { ...acc, balance: acc.balance + tx.paidAmount };
          } else if (tx.type === 'Sale' || tx.type === 'Receive') {
            // Re-debit what was received
            return { ...acc, balance: acc.balance - tx.paidAmount };
          }
        }
        return acc;
      })
    );

    // 3. REVERSE PARTY BALANCES
    if (tx.partyId) {
      setParties((prev) =>
        prev.map((pty) => {
          if (pty.id !== tx.partyId) return pty;

          if (tx.type === 'Purchase') {
            // Remove unpaid amount from supplier payable
            const unpaidAmount = tx.balanceDue || (tx.totalAmount - tx.paidAmount);
            return { ...pty, currentBalance: pty.currentBalance + unpaidAmount };
          } else if (tx.type === 'Sale') {
            // Remove unpaid amount from customer receivable
            const unpaidAmount = tx.balanceDue || (tx.totalAmount - tx.paidAmount);
            return { ...pty, currentBalance: pty.currentBalance - unpaidAmount };
          } else if (tx.type === 'Receive') {
            // Restore receivable
            return { ...pty, currentBalance: pty.currentBalance + tx.paidAmount };
          } else if (tx.type === 'Pay') {
            // Restore payable
            return { ...pty, currentBalance: pty.currentBalance - tx.paidAmount };
          }
          return pty;
        })
      );
    }

    // 4. REMOVE LEDGER ENTRIES AND TRANSACTION
    setTransactions((prev) => prev.filter((t) => t.id !== id));
    setLedgerEntries((prev) => prev.filter((l) => l.transactionId !== id));

    if (viewingTransaction?.id === id) {
      setViewingTransaction(null);
    }
  };

  // ==========================================
  // TRANSACTION EDITING (REVERSE OLD + APPLY NEW)
  // ==========================================
  const updateTransaction = (id: string, updatedData: Partial<Transaction>) => {
    const existing = transactions.find((t) => t.id === id);
    if (!existing) return;

    // Delete existing to reverse effects
    deleteTransaction(id);

    // Recreate with updated data, preserving original docNumber and id
    const merged: Omit<Transaction, 'id' | 'docNumber' | 'createdAt'> = {
      type: updatedData.type || existing.type,
      date: updatedData.date || existing.date,
      time: updatedData.time || existing.time,
      partyId: updatedData.partyId ?? existing.partyId,
      partyName: updatedData.partyName ?? existing.partyName,
      accountId: updatedData.accountId ?? existing.accountId,
      accountName: updatedData.accountName ?? existing.accountName,
      toAccountId: updatedData.toAccountId ?? existing.toAccountId,
      toAccountName: updatedData.toAccountName ?? existing.toAccountName,
      items: updatedData.items || existing.items,
      totalAmount: updatedData.totalAmount !== undefined ? updatedData.totalAmount : existing.totalAmount,
      paidAmount: updatedData.paidAmount !== undefined ? updatedData.paidAmount : existing.paidAmount,
      balanceDue: updatedData.balanceDue !== undefined ? updatedData.balanceDue : existing.balanceDue,
      paymentStatus: updatedData.paymentStatus || existing.paymentStatus,
      notes: updatedData.notes ?? existing.notes,
    };

    const newTx = createTransaction(merged);
    // Overwrite the newly generated docNumber and id with the original ones
    setTransactions((prev) =>
      prev.map((t) => (t.id === newTx.id ? { ...t, id: existing.id, docNumber: existing.docNumber } : t))
    );
    setLedgerEntries((prev) =>
      prev.map((l) => (l.transactionId === newTx.id ? { ...l, transactionId: existing.id, docNumber: existing.docNumber } : l))
    );
  };

  // Product CRUD
  const addProduct = (product: Omit<Product, 'id' | 'createdAt'>) => {
    const newProd: Product = {
      ...product,
      id: 'prod-' + Date.now(),
      createdAt: new Date().toISOString().slice(0, 10),
    };
    setProducts((prev) => [newProd, ...prev]);
  };

  const updateProduct = (id: string, updated: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updated } : p))
    );
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  const adjustStock = (id: string, newStock: number) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, currentStock: Math.max(0, newStock) } : p))
    );
  };

  // Party CRUD
  const addParty = (party: Omit<Party, 'id' | 'createdAt'>) => {
    const newParty: Party = {
      ...party,
      id: 'party-' + Date.now(),
      createdAt: new Date().toISOString().slice(0, 10),
    };
    setParties((prev) => [newParty, ...prev]);
  };

  const updateParty = (id: string, updated: Partial<Party>) => {
    setParties((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updated } : p))
    );
  };

  const deleteParty = (id: string) => {
    setParties((prev) => prev.filter((p) => p.id !== id));
  };

  // Account CRUD
  const addAccount = (account: Omit<Account, 'id'>) => {
    const newAccount: Account = {
      ...account,
      id: 'acc-' + Date.now(),
      openingBalance: account.openingBalance !== undefined ? account.openingBalance : account.balance || 0,
      isDefault: account.isDefault || false,
    };
    setAccounts((prev) => {
      if (newAccount.isDefault) {
        return [...prev.map((a) => ({ ...a, isDefault: false })), newAccount];
      }
      return [...prev, newAccount];
    });
  };

  const updateAccount = (id: string, updated: Partial<Account>) => {
    setAccounts((prev) =>
      prev.map((a) => {
        if (a.id === id) {
          const isDef = updated.isDefault !== undefined ? updated.isDefault : a.isDefault;
          return { ...a, ...updated, isDefault: isDef };
        }
        if (updated.isDefault) {
          return { ...a, isDefault: false };
        }
        return a;
      })
    );
  };

  const deleteAccount = (id: string): { success: boolean; message?: string } => {
    if (accounts.length <= 1) {
      return { success: false, message: 'Kam az kam aik Cash ya Bank account system men hona lazmi hay.' };
    }
    const accToDelete = accounts.find((a) => a.id === id);
    if (!accToDelete) {
      return { success: false, message: 'Account nahi mila.' };
    }

    setAccounts((prev) => {
      const remaining = prev.filter((a) => a.id !== id);
      if (accToDelete.isDefault && remaining.length > 0) {
        remaining[0].isDefault = true;
      }
      return remaining;
    });

    return { success: true };
  };

  const getReconciliationAudit = (): ReconciliationReport => {
    // 1. Audit Accounts
    const accountAudits: AccountReconciliationItem[] = accounts.map((acc) => {
      const opening = acc.openingBalance || 0;
      let totalInflow = 0;
      let totalOutflow = 0;
      let txCount = 0;

      transactions.forEach((tx) => {
        if (tx.type === 'Transfer') {
          if (tx.accountId === acc.id) {
            totalOutflow += tx.totalAmount;
            txCount++;
          }
          if (tx.toAccountId === acc.id) {
            totalInflow += tx.totalAmount;
            txCount++;
          }
        } else if (tx.accountId === acc.id && (tx.paidAmount || 0) > 0) {
          if (tx.type === 'Sale' || tx.type === 'Receive') {
            totalInflow += tx.paidAmount;
            txCount++;
          } else if (tx.type === 'Purchase' || tx.type === 'Pay') {
            totalOutflow += tx.paidAmount;
            txCount++;
          }
        }
      });

      const calculatedBalance = Math.round((opening + totalInflow - totalOutflow) * 100) / 100;
      const recordedBalance = Math.round(acc.balance * 100) / 100;
      const difference = Math.round((recordedBalance - calculatedBalance) * 100) / 100;

      return {
        id: acc.id,
        name: acc.name,
        type: acc.type,
        bankName: acc.bankName,
        openingBalance: opening,
        totalInflow,
        totalOutflow,
        calculatedBalance,
        recordedBalance,
        difference,
        transactionCount: txCount,
        status: Math.abs(difference) < 0.01 ? 'balanced' : 'discrepancy',
      };
    });

    // 2. Audit Parties
    const partyAudits: PartyReconciliationItem[] = parties.map((pty) => {
      const opening = pty.openingBalance || 0;
      let totalInvoiced = 0;
      let totalSettled = 0;
      let txCount = 0;
      let runningCalc = opening;

      transactions.forEach((tx) => {
        if (tx.partyId === pty.id) {
          txCount++;
          const unpaid = tx.balanceDue !== undefined ? tx.balanceDue : (tx.totalAmount - (tx.paidAmount || 0));
          if (tx.type === 'Sale') {
            totalInvoiced += tx.totalAmount;
            totalSettled += tx.paidAmount || 0;
            runningCalc += unpaid;
          } else if (tx.type === 'Purchase') {
            totalInvoiced += tx.totalAmount;
            totalSettled += tx.paidAmount || 0;
            runningCalc -= unpaid;
          } else if (tx.type === 'Receive') {
            totalSettled += tx.paidAmount || 0;
            runningCalc -= (tx.paidAmount || 0);
          } else if (tx.type === 'Pay') {
            totalSettled += tx.paidAmount || 0;
            runningCalc += (tx.paidAmount || 0);
          }
        }
      });

      const calculatedBalance = Math.round(runningCalc * 100) / 100;
      const recordedBalance = Math.round(pty.currentBalance * 100) / 100;
      const difference = Math.round((recordedBalance - calculatedBalance) * 100) / 100;

      return {
        id: pty.id,
        name: pty.name,
        type: pty.type,
        openingBalance: opening,
        totalInvoiced,
        totalSettled,
        calculatedBalance,
        recordedBalance,
        difference,
        transactionCount: txCount,
        status: Math.abs(difference) < 0.01 ? 'balanced' : 'discrepancy',
      };
    });

    // 3. Audit Stock
    const stockAudits: StockReconciliationItem[] = products.map((prod) => {
      let totalPurchased = 0;
      let totalSold = 0;

      transactions.forEach((tx) => {
        tx.items?.forEach((it) => {
          if (it.productId === prod.id) {
            if (tx.type === 'Purchase') totalPurchased += it.quantity;
            if (tx.type === 'Sale') totalSold += it.quantity;
          }
        });
      });

      return {
        id: prod.id,
        name: prod.name,
        grade: prod.grade,
        unit: prod.unit,
        totalPurchased,
        totalSold,
        recordedStock: prod.currentStock,
        calculatedStockDelta: totalPurchased - totalSold,
      };
    });

    // 4. Ghost transactions check (Credit transactions having cash/bank account attached)
    const ghostCount = transactions.filter(
      (t) => t.type !== 'Transfer' && (t.paidAmount || 0) <= 0 && Boolean(t.accountId || t.accountName)
    ).length;

    const accountDiscrepancies = accountAudits.filter((a) => a.status === 'discrepancy').length;
    const partyDiscrepancies = partyAudits.filter((p) => p.status === 'discrepancy').length;
    const totalDiscrepanciesCount = accountDiscrepancies + partyDiscrepancies + ghostCount;

    return {
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' · ' + new Date().toISOString().slice(0, 10),
      accounts: accountAudits,
      parties: partyAudits,
      stock: stockAudits,
      cleanedGhostTransactionsCount: ghostCount,
      totalDiscrepanciesCount,
      hasDiscrepancies: totalDiscrepanciesCount > 0,
    };
  };

  const reconcileAll = (): ReconciliationReport => {
    // 1. Sanitize transactions: strip accountId/accountName from unpaid non-transfer transactions
    let cleanedCount = 0;
    const sanitizedTransactions = transactions.map((tx) => {
      if (tx.type !== 'Transfer' && (tx.paidAmount || 0) <= 0 && (tx.accountId || tx.accountName)) {
        cleanedCount++;
        return {
          ...tx,
          accountId: undefined,
          accountName: undefined,
        };
      }
      return tx;
    });

    if (cleanedCount > 0) {
      setTransactions(sanitizedTransactions);
    }

    // 2. Re-calculate all account balances strictly from transaction inflows and outflows
    setAccounts((prevAccounts) => {
      return prevAccounts.map((acc) => {
        let calculated = acc.openingBalance || 0;
        sanitizedTransactions.forEach((tx) => {
          if (tx.type === 'Transfer') {
            if (tx.accountId === acc.id) calculated -= tx.totalAmount;
            if (tx.toAccountId === acc.id) calculated += tx.totalAmount;
          } else if (tx.accountId === acc.id && (tx.paidAmount || 0) > 0) {
            if (tx.type === 'Sale' || tx.type === 'Receive') {
              calculated += tx.paidAmount;
            } else if (tx.type === 'Purchase' || tx.type === 'Pay') {
              calculated -= tx.paidAmount;
            }
          }
        });
        return { ...acc, balance: Math.round(calculated * 100) / 100 };
      });
    });

    // 3. Re-calculate all party balances
    setParties((prevParties) => {
      return prevParties.map((pty) => {
        let runningCalc = pty.openingBalance || 0;
        sanitizedTransactions.forEach((tx) => {
          if (tx.partyId === pty.id) {
            const unpaid = tx.balanceDue !== undefined ? tx.balanceDue : (tx.totalAmount - (tx.paidAmount || 0));
            if (tx.type === 'Sale') runningCalc += unpaid;
            else if (tx.type === 'Purchase') runningCalc -= unpaid;
            else if (tx.type === 'Receive') runningCalc -= (tx.paidAmount || 0);
            else if (tx.type === 'Pay') runningCalc += (tx.paidAmount || 0);
          }
        });
        return { ...pty, currentBalance: Math.round(runningCalc * 100) / 100 };
      });
    });

    return getReconciliationAudit();
  };

  const reconcileAccountBalances = () => {
    reconcileAll();
  };

  // Expense Head CRUD
  const addExpenseHead = (head: Omit<ExpenseHead, 'id' | 'createdAt'>): ExpenseHead => {
    const newHead: ExpenseHead = {
      ...head,
      id: 'exp-' + Date.now(),
      createdAt: new Date().toISOString().slice(0, 10),
    };
    setExpenseHeads((prev) => [newHead, ...prev]);
    return newHead;
  };

  const updateExpenseHead = (id: string, updated: Partial<ExpenseHead>) => {
    setExpenseHeads((prev) =>
      prev.map((h) => (h.id === id ? { ...h, ...updated } : h))
    );
  };

  const deleteExpenseHead = (id: string) => {
    setExpenseHeads((prev) => prev.filter((h) => h.id !== id));
  };

  const updateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  const resetAllData = () => {
    setProducts([]);
    setParties([]);
    setAccounts(INITIAL_ACCOUNTS.map((a) => ({ ...a, balance: 0 })));
    setTransactions([]);
    setLedgerEntries([]);
    setExpenseHeads(INITIAL_EXPENSE_HEADS);
    try {
      Object.values(STORAGE_KEYS).forEach((k) => localStorage.removeItem(k));
      ['oilflow_products_v1', 'oilflow_parties_v1', 'oilflow_accounts_v1', 'oilflow_transactions_v1', 'oilflow_ledger_v1'].forEach((k) => localStorage.removeItem(k));
    } catch {
      // ignore
    }
  };

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        searchQuery,
        setSearchQuery,
        isMobileMenuOpen,
        setIsMobileMenuOpen,
        products,
        parties,
        accounts,
        transactions,
        ledgerEntries,
        settings,
        transactionModalOpen,
        transactionModalInitialType,
        transactionModalInitialProduct,
        transactionModalInitialPartyId,
        openTransactionModal,
        closeTransactionModal,
        productDrawerOpen,
        editingProduct,
        openProductDrawer,
        closeProductDrawer,
        partyModalOpen,
        editingParty,
        openPartyModal,
        closePartyModal,
        viewingTransaction,
        openViewTransactionModal,
        closeViewTransactionModal,
        pdfPreviewTransaction,
        openPdfPreview,
        closePdfPreview,
        downloadTransactionPdf,
        editingTransaction,
        openEditTransactionModal,
        closeEditTransactionModal,
        transferModalOpen,
        openTransferModal,
        closeTransferModal,
        journalModalOpen,
        journalModalInitialType,
        journalModalInitialExpenseHeadId,
        openJournalModal,
        closeJournalModal,
        viewingPartyLedgerId,
        openPartyLedgerModal,
        closePartyLedgerModal,
        viewingAccountLedgerId,
        openAccountLedgerModal,
        closeAccountLedgerModal,
        viewingProductLedgerId,
        openProductLedgerModal,
        closeProductLedgerModal,
        expenseHeads,
        addExpenseHead,
        updateExpenseHead,
        deleteExpenseHead,
        getExpenseHeadSpending,
        totalExpensesAllTime,
        todayExpenses,
        addProduct,
        updateProduct,
        deleteProduct,
        adjustStock,
        addParty,
        updateParty,
        deleteParty,
        addAccount,
        updateAccount,
        deleteAccount,
        reconcileAccountBalances,
        reconcileModalOpen,
        openReconcileModal,
        closeReconcileModal,
        getReconciliationAudit,
        reconcileAll,
        createTransaction,
        updateTransaction,
        deleteTransaction,
        updateSettings,
        totalCash,
        totalBank,
        totalStockUnits,
        totalStockVolumeLiters,
        totalStockValue,
        totalCustomerReceivables,
        totalSupplierPayables,
        todayCashIn,
        todayCashOut,
        todayNetCash,
        lowStockCount,
        formatCurrency,
        resetAllData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
