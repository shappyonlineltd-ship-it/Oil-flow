import { Product, Party, Account, Transaction, AppSettings, ExpenseHead } from '../types';

export const INITIAL_EXPENSE_HEADS: ExpenseHead[] = [];

export const INITIAL_ACCOUNTS: Account[] = [
  {
    id: 'acc-cash',
    name: 'Cash in Hand (Safe)',
    type: 'Cash',
    balance: 0,
    branch: 'Depot Vault',
    isDefault: true,
  },
  {
    id: 'acc-hbl',
    name: 'HBL Corporate Account',
    type: 'Bank',
    bankName: 'Habib Bank Limited',
    accountNumber: '',
    balance: 0,
    branch: 'Main Market Branch',
  },
  {
    id: 'acc-meezan',
    name: 'Meezan Islamic Account',
    type: 'Bank',
    bankName: 'Meezan Bank Ltd',
    accountNumber: '',
    balance: 0,
    branch: 'Gulberg Commercial',
  },
];

export const INITIAL_PRODUCTS: Product[] = [];

export const INITIAL_PARTIES: Party[] = [];

export const INITIAL_TRANSACTIONS: Transaction[] = [];

export const INITIAL_SETTINGS: AppSettings = {
  businessName: 'Tariq Oil Traders',
  depotName: 'Lahore Main Depot',
  ownerName: 'Muhammad Tariq',
  currencySymbol: 'Rs.',
  minStockAlertSound: true,
};
